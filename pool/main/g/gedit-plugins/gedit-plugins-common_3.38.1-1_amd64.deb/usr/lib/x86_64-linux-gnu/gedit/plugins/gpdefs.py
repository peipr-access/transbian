# -*- coding: utf-8 -*-

GETTEXT_PACKAGE = "gedit-plugins"
