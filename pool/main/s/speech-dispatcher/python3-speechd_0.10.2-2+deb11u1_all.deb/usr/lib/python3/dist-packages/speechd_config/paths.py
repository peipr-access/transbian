SPD_CONF_ORIG_PATH="/usr/share/speech-dispatcher/conf"
SPD_CONF_PATH="/etc/speech-dispatcher"
SPD_SOUND_DATA_PATH="/usr/share/sounds/speech-dispatcher"
SPD_DESKTOP_CONF_PATH="/usr/share/speech-dispatcher/conf/desktop"
