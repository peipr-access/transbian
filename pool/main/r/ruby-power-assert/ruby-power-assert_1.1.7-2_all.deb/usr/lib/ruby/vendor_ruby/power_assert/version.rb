module PowerAssert
  VERSION = "1.1.7"
end
