WALLPAPER=/usr/share/images/desktop-base/desktop-grub.png
COLOR_NORMAL=white/black
COLOR_HIGHLIGHT=black/white
