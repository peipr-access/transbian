Branding is in brand/

brand/* - splash/about
	+ used in desktop/source/splash/splash.cxx
	+ used in sfx2/source/dialog/about.cxx

brand/shell/* - for the shell
	+ used in framework/source/services/backingwindow.cxx
