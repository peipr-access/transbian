document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Documentos de texto (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Información xeral e uso da interface de usuario</label><ul>\
    <li><a target="_top" href="gl/text/swriter/main0000.html?DbPAR=WRITER">Reciba a benvida á Axuda de LibreOffice Writer</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0503.html?DbPAR=WRITER">Recursos de LibreOffice Writer</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/main.html?DbPAR=WRITER">Instrucións para a utilización de LibreOffice Writer</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Ancorar e redimensionar xanelas</a></li>\
    <li><a target="_top" href="gl/text/swriter/04/01020000.html?DbPAR=WRITER">Teclas de atallo de LibreOffice Writer</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/words_count.html?DbPAR=WRITER">Conta de palabras</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/keyboard.html?DbPAR=WRITER">Utilización das teclas de atallo (Accesibilidade de LibreOffice Writer)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Referencia das ordes e do menú</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menús</label><ul>\
    <li><a target="_top" href="gl/text/swriter/main0100.html?DbPAR=WRITER">Menús</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0101.html?DbPAR=WRITER">Ficheiro</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0102.html?DbPAR=WRITER">Editar</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0103.html?DbPAR=WRITER">Ver</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0104.html?DbPAR=WRITER">Inserir</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0105.html?DbPAR=WRITER">Formato</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0115.html?DbPAR=WRITER">Estilos</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0110.html?DbPAR=WRITER">Táboa</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0120.html?DbPAR=WRITER">Menú Formulario</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0106.html?DbPAR=WRITER">Ferramentas</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0107.html?DbPAR=WRITER">Xanela</a></li>\
    <li><a target="_top" href="gl/text/shared/main0108.html?DbPAR=WRITER">Axuda</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="gl/text/swriter/main0200.html?DbPAR=WRITER">Barras de ferramentas</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0202.html?DbPAR=WRITER">Barra Formatado</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0203.html?DbPAR=WRITER">Barra de imaxes</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0204.html?DbPAR=WRITER">Barra Táboa</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0205.html?DbPAR=WRITER">Barra Propiedades de obxecto de debuxo</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0206.html?DbPAR=WRITER">Barra Viñetas e numeración</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0208.html?DbPAR=WRITER">Barra de estado</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0210.html?DbPAR=WRITER">Visualizar impresión</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0213.html?DbPAR=WRITER">Regras</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0214.html?DbPAR=WRITER">Barra de fórmulas</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0215.html?DbPAR=WRITER">Barra Marco</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0216.html?DbPAR=WRITER">Barra Obxecto OLE</a></li>\
    <li><a target="_top" href="gl/text/swriter/main0220.html?DbPAR=WRITER">Barra de obxectos de texto</a></li>\
    <li><a target="_top" href="gl/text/shared/main0201.html?DbPAR=WRITER">Barra Estándar</a></li>\
    <li><a target="_top" href="gl/text/shared/main0212.html?DbPAR=WRITER">Barra Datos de táboa</a></li>\
    <li><a target="_top" href="gl/text/shared/main0213.html?DbPAR=WRITER">Barra Exploración de formularios</a></li>\
    <li><a target="_top" href="gl/text/shared/main0214.html?DbPAR=WRITER">Barra Deseño de consulta</a></li>\
    <li><a target="_top" href="gl/text/shared/main0226.html?DbPAR=WRITER">Barra de ferramentas Deseño de formulario</a></li>\
    <li><a target="_top" href="gl/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Barra de ferramentas do LibreLogo</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">Crear documentos de texto</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navegar e seleccionar co teclado</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Utilización do cursor directo</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Gráficos en documentos de texto</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Inserir imaxes</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Inserir imaxes de ficheiros</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Inserir imaxes da galería co método arrastrar e soltar</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Inserir imaxes dixitalizadas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Inserir gráficas de Calc en documentos de texto</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Inserir imaxes de LibreOffice Draw ou Impress</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Táboas en documentos de texto</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Desactivar e activar o recoñecemento de números en táboas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/tablemode.html?DbPAR=WRITER">Modificar filas e columnas co teclado</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/table_delete.html?DbPAR=WRITER">Eliminar táboas ou o seus contido</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/table_insert.html?DbPAR=WRITER">Inserir táboas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Repetir un título de táboa nunha nova páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Redimensionar filas e columnas en táboas de texto</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Obxectos en documentos de texto</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Posicionamento de obxectos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/wrap.html?DbPAR=WRITER">Axuste de texto ao redor de obxectos</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Seccións e marcos nos documentos de texto</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/sections.html?DbPAR=WRITER">Utilización de seccións</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/section_edit.html?DbPAR=WRITER">Editar seccións</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/section_insert.html?DbPAR=WRITER">Inserir seccións</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Índices e índices analíticos</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numeración de capítulos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Índices definidos polo usuario</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Crear índice</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/indices_index.html?DbPAR=WRITER">Crear índices alfabéticos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Índices que comprenden varios documentos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Crear unha bibliografía</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Editar ou eliminar entradas de índices e de táboas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Actualizar, editar e eliminar índices</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Definir entradas de índice</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formatado de índices</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Campos en documentos de texto</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/fields.html?DbPAR=WRITER">Sobre os campos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserir un campo de data fixa ou variábel</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/field_convert.html?DbPAR=WRITER">Converter un campo en texto</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navegación polos documentos de texto</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Mover e copiar texto en documentos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Reorganizar documentos usando o Navegador</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserir hiperligazóns co Navegador</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/navigator.html?DbPAR=WRITER">Navegador de documentos de texto</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Calcular en documentos de texto</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Calcular en táboas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/calculate.html?DbPAR=WRITER">Calcular en documentos de texto</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Calcular e pegar o resultado dunha fórmula nun documento de texto</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Calcular totais de celas en táboas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Calcular fórmulas complexas en documentos de texto</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Mostrar o resultado dun cálculo de táboa noutra táboa</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formato dos documentos de texto</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">Modelos e estilos</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Modelos e estilos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Alternar estilos de páxina en páxinas impares e pares</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/change_header.html?DbPAR=WRITER">Crear un estilo de páxina baseado na páxina actual</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/load_styles.html?DbPAR=WRITER">Utilización de estilos doutro documento ou modelo</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Crear estilos a partir de seleccións</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Actualizar estilos a partir de seleccións</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/template_create.html?DbPAR=WRITER">Crear modelos de documentos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/template_default.html?DbPAR=WRITER">Cambiar o modelo predefinido</a></li>\
			</ul></li>\
    <li><a target="_top" href="gl/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Mudar a orientación de páxina (horizontal ou vertical)</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/text_capital.html?DbPAR=WRITER">Modificar maiúsculas/minúsculas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Texto oculto</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definir cabeceiras e pés de páxina diferentes</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserir o nome e número de capítulo nunha cabeceira ou pé de páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Aplicar formatado de texto ao teclear</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/reset_format.html?DbPAR=WRITER">Redefinir os atributos de tipo de letra</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Aplicar estilos en modo formato de enchedura</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/wrap.html?DbPAR=WRITER">Axuste de texto ao redor de obxectos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Utilizar un marco para centrar texto nunha páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Enfatizar texto</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Rodar texto</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/page_break.html?DbPAR=WRITER">Inserir e eliminar quebras de páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Crear e aplicar estilos de páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/subscript.html?DbPAR=WRITER">Converter texto en subíndice ou superíndice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Elementos de texto especiais</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/captions.html?DbPAR=WRITER">Utilización de lendas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Texto condicional</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Texto condicional para contas de páxinas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserir un campo de data fixa ou variábel</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Engadir campos de entrada</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Inserir numeración en páxinas de continuación</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Inserir números de páxina en pés de páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Texto oculto</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definir cabeceiras e pés de páxina diferentes</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserir o nome e número de capítulo nunha cabeceira ou pé de páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Consultar datos do usuario en campos ou condicións</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Inserir e editar notas ao pé de páxina ou notas ao final</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Espazamento entre notas ao pé de páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/header_footer.html?DbPAR=WRITER">Sobre cabeceiras e pés de páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formatado de cabeceiras ou pés de páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/text_animation.html?DbPAR=WRITER">Animar texto</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Crear cartas modelo</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Funcións automáticas</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Engadir excepcións á lista de corrección automática</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/autotext.html?DbPAR=WRITER">Utilización do texto automático</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Elaborar listas numeradas ou con viñetas ao teclear</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/auto_off.html?DbPAR=WRITER">Desactivar AutoCorreção</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Verificación ortográfica automática</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Desactivar e activar o recoñecemento de números en táboas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Guionización</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numeración e listas</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Engadir números de capítulos nas lendas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Elaborar listas numeradas ou con viñetas ao teclear</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numeración de capítulos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the Chapter Level of Numbered and Bulleted Lists</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Combinar listas numeradas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Engadir números de liñas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modificar a numeración en listas numeradas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Definir intervalos numéricos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Engadir numeración</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numeración e estilos de numeración</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Engadir viñetas</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Corrector ortográfico, tesauro e idiomas</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Verificación ortográfica automática</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Eliminar palabras dun dicionario definido polo usuario</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Dicionario de sinónimos</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Comprobar ortografía e gramática</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Suxestións para a resolución de problemas</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Inserir texto antes dunha táboa na parte superior da páxina</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Ir a marcadores específicos</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Cargar, gardar, importar, exportar e velar</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/send2html.html?DbPAR=WRITER">Gardar documentos de texto en formato HTML</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Inserir un documento de texto completo</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Documentos principais</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Documentos mestre e Subdocuments</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Ligazóns e referencias</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/references.html?DbPAR=WRITER">Inserir referencias cruzadas</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserir hiperligazóns co Navegador</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Impresión</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Seleccionar bandexas de papel de impresora</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/print_preview.html?DbPAR=WRITER">Previsualizar unha páxina antes da impresión</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/print_small.html?DbPAR=WRITER">Imprimir varias páxinas na mesma folla</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Crear e aplicar estilos de páxina</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Buscar e substituír</label><ul>\
    <li><a target="_top" href="gl/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="gl/text/shared/01/02100001.html?DbPAR=WRITER">Lista de expresións regulares</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">Documentos en HTML (Writer Web)</label><ul>\
    <li><a target="_top" href="gl/text/shared/07/09000000.html?DbPAR=WRITER">Páxinas web</a></li>\
    <li><a target="_top" href="gl/text/shared/02/01170700.html?DbPAR=WRITER">Formularios e filtros HTML</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/send2html.html?DbPAR=WRITER">Gardar documentos de texto en formato HTML</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Follas de cálculo (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Información xeral e uso da interface de usuario</label><ul>\
    <li><a target="_top" href="gl/text/scalc/main0000.html?DbPAR=CALC">Reciba a benvida á Axuda do Calc do LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0503.html?DbPAR=CALC">Recursos de LibreOffice Calc</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/keyboard.html?DbPAR=CALC">Shortcut Keys (LibreOffice Calc Accessibility)</a></li>\
    <li><a target="_top" href="gl/text/scalc/04/01020000.html?DbPAR=CALC">Teclas de atallo para follas de cálculo</a></li>\
    <li><a target="_top" href="gl/text/scalc/05/02140000.html?DbPAR=CALC">Códigos de erro en LibreOffice Calc</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060112.html?DbPAR=CALC">Add-in para Programación en $ [officename] Calc</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/main.html?DbPAR=CALC">Instructions for Using LibreOffice Calc</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Referencia das ordes e menú</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menús</label><ul>\
    <li><a target="_top" href="gl/text/scalc/main0100.html?DbPAR=CALC">Menús</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0101.html?DbPAR=CALC">Ficheiro</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0102.html?DbPAR=CALC">Editar</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0103.html?DbPAR=CALC">Ver</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0104.html?DbPAR=CALC">Inserir</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0105.html?DbPAR=CALC">Formato</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0116.html?DbPAR=CALC">Folla</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0112.html?DbPAR=CALC">Datos</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0106.html?DbPAR=CALC">Ferramentas</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0107.html?DbPAR=CALC">Xanela</a></li>\
    <li><a target="_top" href="gl/text/shared/main0108.html?DbPAR=CALC">Axuda</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="gl/text/scalc/main0200.html?DbPAR=CALC">Barras de ferramentas</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0202.html?DbPAR=CALC">Barra Formatado</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0203.html?DbPAR=CALC">Barra Propiedades de obxecto de debuxo</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0205.html?DbPAR=CALC">Barra Formatado de texto</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0206.html?DbPAR=CALC">Barra de fórmulas</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0208.html?DbPAR=CALC">Barra de estado</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0210.html?DbPAR=CALC">Barra de visualización de páxina</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0214.html?DbPAR=CALC">Barra de imaxes</a></li>\
    <li><a target="_top" href="gl/text/scalc/main0218.html?DbPAR=CALC">Barra Ferramentas</a></li>\
    <li><a target="_top" href="gl/text/shared/main0201.html?DbPAR=CALC">Barra Estándar</a></li>\
    <li><a target="_top" href="gl/text/shared/main0212.html?DbPAR=CALC">Barra Datos de táboa</a></li>\
    <li><a target="_top" href="gl/text/shared/main0213.html?DbPAR=CALC">Barra Exploración de formularios</a></li>\
    <li><a target="_top" href="gl/text/shared/main0214.html?DbPAR=CALC">Barra Deseño de consulta</a></li>\
    <li><a target="_top" href="gl/text/shared/main0226.html?DbPAR=CALC">Barra de ferramentas Deseño de formulario</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Tipos de funcións e operadores</label><ul>\
    <li><a target="_top" href="gl/text/scalc/01/04060000.html?DbPAR=CALC">Asistente de funcións</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060100.html?DbPAR=CALC">Funcións por Categoría</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060107.html?DbPAR=CALC">Funcións de matriz</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060120.html?DbPAR=CALC">Funcións de lóxica binaria</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060101.html?DbPAR=CALC">Funcións de base de datos</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060102.html?DbPAR=CALC">Función de data e hora</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060103.html?DbPAR=CALC">Funcións financeiras Parte I</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060119.html?DbPAR=CALC">Funcións financeiras Parte I</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060118.html?DbPAR=CALC">Funcións financeiras Parte III</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060104.html?DbPAR=CALC">Funcións de información</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060105.html?DbPAR=CALC">Funcións lóxicas</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060106.html?DbPAR=CALC">Funcións matemáticas</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060108.html?DbPAR=CALC">Funcións estatísticas</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060181.html?DbPAR=CALC">Funcións financeiras Parte III</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060182.html?DbPAR=CALC">Funcións financeiras Parte III</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060183.html?DbPAR=CALC">Funcións financeiras Parte III</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060184.html?DbPAR=CALC">Funcións financeiras Parte III</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060185.html?DbPAR=CALC">Funcións financeiras Parte III</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060109.html?DbPAR=CALC">Funcións de folla de cálculo</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060110.html?DbPAR=CALC">Funcións de texto</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060111.html?DbPAR=CALC">Add-in Funcións</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060115.html?DbPAR=CALC">Add-in funcións, Lista de Funcións Análise Part One</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060116.html?DbPAR=CALC">Add-in funcións, Lista de Funcións Análise Parte II</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/04060199.html?DbPAR=CALC">Operadores en LibreOffice Calc</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/userdefined_function.html?DbPAR=CALC">User-Defined Functions</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Cargar, gardar, importar, exportar e velar</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/webquery.html?DbPAR=CALC">Inserting External Data in Table (WebQuery)</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/html_doc.html?DbPAR=CALC">Saving and Opening Sheets in HTML</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/csv_formula.html?DbPAR=CALC">Importing and Exporting Text Files</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formatado</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/text_rotate.html?DbPAR=CALC">Rotating Text</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/text_wrap.html?DbPAR=CALC">Writing Multi-line Text</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formatting Numbers as Text</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/super_subscript.html?DbPAR=CALC">Text Superscript / Subscript</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/row_height.html?DbPAR=CALC">Changing Row Height or Column Width</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Applying Conditional Formatting</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Highlighting Negative Numbers</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Assigning Formats by Formula</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Entering a Number with Leading Zeros</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/format_table.html?DbPAR=CALC">Formatting Spreadsheets</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/format_value.html?DbPAR=CALC">Formatting Numbers With Decimals</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/value_with_name.html?DbPAR=CALC">Naming Cells</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/table_rotate.html?DbPAR=CALC">Rotating Tables (Transposing)</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/rename_table.html?DbPAR=CALC">Renaming Sheets</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx Years</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Using Rounded Off Numbers</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/currency_format.html?DbPAR=CALC">Cells in Currency Format</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/autoformat.html?DbPAR=CALC">Usar Formato automático en táboas</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/note_insert.html?DbPAR=CALC">Inserting and Editing Comments</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/design.html?DbPAR=CALC">Selecting Themes for Sheets</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Entering Fractions</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtrar e ordenar</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/filters.html?DbPAR=CALC">Applying Filters</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/specialfilter.html?DbPAR=CALC">Filter: Applying Advanced Filters</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/autofilter.html?DbPAR=CALC">Aplicar Filtro automático</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/sorted_list.html?DbPAR=CALC">Applying Sort Lists</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Impresión</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/print_title_row.html?DbPAR=CALC">Printing Rows or Columns on Every Page</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/print_landscape.html?DbPAR=CALC">Printing Sheets in Landscape Format</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/print_details.html?DbPAR=CALC">Printing Sheet Details</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/print_exact.html?DbPAR=CALC">Defining Number of Pages for Printing</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Intervalos de datos</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/database_define.html?DbPAR=CALC">Defining Database Ranges</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtering Cell Ranges</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/database_sort.html?DbPAR=CALC">Sorting Data</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Táboa dinámica</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/datapilot.html?DbPAR=CALC">Táboa dinámica</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Creating Pivot Tables</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Deleting Pivot Tables</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Editing Pivot Tables</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtering Pivot Tables</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Selecting Pivot Table Output Ranges</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Updating Pivot Tables</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Gráfica dinámica</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Escenarios</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/scenario.html?DbPAR=CALC">Using Scenarios</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotais</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Referencias</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Addresses and References, Absolute and Relative</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/cellreferences.html?DbPAR=CALC">Referenciar unha cela noutro documento</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">References to Other Sheets and Referencing URLs</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Facer referencia ás celas polo método de arrastrar e soltar.</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/address_auto.html?DbPAR=CALC">Recoñecer nomes como referencia</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Ver, seleccionar e copiar</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/table_view.html?DbPAR=CALC">Changing Table Views</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/formula_value.html?DbPAR=CALC">Displaying Formulas or Values</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/line_fix.html?DbPAR=CALC">Freezing Rows or Columns as Headers</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navigating Through Sheets Tabs</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Copying to Multiple Sheets</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/cellcopy.html?DbPAR=CALC">Copiar só celas visíbeis</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/mark_cells.html?DbPAR=CALC">Selecting Multiple Cells</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Fórmulas e cálculos</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/formulas.html?DbPAR=CALC">Calculating With Formulas</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/formula_copy.html?DbPAR=CALC">Copying Formulas</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/formula_enter.html?DbPAR=CALC">Entering Formulas</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/formula_value.html?DbPAR=CALC">Displaying Formulas or Values</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/calculate.html?DbPAR=CALC">Cálculos nas follas de cálculo</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/calc_date.html?DbPAR=CALC">Cálculos con datas e horas</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/calc_series.html?DbPAR=CALC">Cálculo automático de series</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Cálculo de diferenzas temporais</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/matrixformula.html?DbPAR=CALC">Entering Matrix Formulas</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Protección</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/cell_protect.html?DbPAR=CALC">Protexer celas de cambios</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Desprotexer celas</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Diversos</label><ul>\
    <li><a target="_top" href="gl/text/scalc/guide/auto_off.html?DbPAR=CALC">Desactivar os cambios automáticos</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/consolidate.html?DbPAR=CALC">Consolidating Data</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/goalseek.html?DbPAR=CALC">Applying Goal Seek</a></li>\
    <li><a target="_top" href="gl/text/scalc/01/solver.html?DbPAR=CALC">Resolvedor</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/multioperation.html?DbPAR=CALC">Applying Multiple Operations</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/multitables.html?DbPAR=CALC">Applying Multiple Sheets</a></li>\
    <li><a target="_top" href="gl/text/scalc/guide/validity.html?DbPAR=CALC">Validación do contido das celas</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentacións (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Información xeral e uso da interface de usuario</label><ul>\
    <li><a target="_top" href="gl/text/simpress/main0000.html?DbPAR=IMPRESS">Benvida á Axuda de LibreOffice Impress</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0503.html?DbPAR=IMPRESS">Recursos de LibreOffice Impress</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Utilización de teclas de atallo en LibreOffice Impress</a></li>\
    <li><a target="_top" href="gl/text/simpress/04/01020000.html?DbPAR=IMPRESS">Teclas de atallo para LibreOffice Impress</a></li>\
    <li><a target="_top" href="gl/text/simpress/04/presenter.html?DbPAR=IMPRESS">Atallos de teclado da consola de presentación</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/main.html?DbPAR=IMPRESS">Instrucións para utilizar LibreOffice Impress</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Referencia das ordes e do menú</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menús</label><ul>\
    <li><a target="_top" href="gl/text/simpress/main0100.html?DbPAR=IMPRESS">Menús</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0101.html?DbPAR=IMPRESS">Ficheiro</a></li>\
    <li><a target="_top" href="gl/text/simpress/main_edit.html?DbPAR=IMPRESS">Editar</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0103.html?DbPAR=IMPRESS">Ver</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0104.html?DbPAR=IMPRESS">Inserir</a></li>\
    <li><a target="_top" href="gl/text/simpress/main_format.html?DbPAR=IMPRESS">Formato</a></li>\
    <li><a target="_top" href="gl/text/simpress/main_slide.html?DbPAR=IMPRESS">Diapositiva</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0114.html?DbPAR=IMPRESS">Presentación de diapositivas</a></li>\
    <li><a target="_top" href="gl/text/simpress/main_tools.html?DbPAR=IMPRESS">Ferramentas</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0107.html?DbPAR=IMPRESS">Xanela</a></li>\
    <li><a target="_top" href="gl/text/shared/main0108.html?DbPAR=IMPRESS">Axuda</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="gl/text/simpress/main0200.html?DbPAR=IMPRESS">Barras de ferramentas</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0202.html?DbPAR=IMPRESS">Barra de ferramentas Liña e enchedura</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0203.html?DbPAR=IMPRESS">Barra Formatado de texto</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0204.html?DbPAR=IMPRESS">Barra Visualización de diapositivas</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0206.html?DbPAR=IMPRESS">Barra de estado</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0209.html?DbPAR=IMPRESS">Regras</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0210.html?DbPAR=IMPRESS">Barra Debuxo</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0211.html?DbPAR=IMPRESS">Barra Esquema</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0212.html?DbPAR=IMPRESS">Barra Clasificador de diapositivas</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0213.html?DbPAR=IMPRESS">Barra Opcións</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0214.html?DbPAR=IMPRESS">Barra de imaxes</a></li>\
    <li><a target="_top" href="gl/text/shared/main0201.html?DbPAR=IMPRESS">Barra Estándar</a></li>\
    <li><a target="_top" href="gl/text/shared/main0213.html?DbPAR=IMPRESS">Barra Exploración de formularios</a></li>\
    <li><a target="_top" href="gl/text/shared/main0226.html?DbPAR=IMPRESS">Barra de ferramentas Deseño de formulario</a></li>\
    <li><a target="_top" href="gl/text/shared/main0227.html?DbPAR=IMPRESS">Barra Editar puntos</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Cargar, gardar, importar, exportar e velar</label><ul>\
    <li><a target="_top" href="gl/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Gardar presentacións en formato HTML</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Importar páxinas HTML para presentacións</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Cargar cor, gradación e listas de trazados</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportar animacións a formato GIF</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Incluír follas de cálculo en diapositivas</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserir imaxes</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Copiar diapositivas doutras presentacións</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formatado</label><ul>\
    <li><a target="_top" href="gl/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Cargar cor, gradación e listas de trazados</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Cargar estilos de liña e de frecha</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Definir cores personalizadas</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Crear recheos en gradación</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Substitución de cores</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Dispor, aliñar e distribuír obxectos</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/background.html?DbPAR=IMPRESS">Modificar a enchedura de fondo da diapositiva</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/footer.html?DbPAR=IMPRESS">Engadir cabeceira ou pé de páxina a todas as diapositivas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Mover obxectos</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Imprimir</label><ul>\
    <li><a target="_top" href="gl/text/simpress/guide/printing.html?DbPAR=IMPRESS">Imprimir presentacións</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Imprimir diapositivas axustadas ao tamaño do papel</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Efectos</label><ul>\
    <li><a target="_top" href="gl/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportar animacións a formato GIF</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animar obxectos en presentación de diapositivas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animar transicións de diapositivas</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Transición gradual de dous obxectos</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Crear imaxes GIF animadas</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Obxectos, gráficos e mapas de bits</label><ul>\
    <li><a target="_top" href="gl/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Combinar obxectos e construír formas</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Agrupar obxectos</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Debuxar sectores e segmentos</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplicar obxectos</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Rotar obxectos</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Montar obxectos 3D</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Conectar liñas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Converter caracteres de texto en obxectos de debuxo</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Converter imaxes de mapa de bits en imaxes vectoriais</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Converter obxectos 2D en curvas, polígonos e obxectos 3D</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Cargar estilos de liña e de frecha</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Debuxar curvas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Editar curvas</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserir imaxes</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Incluír follas de cálculo en diapositivas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Mover obxectos</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Seleccionar obxectos subxacentes</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Crear fluxogramas</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Texto en presentacións</label><ul>\
    <li><a target="_top" href="gl/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Engadir texto</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Converter caracteres de texto en obxectos de debuxo</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Visualizar</label><ul>\
    <li><a target="_top" href="gl/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Modificar a orde das diapositivas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Zoom co teclado numérico</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Presentacións de diapositivas</label><ul>\
    <li><a target="_top" href="gl/text/simpress/guide/show.html?DbPAR=IMPRESS">Mostrar presentacións de diapositivas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/individual.html?DbPAR=IMPRESS">Crear presentacións personalizadas de diapositivas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Probar intervalos dos cambios de diapositivas</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Debuxos (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Información xeral e uso da interface de usuario</label><ul>\
    <li><a target="_top" href="gl/text/sdraw/main0000.html?DbPAR=DRAW">Reciba a benvida á Axuda do Draw do LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main0503.html?DbPAR=DRAW">Recursos de LibreOffice Draw</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Teclas de atallo para obxectos de debuxo</a></li>\
    <li><a target="_top" href="gl/text/sdraw/04/01020000.html?DbPAR=DRAW">Teclas de atallo para debuxos</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/main.html?DbPAR=DRAW">Instrucións para utilizar LibreOffice Draw</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Referencia das ordes e dos menús</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menús</label><ul>\
    <li><a target="_top" href="gl/text/sdraw/main0100.html?DbPAR=DRAW">Menús</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main0101.html?DbPAR=DRAW">Ficheiro</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main_edit.html?DbPAR=DRAW">Editar</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main0103.html?DbPAR=DRAW">Ver</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main_insert.html?DbPAR=DRAW">Inserir</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main_format.html?DbPAR=DRAW">Formato</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main_page.html?DbPAR=DRAW">Páxina</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main_shape.html?DbPAR=DRAW">Forma</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main_tools.html?DbPAR=DRAW">Ferramentas</a></li>\
    <li><a target="_top" href="gl/text/simpress/main0107.html?DbPAR=DRAW">Xanela</a></li>\
    <li><a target="_top" href="gl/text/shared/main0108.html?DbPAR=DRAW">Axuda</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="gl/text/sdraw/main0200.html?DbPAR=DRAW">Barras de ferramentas</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main0210.html?DbPAR=DRAW">Barra Debuxo</a></li>\
    <li><a target="_top" href="gl/text/sdraw/main0213.html?DbPAR=DRAW">Barra Opcións</a></li>\
    <li><a target="_top" href="gl/text/shared/main0201.html?DbPAR=DRAW">Barra Estándar</a></li>\
    <li><a target="_top" href="gl/text/shared/main0213.html?DbPAR=DRAW">Barra Exploración de formularios</a></li>\
    <li><a target="_top" href="gl/text/shared/main0226.html?DbPAR=DRAW">Barra de ferramentas Deseño de formulario</a></li>\
    <li><a target="_top" href="gl/text/shared/main0227.html?DbPAR=DRAW">Barra Editar puntos</a></li>\
    <li><a target="_top" href="gl/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D-Settings</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Cargar, gardar, importar e exportar</label><ul>\
    <li><a target="_top" href="gl/text/simpress/guide/palette_files.html?DbPAR=DRAW">Cargar cor, gradación e listas de trazados</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserir imaxes</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formato</label><ul>\
    <li><a target="_top" href="gl/text/simpress/guide/palette_files.html?DbPAR=DRAW">Cargar cor, gradación e listas de trazados</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Cargar estilos de liña e de frecha</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/color_define.html?DbPAR=DRAW">Definir cores personalizadas</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/gradient.html?DbPAR=DRAW">Crear recheos en gradación</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Substitución de cores</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Dispor, aliñar e distribuír obxectos</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/background.html?DbPAR=DRAW">Modificar a enchedura de fondo da diapositiva</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/move_object.html?DbPAR=DRAW">Mover obxectos</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Impresión</label><ul>\
    <li><a target="_top" href="gl/text/simpress/guide/printing.html?DbPAR=DRAW">Imprimir presentacións</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Imprimir diapositivas axustadas ao tamaño do papel</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Efectos</label><ul>\
    <li><a target="_top" href="gl/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Transición gradual de dous obxectos</a></li>\
    <li><a target="_top" href="gl/text/shared/01/05350000.html?DbPAR=DRAW">Efectos 3D</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Obxectos, gráficas e mapas de bits</label><ul>\
    <li><a target="_top" href="gl/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Combinar obxectos e construír formas</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Debuxar sectores e segmentos</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplicar obxectos</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Rotar obxectos</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Montar obxectos 3D</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Conectar liñas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/text2curve.html?DbPAR=DRAW">Converter caracteres de texto en obxectos de debuxo</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/vectorize.html?DbPAR=DRAW">Converter imaxes de mapa de bits en imaxes vectoriais</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/3d_create.html?DbPAR=DRAW">Converter obxectos 2D en curvas, polígonos e obxectos 3D</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Cargar estilos de liña e de frecha</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/line_draw.html?DbPAR=DRAW">Debuxar curvas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/line_edit.html?DbPAR=DRAW">Editar curvas</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserir imaxes</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/table_insert.html?DbPAR=DRAW">Incluír follas de cálculo en diapositivas</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/move_object.html?DbPAR=DRAW">Mover obxectos</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/select_object.html?DbPAR=DRAW">Seleccionar obxectos subxacentes</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/orgchart.html?DbPAR=DRAW">Crear fluxogramas</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Grupos e capas</label><ul>\
    <li><a target="_top" href="gl/text/sdraw/guide/groups.html?DbPAR=DRAW">Agrupar obxectos</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserting Layers</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="gl/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Texto en debuxos</label><ul>\
    <li><a target="_top" href="gl/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Engadir texto</a></li>\
    <li><a target="_top" href="gl/text/simpress/guide/text2curve.html?DbPAR=DRAW">Converter caracteres de texto en obxectos de debuxo</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Visualizar</label><ul>\
    <li><a target="_top" href="gl/text/simpress/guide/change_scale.html?DbPAR=DRAW">Zoom co teclado numérico</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Funcionalidade da base de datos (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Información xeral</label><ul>\
    <li><a target="_top" href="gl/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/database_main.html?DbPAR=BASE">Visión xeral da base de datos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_new.html?DbPAR=BASE">Crear novas bases de datos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_tables.html?DbPAR=BASE">Traballar con táboas</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_queries.html?DbPAR=BASE">Traballar con consultas</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_forms.html?DbPAR=BASE">Traballar con formularios</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_reports.html?DbPAR=BASE">Creando informes</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_register.html?DbPAR=BASE">Rexistrar e eliminar bases de datos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_im_export.html?DbPAR=BASE">Importar e exportar datos en Base</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Executar ordes SQL</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Fórmulas (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Información xeral e uso da interface do usuario</label><ul>\
    <li><a target="_top" href="gl/text/smath/main0000.html?DbPAR=MATH">Reciba a benvida á Axuda de LibreOffice Math</a></li>\
    <li><a target="_top" href="gl/text/smath/main0503.html?DbPAR=MATH">Funcións de LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">Elementos de fórmula do LibreOffice</label><ul>\
    <li><a target="_top" href="gl/text/smath/01/03090100.html?DbPAR=MATH">Operadores unarios/binarios</a></li>\
    <li><a target="_top" href="gl/text/smath/01/03090200.html?DbPAR=MATH">Relacións</a></li>\
    <li><a target="_top" href="gl/text/smath/01/03090800.html?DbPAR=MATH">Operacións de conxuntos</a></li>\
    <li><a target="_top" href="gl/text/smath/01/03090400.html?DbPAR=MATH">Funcións</a></li>\
    <li><a target="_top" href="gl/text/smath/01/03090300.html?DbPAR=MATH">Operadores</a></li>\
    <li><a target="_top" href="gl/text/smath/01/03090600.html?DbPAR=MATH">Atributos</a></li>\
    <li><a target="_top" href="gl/text/smath/01/03090500.html?DbPAR=MATH">Parénteses</a></li>\
    <li><a target="_top" href="gl/text/smath/01/03090700.html?DbPAR=MATH">Formato</a></li>\
    <li><a target="_top" href="gl/text/smath/01/03091600.html?DbPAR=MATH">Outros símbolos</a></li>\
            </ul></li>\
    <li><a target="_top" href="gl/text/smath/guide/main.html?DbPAR=MATH">Instrucións para o uso de LibreOffice Math</a></li>\
    <li><a target="_top" href="gl/text/smath/guide/keyboard.html?DbPAR=MATH">Atallos (accesibilidade de LibreOffice Math)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Referencia das ordes e do menú</label><ul>\
    <li><a target="_top" href="gl/text/smath/main0100.html?DbPAR=MATH">Menús</a></li>\
    <li><a target="_top" href="gl/text/smath/main0200.html?DbPAR=MATH">Barras de ferramentas</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Traballar con fórmulas</label><ul>\
    <li><a target="_top" href="gl/text/smath/guide/align.html?DbPAR=MATH">Aliñar manualmente partes de fórmulas</a></li>\
    <li><a target="_top" href="gl/text/smath/guide/attributes.html?DbPAR=MATH">Modificar os atributos predefinidos</a></li>\
    <li><a target="_top" href="gl/text/smath/guide/brackets.html?DbPAR=MATH">Combinar partes de fórmulas entre parénteses</a></li>\
    <li><a target="_top" href="gl/text/smath/guide/comment.html?DbPAR=MATH">Introducir comentarios</a></li>\
    <li><a target="_top" href="gl/text/smath/guide/newline.html?DbPAR=MATH">Introducir quebras de liña</a></li>\
    <li><a target="_top" href="gl/text/smath/guide/parentheses.html?DbPAR=MATH">Inserir parénteses</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Gráficos e diagramas</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Información xeral</label><ul>\
    <li><a target="_top" href="gl/text/schart/main0000.html?DbPAR=CHART">Gráficas en LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/schart/main0503.html?DbPAR=CHART">Recursos de LibreOffice Chart</a></li>\
    <li><a target="_top" href="gl/text/schart/04/01020000.html?DbPAR=CHART">Teclas de atallo para gráficas</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Marcos e scripts</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">BASIC LibreOffice</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Información xeral e uso da interface do usuario</label><ul>\
    <li><a target="_top" href="gl/text/sbasic/shared/main0601.html?DbPAR=BASIC">Axuda do Basic do LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programar con LibreOffice Basic</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/00000002.html?DbPAR=BASIC">Glosario de LibreOffice Basic</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01010210.html?DbPAR=BASIC">Fundamentos</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01020000.html?DbPAR=BASIC">Sintaxe</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01050000.html?DbPAR=BASIC">IDE de LibreOffice Basic</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01030100.html?DbPAR=BASIC">Visión xeral do IDE</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01030200.html?DbPAR=BASIC">O editor de Basic</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01050100.html?DbPAR=BASIC">Xanela Monitorización</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/main0211.html?DbPAR=BASIC">Barra de macros</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/05060700.html?DbPAR=BASIC">Macro</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Referencia das ordes</label><ul>\
    <li><a target="_top" href="gl/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01020500.html?DbPAR=BASIC">Bibliotecas, módulos e caixas de diálogo</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funcións, instrucións e operadores</label><ul>\
    <li><a target="_top" href="gl/text/sbasic/shared/03010000.html?DbPAR=BASIC">Funcións de E/S de pantalla</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020000.html?DbPAR=BASIC">Funcións de E/S de ficheiro</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030000.html?DbPAR=BASIC">Funcións de data e hora</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funcións de tratamento de erros</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03060000.html?DbPAR=BASIC">Operadores lóxicos</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03070000.html?DbPAR=BASIC">Operadores matemáticos</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funcións numéricas</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090000.html?DbPAR=BASIC">Control da execución do programa</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variábeis</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03110000.html?DbPAR=BASIC">Operadores de comparación</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120000.html?DbPAR=BASIC">Cadeas</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Calling Calc Functions in Macros</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03130000.html?DbPAR=BASIC">Outras ordes</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Lista alfabética de funcións, instrucións e operadores</label><ul>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080601.html?DbPAR=BASIC">Función Abs</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03104200.html?DbPAR=BASIC">Función Array</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120101.html?DbPAR=BASIC">Función Asc</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080101.html?DbPAR=BASIC">Función Atn</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03130100.html?DbPAR=BASIC">Instrución Beep</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100100.html?DbPAR=BASIC">Función CBool</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120105.html?DbPAR=BASIC">Función CByte</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100050.html?DbPAR=BASIC">Función CCur</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030116.html?DbPAR=BASIC">Función CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030115.html?DbPAR=BASIC">Función CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030114.html?DbPAR=BASIC">Función CDateFromUnoTime</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030113.html?DbPAR=BASIC">Función CDateToUnoTime</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030112.html?DbPAR=BASIC">Función CDateFromUnoDate</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030111.html?DbPAR=BASIC">Función CDateToUnoDate</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030108.html?DbPAR=BASIC">Función CDateFromIso</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030107.html?DbPAR=BASIC">Función CDateToIso</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100300.html?DbPAR=BASIC">Función CDate</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100400.html?DbPAR=BASIC">Función CDbl</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100060.html?DbPAR=BASIC">Función CDec</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100500.html?DbPAR=BASIC">Función CInt</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100600.html?DbPAR=BASIC">Función CLng</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100900.html?DbPAR=BASIC">Función CSng</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03101000.html?DbPAR=BASIC">Función CStr</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090401.html?DbPAR=BASIC">Instrución Call</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020401.html?DbPAR=BASIC">Instrución ChDir</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020402.html?DbPAR=BASIC">Instrución ChDrive</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090402.html?DbPAR=BASIC">Función Choose</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120102.html?DbPAR=BASIC">Función Chr</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020101.html?DbPAR=BASIC">Instrución Close</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03110100.html?DbPAR=BASIC">Operadores de comparación</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100700.html?DbPAR=BASIC">Instrución Const</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120313.html?DbPAR=BASIC">Función ConvertFromURL</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120312.html?DbPAR=BASIC">Función ConvertToURL</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080102.html?DbPAR=BASIC">Función Cos</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03132400.html?DbPAR=BASIC">Función CreateObject</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03131800.html?DbPAR=BASIC">Función CreateUnoDialog</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03132000.html?DbPAR=BASIC">Función CreateUnoListener</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03131600.html?DbPAR=BASIC">Función CreateUnoService</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03131500.html?DbPAR=BASIC">Función CreateUnoStruct</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03132300.html?DbPAR=BASIC">Función CreateUnoValue</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020403.html?DbPAR=BASIC">Función CurDir</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100070.html?DbPAR=BASIC">Función CVar</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03100080.html?DbPAR=BASIC">Función CVErr</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030110.html?DbPAR=BASIC">Function DateAdd</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030120.html?DbPAR=BASIC">Función DateDiff</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030130.html?DbPAR=BASIC">Función DatePart</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030101.html?DbPAR=BASIC">Función DateSerial</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030102.html?DbPAR=BASIC">Function DateValue</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030103.html?DbPAR=BASIC">Función Day</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090403.html?DbPAR=BASIC">Instrución Declare</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03101100.html?DbPAR=BASIC">Instrución DefBool</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03101300.html?DbPAR=BASIC">Instrución DefDate</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03101400.html?DbPAR=BASIC">Instrución DefDbl</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03101500.html?DbPAR=BASIC">Instrución DefInt</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03101600.html?DbPAR=BASIC">Instrución DefLng</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03101700.html?DbPAR=BASIC">Instrución DefObj</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102000.html?DbPAR=BASIC">Instrución DefVar</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03104300.html?DbPAR=BASIC">Función DimArray</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020404.html?DbPAR=BASIC">Función Dir</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03110100.html?DbPAR=BASIC">Operadores de comparación</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090404.html?DbPAR=BASIC">Instrución End</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03130800.html?DbPAR=BASIC">Función Environ</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020301.html?DbPAR=BASIC">Función Eof</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03104600.html?DbPAR=BASIC">Función EqualUnoObjects</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03050100.html?DbPAR=BASIC">Función Erl</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03050200.html?DbPAR=BASIC">Función Err</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03050300.html?DbPAR=BASIC">Función Error</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funcións de tratamento de erros</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090412.html?DbPAR=BASIC">Instrución Exit</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080201.html?DbPAR=BASIC">Función Exp</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020405.html?DbPAR=BASIC">Function FileAttr</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020406.html?DbPAR=BASIC">Instrución FileCopy</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020407.html?DbPAR=BASIC">Función FileDateTime</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020415.html?DbPAR=BASIC">Function FileExists</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020408.html?DbPAR=BASIC">Función FileLen</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103800.html?DbPAR=BASIC">Función FindObject</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103900.html?DbPAR=BASIC">Función FindPropertyObject</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080501.html?DbPAR=BASIC">Función Fix</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020102.html?DbPAR=BASIC">Función FreeFile</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090405.html?DbPAR=BASIC">Función FreeLibrary</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090406.html?DbPAR=BASIC">Función Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090400.html?DbPAR=BASIC">Instrucións adicionais</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080300.html?DbPAR=BASIC">Xeración de números aleatorios</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020409.html?DbPAR=BASIC">Function GetAttr</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03132500.html?DbPAR=BASIC">Función GetDefaultContext</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03132100.html?DbPAR=BASIC">Función GetGuiType</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03131000.html?DbPAR=BASIC">Función GetSolarVersion</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03130700.html?DbPAR=BASIC">Función GetSystemTick</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020201.html?DbPAR=BASIC">Instrución Get</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103450.html?DbPAR=BASIC">Instrución Global</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090301.html?DbPAR=BASIC">Instrución GoSub...Return</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090302.html?DbPAR=BASIC">Instrución GoTo</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03010302.html?DbPAR=BASIC">Función Green</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03104400.html?DbPAR=BASIC">Función HasUnoInterfaces</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080801.html?DbPAR=BASIC">Función Hex</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030201.html?DbPAR=BASIC">Función Hour</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120401.html?DbPAR=BASIC">Función InStr</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03010201.html?DbPAR=BASIC">Función InputBox</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020202.html?DbPAR=BASIC">Instrución Input#</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080502.html?DbPAR=BASIC">Función Int</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102200.html?DbPAR=BASIC">Función IsArray</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102300.html?DbPAR=BASIC">Función IsDate</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102400.html?DbPAR=BASIC">Función IsEmpty</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102450.html?DbPAR=BASIC">Función IsError</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03104000.html?DbPAR=BASIC">Función IsMissing</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102700.html?DbPAR=BASIC">Función IsNumeric</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102800.html?DbPAR=BASIC">Función IsObject</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03104500.html?DbPAR=BASIC">Función IsUnoStruct</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120315.html?DbPAR=BASIC">Función Join</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020410.html?DbPAR=BASIC">Instrución Kill</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102900.html?DbPAR=BASIC">Función LBound</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120302.html?DbPAR=BASIC">Función LCase</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120304.html?DbPAR=BASIC">Instrución LSet</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120305.html?DbPAR=BASIC">Función LTrim</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120303.html?DbPAR=BASIC">Función Left</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120402.html?DbPAR=BASIC">Función Len</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103100.html?DbPAR=BASIC">Instrución Let</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input # Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020302.html?DbPAR=BASIC">Función Loc</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020303.html?DbPAR=BASIC">Función Lof</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080202.html?DbPAR=BASIC">Función Log</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030202.html?DbPAR=BASIC">Función Minute</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020411.html?DbPAR=BASIC">Instrución MkDir</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030104.html?DbPAR=BASIC">Función Month</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03010101.html?DbPAR=BASIC">Instrución MsgBox</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020412.html?DbPAR=BASIC">Instrución Name</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030203.html?DbPAR=BASIC">Función Now</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funcións numéricas</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080802.html?DbPAR=BASIC">Función Oct</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020103.html?DbPAR=BASIC">Instrución Open</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103200.html?DbPAR=BASIC">Instrución Option Base</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103300.html?DbPAR=BASIC">Instrución Option Explicit</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103400.html?DbPAR=BASIC">Instrución Public</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080301.html?DbPAR=BASIC">Instrución Randomize</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03102101.html?DbPAR=BASIC">Instrución ReDim</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03010303.html?DbPAR=BASIC">Función Red</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/replace.html?DbPAR=BASIC">Función Replace</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020104.html?DbPAR=BASIC">Instrución Reset</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120307.html?DbPAR=BASIC">Función Right</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020413.html?DbPAR=BASIC">Instrución RmDir</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080302.html?DbPAR=BASIC">Función Rnd</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120308.html?DbPAR=BASIC">Instrución RSet</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120309.html?DbPAR=BASIC">Función RTrim</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030204.html?DbPAR=BASIC">Función Second</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020304.html?DbPAR=BASIC">Función Seek</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020414.html?DbPAR=BASIC">Instrución SetAttr</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080701.html?DbPAR=BASIC">Función Sgn</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03130500.html?DbPAR=BASIC">Función Shell</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080103.html?DbPAR=BASIC">Función Sin</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080401.html?DbPAR=BASIC">Función Sqr</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080400.html?DbPAR=BASIC">Cálculo de raíz cadrada</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103500.html?DbPAR=BASIC">Instrución Static</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090408.html?DbPAR=BASIC">Instrución Stop</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120403.html?DbPAR=BASIC">Función StrComp</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120103.html?DbPAR=BASIC">Función Str</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090409.html?DbPAR=BASIC">Instrución Sub</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090410.html?DbPAR=BASIC">Función Switch</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080104.html?DbPAR=BASIC">Función Tan</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030205.html?DbPAR=BASIC">Función TimeSerial</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030206.html?DbPAR=BASIC">Función TimeValue</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030303.html?DbPAR=BASIC">Función Timer</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03080100.html?DbPAR=BASIC">Funcións trigonométricas</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120311.html?DbPAR=BASIC">Función Trim</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03131300.html?DbPAR=BASIC">Función TwipsPerPixelX</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03131400.html?DbPAR=BASIC">Función TwipsPerPixelY </a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03103000.html?DbPAR=BASIC">Función UBound</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120310.html?DbPAR=BASIC">Función UCase</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03120104.html?DbPAR=BASIC">Función Val</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03130600.html?DbPAR=BASIC">Instrución Wait</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030105.html?DbPAR=BASIC">Función WeekDay</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03090411.html?DbPAR=BASIC">Instrución With</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03020205.html?DbPAR=BASIC">Instrución Write</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03030106.html?DbPAR=BASIC">Función Year</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03070100.html?DbPAR=BASIC">Operador «-»</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03070200.html?DbPAR=BASIC">Operador «*»</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03070300.html?DbPAR=BASIC">Operador «+»</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03070400.html?DbPAR=BASIC">Operador «/»</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03070500.html?DbPAR=BASIC">Operador «^»</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Bibliotecas avanzadas en BASIC</label><ul>\
    <li><a target="_top" href="gl/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Biblioteca Tools</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Biblioteca DEPOT</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Biblioteca EURO</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Biblioteca FORMWIZARD</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Biblioteca GIMMICKS</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Biblioteca SCHEDULE</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Biblioteca SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Biblioteca TEMPLATE</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guías</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/macro_recording.html?DbPAR=BASIC">Gravar macros</a></li>\
    <li><a target="_top" href="gl/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Modificación das propiedades dos controis no editor de caixas de diálogo</a></li>\
    <li><a target="_top" href="gl/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Creación de controis no Editor de caixas de diálogo</a></li>\
    <li><a target="_top" href="gl/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Exemplos de programación para controis no Editor de caixas de diálogo</a></li>\
    <li><a target="_top" href="gl/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="gl/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Creación de caixas de diálogo de Basic</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01030400.html?DbPAR=BASIC">Organizar bibliotecas e módulos</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01020100.html?DbPAR=BASIC">Usar variábeis</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01020200.html?DbPAR=BASIC">Uso de obxectos</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01030300.html?DbPAR=BASIC">Depurar un programa en Basic</a></li>\
    <li><a target="_top" href="gl/text/sbasic/shared/01040000.html?DbPAR=BASIC">Macros executadas por eventos</a></li>\
    <li><a target="_top" href="gl/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="gl/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Do Basica para o Python</a></li>\
    <li><a target="_top" href="gl/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Axuda para scripts en Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Información xeral e uso da interface do usuario</label><ul>\
    <li><a target="_top" href="gl/text/sbasic/python/main0000.html?DbPAR=BASIC">Scripts en Python</a></li>\
    <li><a target="_top" href="gl/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE para Python</a></li>\
    <li><a target="_top" href="gl/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="gl/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programar con Python</label><ul>\
    <li><a target="_top" href="gl/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="gl/text/sbasic/python/python_examples.html?DbPAR=BASIC">Exemplos en Python</a></li>\
    <li><a target="_top" href="gl/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Do Python ao Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Instalación do LibreOffice</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Cambiar a asociación dos tipos de documentos de Microsoft Office</a></li>\
    <li><a target="_top" href="gl/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Safe Mode</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Temas de axuda frecuentes</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Información xeral</label><ul>\
    <li><a target="_top" href="gl/text/shared/main0400.html?DbPAR=SHARED">Teclas de atallo</a></li>\
    <li><a target="_top" href="gl/text/shared/00/00000005.html?DbPAR=SHARED">Glosario xeral</a></li>\
    <li><a target="_top" href="gl/text/shared/00/00000002.html?DbPAR=SHARED">Glosario de termos da internet</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/accessibility.html?DbPAR=SHARED">Accesibilidade en LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/keyboard.html?DbPAR=SHARED">Atallos (Accesibilidade de LibreOffice)</a></li>\
    <li><a target="_top" href="gl/text/shared/04/01010000.html?DbPAR=SHARED">Teclas de atallo xerais en LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/version_number.html?DbPAR=SHARED">Versións e números de compilación</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice e Microsoft Office</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/ms_user.html?DbPAR=SHARED">Utilización de Microsoft Office e de LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Comparación de termos de Microsoft Office e LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Sobre a conversión de documentos de Microsoft Office</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Cambiar a asociación dos tipos de documentos de Microsoft Office</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Opcións de LibreOffice</label><ul>\
    <li><a target="_top" href="gl/text/shared/optionen/01000000.html?DbPAR=SHARED">Opcións</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01010100.html?DbPAR=SHARED">Datos do usuario</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01010200.html?DbPAR=SHARED">Xeral</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01010300.html?DbPAR=SHARED">Camiños</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01010400.html?DbPAR=SHARED">Recursos ortográficos</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01010600.html?DbPAR=SHARED">Xeral</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01010700.html?DbPAR=SHARED">Tipos de letra</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01010800.html?DbPAR=SHARED">Ver</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01010900.html?DbPAR=SHARED">Opcións de impresión</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01012000.html?DbPAR=SHARED">Application Colors</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01013000.html?DbPAR=SHARED">Accesibilidade</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/java.html?DbPAR=SHARED">Avanzado</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">IDE de Basic</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/opencl.html?DbPAR=SHARED">Open CL</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01020000.html?DbPAR=SHARED">Opcións de Cargar/Gardar</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01030000.html?DbPAR=SHARED">Opcións da internet</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01040000.html?DbPAR=SHARED">Opcións de documentos de texto</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01050000.html?DbPAR=SHARED">Opcións de documentos HTML</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01060000.html?DbPAR=SHARED">Opcións de folla de cálculo</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01070000.html?DbPAR=SHARED">Opcións de presentación</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01080000.html?DbPAR=SHARED">Opcións de debuxo</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01090000.html?DbPAR=SHARED">Fórmula</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01110000.html?DbPAR=SHARED">Opcións de gráfica</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01130100.html?DbPAR=SHARED">Propiedades VBA</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01140000.html?DbPAR=SHARED">Idiomas</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01150000.html?DbPAR=SHARED">Opcións de configuración de idioma</a></li>\
    <li><a target="_top" href="gl/text/shared/optionen/01160000.html?DbPAR=SHARED">Opcións de fontes de datos</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Asistentes</label><ul>\
    <li><a target="_top" href="gl/text/shared/autopi/01000000.html?DbPAR=SHARED">Asistente</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Asistente de cartas</label><ul>\
    <li><a target="_top" href="gl/text/shared/autopi/01010000.html?DbPAR=SHARED">Asistente de cartas</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Asistente de fax</label><ul>\
    <li><a target="_top" href="gl/text/shared/autopi/01020000.html?DbPAR=SHARED">Asistente de fax</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Asistente de axendas</label><ul>\
    <li><a target="_top" href="gl/text/shared/autopi/01040000.html?DbPAR=SHARED">Asistente de axendas</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Asistente para exportar a HTML</label><ul>\
    <li><a target="_top" href="gl/text/shared/autopi/01110000.html?DbPAR=SHARED">Exportar HTML</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Asistente para converter documentos</label><ul>\
    <li><a target="_top" href="gl/text/shared/autopi/01130000.html?DbPAR=SHARED">Conversor de documentos</a></li>\
			</ul></li>\
    <li><a target="_top" href="gl/text/shared/autopi/01150000.html?DbPAR=SHARED">Asistente de conversión de euros</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configuración de LibreOffice</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/configure_overview.html?DbPAR=SHARED">Configuración de LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/shared/01/packagemanager.html?DbPAR=SHARED">Xestor de extensións</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/flat_icons.html?DbPAR=SHARED">Cambiar a visualización de icona</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Engadir botóns a barras de ferramentas</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/workfolder.html?DbPAR=SHARED">Changing Your Working Directory</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/standard_template.html?DbPAR=SHARED">Cambiar modelos predefinidos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Rexistrar axendas de enderezos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/formfields.html?DbPAR=SHARED">Inserir e editar botóns</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Traballar coa interface do usuario</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navegar para chegar a obxectos con rapidez</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/navigator.html?DbPAR=SHARED">Navegador para a visión xeral de documento</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/autohide.html?DbPAR=SHARED">Mostrar, ancorar e ocultar xanelas</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/textmode_change.html?DbPAR=SHARED">Alternar entre os modos inserir e sobrescribir</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Uso das barras de ferramentas</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Sinaturas dixitais</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Sobre as sinaturas dixitais</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Aplicación de sinaturas dixitais</a></li>\
    <li><a target="_top" href="gl/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="gl/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="gl/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="gl/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Imprimir, faxes e envíos</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/labels_database.html?DbPAR=SHARED">Imprimir etiquetas de enderezos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Imprimir en branco e negro</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/email.html?DbPAR=SHARED">Enviar documentos como correos electrónicos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/fax.html?DbPAR=SHARED">Enviar fax e configurar LibreOffice para o envío de fax</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Arrastrar e soltar</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/dragdrop.html?DbPAR=SHARED">Arrastrar e soltar en documentos de LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Mover e copiar texto en documentos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copiar áreas de follas de cálculo a documentos de texto</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copiar imaxes entre documentos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Copiar imaxes da galería</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Arrastrar e soltar mediante a visualización de fonte de datos</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copiar e pegar</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Copiar obxectos de debuxo noutros documentos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copiar imaxes entre documentos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Copiar imaxes da galería</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copiar áreas de follas de cálculo a documentos de texto</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Gráficos e diagramas</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/chart_insert.html?DbPAR=SHARED">Inserir gráficas</a></li>\
    <li><a target="_top" href="gl/text/schart/main0000.html?DbPAR=SHARED">Gráficas en LibreOffice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Cargar, gardar, importar, exportar, PDF</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/doc_open.html?DbPAR=SHARED">Abrir documentos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/import_ms.html?DbPAR=SHARED">Abrir documentos gardados noutros formatos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/doc_save.html?DbPAR=SHARED">Gardar documentos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Gardar documentos automaticamente</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/export_ms.html?DbPAR=SHARED">Gardar documentos noutros formatos</a></li>\
    <li><a target="_top" href="gl/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Exportar como PDF</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Importar e exportar datos en formato texto</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Ligazóns e referencias</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Inserir hiperligazóns</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Ligazóns relativas e absolutas</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Editar hiperligazóns</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Seguimento das versións do documento</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Comparar versións de documentos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Combinar versións</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Rexistrar cambios</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/redlining.html?DbPAR=SHARED">Rexistrar e visualizar cambios</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Aceptar ou rexeitar cambios</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Xestión de versións</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etiquetas e cartóns de visita</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/labels.html?DbPAR=SHARED">Crear e imprimir etiquetas e tarxetas de visita</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Inserir datos externos</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/copytable2application.html?DbPAR=SHARED">Inserir datos de follas de cálculo</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/copytext2application.html?DbPAR=SHARED">Inserir datos de documentos de texto</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Inserir, editar e gardar mapas de bits</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Engadir imaxes á galería</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Funcións automáticas</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Desactivar automaticamente o recoñecemento de URL</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Buscar e substituír</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/data_search2.html?DbPAR=SHARED">Buscar cun filtro de formulario</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_search.html?DbPAR=SHARED">Buscar táboas e documentos de formulario</a></li>\
    <li><a target="_top" href="gl/text/shared/01/02100001.html?DbPAR=SHARED">Lista de expresións regulares</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guías</label><ul>\
    <li><a target="_top" href="gl/text/shared/guide/linestyles.html?DbPAR=SHARED">Aplicar estilos de liña</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/text_color.html?DbPAR=SHARED">Cambiar a cor do texto</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/change_title.html?DbPAR=SHARED">Cambiar o título dun documento</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/round_corner.html?DbPAR=SHARED">Crear cantos arredondados</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/background.html?DbPAR=SHARED">Definir cores ou imaxes de fondo</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/lineend_define.html?DbPAR=SHARED">Definir fins de liña</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Definir estilos de liña</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Editar obxectos gráficos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/line_intext.html?DbPAR=SHARED">Debuxar liñas no texto</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/aaa_start.html?DbPAR=SHARED">Primeiros pasos</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserir obxectos da galería</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Inserir caracteres especiais</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/tabs.html?DbPAR=SHARED">Inserir e editar tabulacións</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/protection.html?DbPAR=SHARED">Protexer o contido en LibreOffice</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Protexer rexistros</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Seleccionar a máxima área imprimíbel dunha páxina</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/measurement_units.html?DbPAR=SHARED">Seleccionar unidades de medida</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/language_select.html?DbPAR=SHARED">Seleccionar o idioma do documento</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Deseño de táboa</a></li>\
    <li><a target="_top" href="gl/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Desactivar viñetas e numeración de parágrafos individuais</a></li>\
		</ul></li>\
	</ul></li></ul>\
';
