document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Besedilni dokumenti (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Splošni podatki in uporabniški vmesnik</label><ul>\
    <li><a target="_top" href="sl/text/swriter/main0000.html?DbPAR=WRITER">Dobrodošli v pomoči za LibreOffice Writer</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0503.html?DbPAR=WRITER">Kaj ponuja LibreOffice Writer</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/main.html?DbPAR=WRITER">Navodila za uporabo programa LibreOffice Writer</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Sidranje in spreminjanje velikosti oken</a></li>\
    <li><a target="_top" href="sl/text/swriter/04/01020000.html?DbPAR=WRITER">Tipke za bližnjice za LibreOffice Writer</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/words_count.html?DbPAR=WRITER">Štetje besed</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/keyboard.html?DbPAR=WRITER">Uporaba tipk za bližnjico (dostopnost LibreOffice Writer)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Pregled ukazov in menijev</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Meniji</label><ul>\
    <li><a target="_top" href="sl/text/swriter/main0100.html?DbPAR=WRITER">Meniji</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0101.html?DbPAR=WRITER">Datoteka</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0102.html?DbPAR=WRITER">Uredi</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0103.html?DbPAR=WRITER">Pogled</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0104.html?DbPAR=WRITER">Vstavi</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0105.html?DbPAR=WRITER">Oblika</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0115.html?DbPAR=WRITER">Slogi</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0110.html?DbPAR=WRITER">Tabela</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0120.html?DbPAR=WRITER">Meni Obrazec</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0106.html?DbPAR=WRITER">Orodja</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0107.html?DbPAR=WRITER">Okno</a></li>\
    <li><a target="_top" href="sl/text/shared/main0108.html?DbPAR=WRITER">Pomoč</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Orodne vrstice</label><ul>\
    <li><a target="_top" href="sl/text/swriter/main0200.html?DbPAR=WRITER">Orodne vrstice</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0202.html?DbPAR=WRITER">Vrstica Oblikovanje</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0203.html?DbPAR=WRITER">Vrstica Slika</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0204.html?DbPAR=WRITER">Vrstica Tabela</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0205.html?DbPAR=WRITER">Vrstica Lastnosti risanega predmeta</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0206.html?DbPAR=WRITER">Vrstica Označevanje in oštevilčevanje</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0208.html?DbPAR=WRITER">Vrstica stanja</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0210.html?DbPAR=WRITER">Predogled tiskanja</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0213.html?DbPAR=WRITER">Ravnila</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0214.html?DbPAR=WRITER">Vrstica za formule</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0215.html?DbPAR=WRITER">Vrstica Okvir</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0216.html?DbPAR=WRITER">Vrstica Predmet OLE</a></li>\
    <li><a target="_top" href="sl/text/swriter/main0220.html?DbPAR=WRITER">Vrstica Besedilni predmet</a></li>\
    <li><a target="_top" href="sl/text/shared/main0201.html?DbPAR=WRITER">Standardna vrstica</a></li>\
    <li><a target="_top" href="sl/text/shared/main0212.html?DbPAR=WRITER">Vrstica Podatki tabele</a></li>\
    <li><a target="_top" href="sl/text/shared/main0213.html?DbPAR=WRITER">Vrstica Krmarjenje po obrazcu</a></li>\
    <li><a target="_top" href="sl/text/shared/main0214.html?DbPAR=WRITER">Vrstica Oblikovanje poizvedbe</a></li>\
    <li><a target="_top" href="sl/text/shared/main0226.html?DbPAR=WRITER">Orodna vrstica Oblikovanje obrazca</a></li>\
    <li><a target="_top" href="sl/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Orodna vrstica LibreLogo</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">Ustvarjanje besedilnih dokumentov</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Krmarjenje in izbiranje z uporabo tipkovnice</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Uporaba neposredne kazalke</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Slike v dokumentih z besedilom</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Vstavljanje slik</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Vstavljanje slike iz datoteke</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Vstavljanje slike iz galerije z načinom povleci in spusti</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Vstavljanje optično prebrane slike</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Vstavljanje grafikona iz programa Calc v dokument z besedilom</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Vstavljanje grafike iz programov LibreOffice Draw ali Impress</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabele v dokumentih z besedilom</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Vklop in izklop prepoznavanja števil v tabelah</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/tablemode.html?DbPAR=WRITER">Spreminjanje vrstic in stolpcev z uporabo tipkovnice</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/table_delete.html?DbPAR=WRITER">Brisanje tabel ali vsebine tabele</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/table_insert.html?DbPAR=WRITER">Vstavljanje tabel</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Ponovitev glave tabele na novi strani</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Spreminjanje velikosti vrstic ali stolpcev v besedilni tabeli</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Predmeti v besedilnih dokumentih</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Umeščanje predmetov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/wrap.html?DbPAR=WRITER">Oblivanje besedila okrog predmetov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Razdelki in okviri v dokumentih z besedilom</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/sections.html?DbPAR=WRITER">Uporaba odsekov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/text_frame.html?DbPAR=WRITER">Vstavljanje, urejanje in povezovanje okvirov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/section_edit.html?DbPAR=WRITER">Urejanje odsekov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/section_insert.html?DbPAR=WRITER">Vstavljanje odsekov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Kazala</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Oštevilčevanje poglavij</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Uporabniško določena kazala</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Ustvarjanje kazala vsebine</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/indices_index.html?DbPAR=WRITER">Ustvarjanje abecednih kazal</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Kazala, ki zajemajo več dokumentov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Ustvarjanje bibliografije</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Urejanje ali brisanje vnosov v kazala</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Posodabljanje, urejanje in brisanje kazal</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Določanje vnosov v kazalu vsebine</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/indices_form.html?DbPAR=WRITER">Oblikovanje kazala vsebine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Polja v besedilnih dokumentih</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/fields.html?DbPAR=WRITER">Polja</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/fields_date.html?DbPAR=WRITER">Vstavljanje polja s fiksnim ali spremenljivim datumom</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/field_convert.html?DbPAR=WRITER">Pretvarjanje polja v besedilo</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Krmarjenje po dokumentih z besedilom</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Premikanje in kopiranje besedila v dokumentih</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Prerazporeditev dokumenta z uporabo Krmarja</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Vstavljanje hiperpovezav s pomočjo Krmarja</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/navigator.html?DbPAR=WRITER">Krmar za dokumente z besedilom</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Računanje v dokumentih z besedilom</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Računanje med tabelami</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/calculate.html?DbPAR=WRITER">Računanje v dokumentih z besedilom</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Računanje in lepljenje rezultata formule v dokument z besedilom</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Računanje vsote celic v tabelah</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Računanje sestavljenih formul v dokumentih z besedilom</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Prikaz rezultata izračuna tabele v drugi tabeli</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Oblikovanje dokumentov z besedilom</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">Predloge in slogi</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Predloge in slogi</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Izmenjujoči slogi strani na sodih in lihih straneh</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/change_header.html?DbPAR=WRITER">Ustvarjanje sloga strani na osnovi trenutne strani</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/load_styles.html?DbPAR=WRITER">Uporaba slogov iz drugega dokumenta ali predloge</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Uporaba novih slogov iz izborov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Posodabljanje slogov iz izborov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/template_create.html?DbPAR=WRITER">Ustvarjanje predloge dokumenta</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/template_default.html?DbPAR=WRITER">Spreminjanje privzete predloge</a></li>\
			</ul></li>\
    <li><a target="_top" href="sl/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Spreminjanje usmerjenosti strani (ležeče ali pokončno)</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/text_capital.html?DbPAR=WRITER">Spreminjanje velikosti črk v besedilu</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Skrivanje besedila</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Določitev različnih glav in nog</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Vstavljanje imena poglavja in številke v glavo ali nogo</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Uporaba oblikovanja besedila med vnašanjem</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/reset_format.html?DbPAR=WRITER">Ponastavljanje atributov pisave</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Uporaba slogov z načinom kopiranja slogov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/wrap.html?DbPAR=WRITER">Oblivanje besedila okrog predmetov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Uporaba okvira za sredinsko poravnavo besedila na strani</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Poudarjanje besedila</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Sukanje besedila</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/page_break.html?DbPAR=WRITER">Vstavljanje in brisanje prelomov strani</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Ustvarjanje in uporaba slogov strani</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/subscript.html?DbPAR=WRITER">Nadpisano ali podpisano besedilo</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Posebni elementi besedila</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/captions.html?DbPAR=WRITER">Uporaba napisov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Pogojno besedilo</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Pogojno besedilo za število strani</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/fields_date.html?DbPAR=WRITER">Vstavljanje polja s fiksnim ali spremenljivim datumom</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Dodajanje vnosnih polj</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Vstavljanje številk strani na naslednjih straneh</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Vstavljanje številk strani v noge</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Skrivanje besedila</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Določitev različnih glav in nog</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Vstavljanje imena poglavja in številke v glavo ali nogo</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Poizvedovanje po uporabniških podatkih v poljih ali pogojih</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Vstavljanje in urejanje sprotnih in končnih opomb</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Razmik med sprotnimi opombami</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/header_footer.html?DbPAR=WRITER">O glavah in nogah</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Oblikovanje glav in nog</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/text_animation.html?DbPAR=WRITER">Animiranje besedila</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Ustvarjanje tipskega pisma</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Samodejne funkcije</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Dodajanje izjem na seznam samopopravkov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/autotext.html?DbPAR=WRITER">Uporaba samobesedila</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Ustvarjanje oštevilčenega ali označenega seznama med vnašanjem</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/auto_off.html?DbPAR=WRITER">Izklop samopopravkov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Samodejno preveri črkovanje</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Vklop in izklop prepoznavanja števil v tabelah</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Deljenje besed</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Oštevilčevanje in seznami</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Dodajanje številk poglavij k napisom</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Ustvarjanje oštevilčenega ali označenega seznama med vnašanjem</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Oštevilčevanje poglavij</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Spreminjanje ravni poglavij pri oštevilčenih in označenih seznamih</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Združevanje oštevilčenih seznamov</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Dodajanje številk vrstic</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Spreminjanje oštevilčevanja v oštevilčenem seznamu</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Določanje obsega števil</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Dodajanje oštevilčevanja</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Oštevilčevanje in slogi oštevilčevanja</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Dodajanje oznak</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Preverjanje črkovanja, slovar sopomenk in jeziki</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Samodejno preveri črkovanje</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Odstranjevanje besed iz uporabniško določenega slovarja</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Slovar sopomenk</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Preverjanje črkovanja in slovnične pravilnosti</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Nasveti za reševanje težav</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Vstavljanje besedila pred tabelo na vrhu strani</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Pot do določenega zaznamka</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Nalaganje, shranjevanje, uvažanje, izvažanje in prekrivanje podatkov</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/send2html.html?DbPAR=WRITER">Shranjevanje dokumentov z besedilom v obliki HTML</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Vstavljanje celotnega dokumenta z besedilom</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/redaction.html?DbPAR=WRITER">Prekrivanje podatkov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Glavni dokumenti</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Glavni dokumenti in poddokumenti</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Povezave in sklici</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/references.html?DbPAR=WRITER">Vstavljanje navzkrižnega sklicevanja</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Vstavljanje hiperpovezav s pomočjo Krmarja</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Tiskanje</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Izbiranje tiskalnikovega pladnja za papir</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/print_preview.html?DbPAR=WRITER">Predogled strani pred tiskanjem</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/print_small.html?DbPAR=WRITER">Tiskanje več strani na enem listu</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Ustvarjanje in uporaba slogov strani</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Iskanje in zamenjevanje</label><ul>\
    <li><a target="_top" href="sl/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Uporaba regularnih izrazov pri iskanju po besedilu</a></li>\
    <li><a target="_top" href="sl/text/shared/01/02100001.html?DbPAR=WRITER">Seznam regularnih izrazov</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">Dokumenti HTML (Writer/Web)</label><ul>\
    <li><a target="_top" href="sl/text/shared/07/09000000.html?DbPAR=WRITER">Spletne strani</a></li>\
    <li><a target="_top" href="sl/text/shared/02/01170700.html?DbPAR=WRITER">Filtri in obrazci HTML</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/send2html.html?DbPAR=WRITER">Shranjevanje dokumentov z besedilom v obliki HTML</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Preglednice (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Splošni podatki in uporabniški vmesnik</label><ul>\
    <li><a target="_top" href="sl/text/scalc/main0000.html?DbPAR=CALC">Dobrodošli v pomoči za LibreOffice Calc</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0503.html?DbPAR=CALC">Kaj ponuja LibreOffice Calc</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/keyboard.html?DbPAR=CALC">Tipke za bližnjice (Dostopnost LibreOffice Calc)</a></li>\
    <li><a target="_top" href="sl/text/scalc/04/01020000.html?DbPAR=CALC">Tipke za bližnjice za delo s preglednicami</a></li>\
    <li><a target="_top" href="sl/text/scalc/05/02140000.html?DbPAR=CALC">Šifre napak v LibreOffice Calc</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060112.html?DbPAR=CALC">Dodatek za programiranje v modulu LibreOffice Calc</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/main.html?DbPAR=CALC">Navodila za uporabo programa LibreOffice Calc</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Pregled ukazov in menijev</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Meniji</label><ul>\
    <li><a target="_top" href="sl/text/scalc/main0100.html?DbPAR=CALC">Meniji</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0101.html?DbPAR=CALC">Datoteka</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0102.html?DbPAR=CALC">Uredi</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0103.html?DbPAR=CALC">Pogled</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0104.html?DbPAR=CALC">Vstavi</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0105.html?DbPAR=CALC">Oblika</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0116.html?DbPAR=CALC">Delovni list</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0112.html?DbPAR=CALC">Podatki</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0106.html?DbPAR=CALC">Orodja</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0107.html?DbPAR=CALC">Okno</a></li>\
    <li><a target="_top" href="sl/text/shared/main0108.html?DbPAR=CALC">Pomoč</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Orodne vrstice</label><ul>\
    <li><a target="_top" href="sl/text/scalc/main0200.html?DbPAR=CALC">Orodne vrstice</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0202.html?DbPAR=CALC">Vrstica Oblikovanje</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0203.html?DbPAR=CALC">Vrstica Lastnosti risanega predmeta</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0205.html?DbPAR=CALC">Vrstica Oblikovanje besedila</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0206.html?DbPAR=CALC">Vrstica za formule</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0208.html?DbPAR=CALC">Vrstica stanja</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0210.html?DbPAR=CALC">Vrstica Predogled tiskanja</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0214.html?DbPAR=CALC">Vrstica Slika</a></li>\
    <li><a target="_top" href="sl/text/scalc/main0218.html?DbPAR=CALC">Vrstica Orodja</a></li>\
    <li><a target="_top" href="sl/text/shared/main0201.html?DbPAR=CALC">Standardna vrstica</a></li>\
    <li><a target="_top" href="sl/text/shared/main0212.html?DbPAR=CALC">Vrstica Podatki tabele</a></li>\
    <li><a target="_top" href="sl/text/shared/main0213.html?DbPAR=CALC">Vrstica Krmarjenje po obrazcu</a></li>\
    <li><a target="_top" href="sl/text/shared/main0214.html?DbPAR=CALC">Vrstica Oblikovanje poizvedbe</a></li>\
    <li><a target="_top" href="sl/text/shared/main0226.html?DbPAR=CALC">Orodna vrstica Oblikovanje obrazca</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Vrste funkcij in operatorji</label><ul>\
    <li><a target="_top" href="sl/text/scalc/01/04060000.html?DbPAR=CALC">Čarovnik za funkcije</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060100.html?DbPAR=CALC">Funkcije po kategorijah</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060107.html?DbPAR=CALC">Funkcije za matrike</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060120.html?DbPAR=CALC">Funkcije bitnih operacij</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060101.html?DbPAR=CALC">Funkcije za delo z zbirkami podatkov</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060102.html?DbPAR=CALC">Funkcije datuma in časa</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060103.html?DbPAR=CALC">Finančne funkcije – Prvi del</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060119.html?DbPAR=CALC">Finančne funkcije – Drugi del</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060118.html?DbPAR=CALC">Finančne funkcije – Tretji del</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060104.html?DbPAR=CALC">Informacijske funkcije</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060105.html?DbPAR=CALC">Logične funkcije</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060106.html?DbPAR=CALC">Matematične funkcije</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060108.html?DbPAR=CALC">Statistične funkcije</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060181.html?DbPAR=CALC">Statistične funkcije prvi del</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060182.html?DbPAR=CALC">Statistične funkcije drugi del</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060183.html?DbPAR=CALC">Statistične funkcije – Tretji del</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060184.html?DbPAR=CALC">Statistične funkcije – Četrti del</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060185.html?DbPAR=CALC">Statistične funkcije – Peti del</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060109.html?DbPAR=CALC">Funkcije preglednice</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060110.html?DbPAR=CALC">Funkcije za besedilo</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060111.html?DbPAR=CALC">Funkcije dodatkov</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060115.html?DbPAR=CALC">Funkcije dodatkov, seznam funkcij za analizo – I. del</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060116.html?DbPAR=CALC">Funkcije dodatkov, seznam funkcij za analizo – II. del</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/04060199.html?DbPAR=CALC">Operatorji v programu LibreOffice Calc</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Uporabniško določene funkcije</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Nalaganje, shranjevanje, uvažanje, izvažanje in prekrivanje podatkov</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/webquery.html?DbPAR=CALC">Vnašanje zunanjih podatkov v tabelo (Poizvedba spletnih strani)</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/html_doc.html?DbPAR=CALC">Shranjevanje in odpiranje delovnih listov v HTML-ju</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/csv_formula.html?DbPAR=CALC">Uvažanje in izvažanje datotek z besedilom</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/redaction.html?DbPAR=CALC">Prekrivanje podatkov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Oblikovanje</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/text_rotate.html?DbPAR=CALC">Sukanje besedila</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/text_wrap.html?DbPAR=CALC">Pisanje večvrstičnega besedila</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/text_numbers.html?DbPAR=CALC">Oblikovanje števil kot besedilo</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/super_subscript.html?DbPAR=CALC">Nadpisano/ podpisano besedilo</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/row_height.html?DbPAR=CALC">Spreminjanje višine vrstic ali širine stolpcev</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Uporabljanje pogojnega oblikovanja</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Poudarjanje negativnih števil</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Dodeljevanje oblik s formulo</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Vnašanje števil z vodilnimi ničlami</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/format_table.html?DbPAR=CALC">Oblikovanje preglednic</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/format_value.html?DbPAR=CALC">Oblikovanje števil z decimalkami</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/value_with_name.html?DbPAR=CALC">Poimenovanje celic</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/table_rotate.html?DbPAR=CALC">Sukanje tabel (transponiranje)</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/rename_table.html?DbPAR=CALC">Preimenovanje delovnih listov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/year2000.html?DbPAR=CALC">Letnice 19xx/20xx</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Uporaba zaokroženih števil</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/currency_format.html?DbPAR=CALC">Celice v obliki valute</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/autoformat.html?DbPAR=CALC">Uporaba samooblikovanja za tabele</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/note_insert.html?DbPAR=CALC">Vstavljanje in urejanje komentarjev</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/design.html?DbPAR=CALC">Izbiranje tem za delovne liste</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Vnašanje ulomkov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtriranje in razvrščanje</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/filters.html?DbPAR=CALC">Uporabljanje filtrov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/specialfilter.html?DbPAR=CALC">Filter: Uveljavljanje naprednih filtrov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/autofilter.html?DbPAR=CALC">Uporabljanje samodejnega filtra</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/sorted_list.html?DbPAR=CALC">Uveljavljenje razvrščevalnih seznamov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Tiskanje</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/print_title_row.html?DbPAR=CALC">Tiskanje vrstic in stolpcev na vsaki strani.</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/print_landscape.html?DbPAR=CALC">Tiskanje delovnih strani v ležeči obliki</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/print_details.html?DbPAR=CALC">Podatki o delovnem listu za tiskanje</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/print_exact.html?DbPAR=CALC">Določanje števila strani za tiskanje</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Obsegi podatkov</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/database_define.html?DbPAR=CALC">Določanje obsegov zbirke podatkov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtriranje obsegov celic</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/database_sort.html?DbPAR=CALC">Razvrščanje podatkov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Vrtilna tabela</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/datapilot.html?DbPAR=CALC">Vrtilna tabela</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Ustvarjanje vrtilnih tabel</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Brisanje vrtilnih tabel</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Urejanje vrtilnih tabel</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtriranje vrtilnih tabel</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Izbiranje izhodnih obsegov vrtilne tabele</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Posodabljanje vrtilnih tabel</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Vrtilni grafikon</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/pivotchart.html?DbPAR=CALC">Vrtilni grafikon</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Ustvarjanje vrtilnih grafikonov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Urejanje vrtilnih grafikonov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtriranje vrtilnih grafikonov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Posodabljanje vrtilnega grafikona</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Brisanje vrtilnih grafikonov</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Scenariji</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/scenario.html?DbPAR=CALC">Uporaba scenarijev</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Delne vsote</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Uporaba orodja Delne vsote</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Sklici</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Naslavljanje in sklici, absolutno in relativno</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/cellreferences.html?DbPAR=CALC">Sklicevanje na celico v drugem dokumentu</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Sklici na druge delovne liste in sklicevanje na URL-je</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Sklicevanje na celice z dejanjem Povleci in spusti</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/address_auto.html?DbPAR=CALC">Prepoznavanje imen pri naslavljanju</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Pogled, izbiranje, kopiranje</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/table_view.html?DbPAR=CALC">Spreminjanje prikazov tabele</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/formula_value.html?DbPAR=CALC">Prikaz formul ali vrednosti</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/line_fix.html?DbPAR=CALC">Zamrzovanje vrstic ali stolpcev kot glave</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/multi_tables.html?DbPAR=CALC">Krmarjenje po zavihkih delovnih listov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Kopiranje v več delovnih listov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/cellcopy.html?DbPAR=CALC">Kopiraj samo vidne celice</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/mark_cells.html?DbPAR=CALC">Izbiranje več celic hkrati</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formule in izračuni</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/formulas.html?DbPAR=CALC">Računanje s formulami</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/formula_copy.html?DbPAR=CALC">Kopiranje formul</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/formula_enter.html?DbPAR=CALC">Vnašanje formul</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/formula_value.html?DbPAR=CALC">Prikaz formul ali vrednosti</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/calculate.html?DbPAR=CALC">Računanje v preglednicah</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/calc_date.html?DbPAR=CALC">Računanje z datumi in časom</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/calc_series.html?DbPAR=CALC">Samodejno računanje nizov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Računanje časovnih razlik</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/matrixformula.html?DbPAR=CALC">Vnašanje matričnih formul</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Zaščita</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/cell_protect.html?DbPAR=CALC">Varovanje celic pred spremembami</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Nezaščitenost celic</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Razno</label><ul>\
    <li><a target="_top" href="sl/text/scalc/guide/auto_off.html?DbPAR=CALC">Deaktiviranje samodejnih sprememb</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/consolidate.html?DbPAR=CALC">Usklajevanje podatkov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/goalseek.html?DbPAR=CALC">Uporabljanje iskanja cilja</a></li>\
    <li><a target="_top" href="sl/text/scalc/01/solver.html?DbPAR=CALC">Reševalec</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/multioperation.html?DbPAR=CALC">Uporaba večkratnih operacij</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/multitables.html?DbPAR=CALC">Uporabljanje več delovnih listov</a></li>\
    <li><a target="_top" href="sl/text/scalc/guide/validity.html?DbPAR=CALC">Veljavnost vsebin celic</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Predstavitve (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Splošni podatki in uporabniški vmesnik</label><ul>\
    <li><a target="_top" href="sl/text/simpress/main0000.html?DbPAR=IMPRESS">Dobrodošli v pomoči za LibreOffice Impress</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0503.html?DbPAR=IMPRESS">Kaj ponuja LibreOffice Impress</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Uporaba tipk za bližnjice v LibreOffice Impress</a></li>\
    <li><a target="_top" href="sl/text/simpress/04/01020000.html?DbPAR=IMPRESS">Tipke za bližnjice v LibreOffice Impress</a></li>\
    <li><a target="_top" href="sl/text/simpress/04/presenter.html?DbPAR=IMPRESS">Tipke za bližnjice razširitve Upravljalni zaslon govorca</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/main.html?DbPAR=IMPRESS">Navodila za uporabo LibreOffice Impress</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Pregled ukazov in menijev</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Meniji</label><ul>\
    <li><a target="_top" href="sl/text/simpress/main0100.html?DbPAR=IMPRESS">Meniji</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0101.html?DbPAR=IMPRESS">Datoteka</a></li>\
    <li><a target="_top" href="sl/text/simpress/main_edit.html?DbPAR=IMPRESS">Uredi</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0103.html?DbPAR=IMPRESS">Pogled</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0104.html?DbPAR=IMPRESS">Vstavi</a></li>\
    <li><a target="_top" href="sl/text/simpress/main_format.html?DbPAR=IMPRESS">Oblika</a></li>\
    <li><a target="_top" href="sl/text/simpress/main_slide.html?DbPAR=IMPRESS">Prosojnica</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0114.html?DbPAR=IMPRESS">Projekcija</a></li>\
    <li><a target="_top" href="sl/text/simpress/main_tools.html?DbPAR=IMPRESS">Orodja</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0107.html?DbPAR=IMPRESS">Okno</a></li>\
    <li><a target="_top" href="sl/text/shared/main0108.html?DbPAR=IMPRESS">Pomoč</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Orodne vrstice</label><ul>\
    <li><a target="_top" href="sl/text/simpress/main0200.html?DbPAR=IMPRESS">Orodne vrstice</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0202.html?DbPAR=IMPRESS">Vrstica Črte in polnila</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0203.html?DbPAR=IMPRESS">Vrstica Oblikovanje besedila</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0204.html?DbPAR=IMPRESS">Vrstica Pogled prosojnice</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0206.html?DbPAR=IMPRESS">Vrstica stanja</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0209.html?DbPAR=IMPRESS">Ravnila</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0210.html?DbPAR=IMPRESS">Vrstica Risba</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0211.html?DbPAR=IMPRESS">Vrstica Oris</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0212.html?DbPAR=IMPRESS">Vrstica Pregledovalnik prosojnic</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0213.html?DbPAR=IMPRESS">Vrstica Možnosti</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0214.html?DbPAR=IMPRESS">Vrstica Slika</a></li>\
    <li><a target="_top" href="sl/text/shared/main0201.html?DbPAR=IMPRESS">Standardna vrstica</a></li>\
    <li><a target="_top" href="sl/text/shared/main0213.html?DbPAR=IMPRESS">Vrstica Krmarjenje po obrazcu</a></li>\
    <li><a target="_top" href="sl/text/shared/main0226.html?DbPAR=IMPRESS">Orodna vrstica Oblikovanje obrazca</a></li>\
    <li><a target="_top" href="sl/text/shared/main0227.html?DbPAR=IMPRESS">Vrstica Uredi točke</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Nalaganje, shranjevanje, uvažanje, izvažanje in prekrivanje podatkov</label><ul>\
    <li><a target="_top" href="sl/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Shranjevanje predstavitve v zapisu HTML</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Uvoz strani HTML v predstavitve</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Nalaganje seznamov barv, barvnih prelivov in šrafiranj</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Izvoz animacij v zapisu GIF</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Vključevanje preglednic v prosojnice</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Vstavljanje slik</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Kopiranje prosojnic iz drugih predstavitev</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/redaction.html?DbPAR=IMPRESS">Prekrivanje podatkov</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Oblikovanje</label><ul>\
    <li><a target="_top" href="sl/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Nalaganje seznamov barv, barvnih prelivov in šrafiranj</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Nalaganje slogov črt in puščic</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Določanje lastnih barv</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Ustvarjanje prelivov</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Zamenjava barv</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Razporejanje, poravnavanje in porazdelitev predmetov</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/background.html?DbPAR=IMPRESS">Spreminjanje polnila ozadja prosojnice</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/footer.html?DbPAR=IMPRESS">Dodajanje glave ali noge vsem prosojnicam</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Spreminjanje in dodajanje glavne strani oz. matrice</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Premikanje predmetov</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Tiskanje</label><ul>\
    <li><a target="_top" href="sl/text/simpress/guide/printing.html?DbPAR=IMPRESS">Tiskanje predstavitev</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Tiskanje prosojnice, da ustreza velikosti lista</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Učinki</label><ul>\
    <li><a target="_top" href="sl/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Izvoz animacij v zapisu GIF</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animacija predmetov na prosojnicah predstavitve</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animacija prehodov med prosojnicami</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Preliv dveh predmetov</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Ustvarjanje animiranih slik GIF</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Predmeti, risbe in bitne slike</label><ul>\
    <li><a target="_top" href="sl/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Sestavljanje predmetov in konstruiranje oblik</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Združevanje predmetov</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Risanje izsekov in odsekov</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Podvajanje predmetov</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Sukanje predmetov</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Sestavljanje predmetov 3D</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Povezovanje črt</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Pretvorba črk in znakov v predmete risanja</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Pretvorba bitnih slik v vektorske</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Pretvorba predmetov 2D v krivulje, mnogokotnike in 3D-predmete</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Nalaganje slogov črt in puščic</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Risanje krivulj</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Urejanje krivulj</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Vstavljanje slik</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Vključevanje preglednic v prosojnice</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Premikanje predmetov</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Izbiranje spodaj ležečih predmetov</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Ustvarjanje diagrama poteka</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Besedilo v predstavitvah</label><ul>\
    <li><a target="_top" href="sl/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Dodajanje besedila</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Pretvorba črk in znakov v predmete risanja</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Pogled</label><ul>\
    <li><a target="_top" href="sl/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Spreminjanje vrstnega reda prosojnic</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Povečevanje/pomanjševanje z numerično tipkovnico</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Projekcije</label><ul>\
    <li><a target="_top" href="sl/text/simpress/guide/show.html?DbPAR=IMPRESS">Izvajanje projekcije</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Uporaba upravljalnega zaslona govorca</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Daljinec za Impress</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/individual.html?DbPAR=IMPRESS">Ustvarjanje projekcije po meri</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Vadba časovne usklajenosti menjave prosojnic</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Risbe (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Splošni podatki in uporabniški vmesnik</label><ul>\
    <li><a target="_top" href="sl/text/sdraw/main0000.html?DbPAR=DRAW">Dobrodošli v pomoči za LibreOffice Draw</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main0503.html?DbPAR=DRAW">Kaj ponuja LibreOffice Draw</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Tipke za bližnjice za risane predmete</a></li>\
    <li><a target="_top" href="sl/text/sdraw/04/01020000.html?DbPAR=DRAW">Tipke za bližnjice za risbe</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/main.html?DbPAR=DRAW">Navodila za uporabo LibreOffice Draw</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Pregled ukazov in menijev</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Meniji</label><ul>\
    <li><a target="_top" href="sl/text/sdraw/main0100.html?DbPAR=DRAW">Meniji</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main0101.html?DbPAR=DRAW">Datoteka</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main_edit.html?DbPAR=DRAW">Uredi</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main0103.html?DbPAR=DRAW">Pogled</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main_insert.html?DbPAR=DRAW">Vstavi</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main_format.html?DbPAR=DRAW">Oblika</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main_page.html?DbPAR=DRAW">Stran</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main_shape.html?DbPAR=DRAW">Lik</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main_tools.html?DbPAR=DRAW">Orodja</a></li>\
    <li><a target="_top" href="sl/text/simpress/main0107.html?DbPAR=DRAW">Okno</a></li>\
    <li><a target="_top" href="sl/text/shared/main0108.html?DbPAR=DRAW">Pomoč</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Orodne vrstice</label><ul>\
    <li><a target="_top" href="sl/text/sdraw/main0200.html?DbPAR=DRAW">Orodne vrstice</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main0210.html?DbPAR=DRAW">Vrstica Risba</a></li>\
    <li><a target="_top" href="sl/text/sdraw/main0213.html?DbPAR=DRAW">Vrstica Možnosti</a></li>\
    <li><a target="_top" href="sl/text/shared/main0201.html?DbPAR=DRAW">Standardna vrstica</a></li>\
    <li><a target="_top" href="sl/text/shared/main0213.html?DbPAR=DRAW">Vrstica Krmarjenje po obrazcu</a></li>\
    <li><a target="_top" href="sl/text/shared/main0226.html?DbPAR=DRAW">Orodna vrstica Oblikovanje obrazca</a></li>\
    <li><a target="_top" href="sl/text/shared/main0227.html?DbPAR=DRAW">Vrstica Uredi točke</a></li>\
    <li><a target="_top" href="sl/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">Nastavitve 3D</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Nalaganje, shranjevanje, uvažanje in izvažanje</label><ul>\
    <li><a target="_top" href="sl/text/simpress/guide/palette_files.html?DbPAR=DRAW">Nalaganje seznamov barv, barvnih prelivov in šrafiranj</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Vstavljanje slik</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Oblikovanje</label><ul>\
    <li><a target="_top" href="sl/text/simpress/guide/palette_files.html?DbPAR=DRAW">Nalaganje seznamov barv, barvnih prelivov in šrafiranj</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Nalaganje slogov črt in puščic</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/color_define.html?DbPAR=DRAW">Določanje lastnih barv</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/gradient.html?DbPAR=DRAW">Ustvarjanje prelivov</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Zamenjava barv</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Razporejanje, poravnavanje in porazdelitev predmetov</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/background.html?DbPAR=DRAW">Spreminjanje polnila ozadja prosojnice</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/masterpage.html?DbPAR=DRAW">Spreminjanje in dodajanje glavne strani oz. matrice</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/move_object.html?DbPAR=DRAW">Premikanje predmetov</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Tiskanje</label><ul>\
    <li><a target="_top" href="sl/text/simpress/guide/printing.html?DbPAR=DRAW">Tiskanje predstavitev</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Tiskanje prosojnice, da ustreza velikosti lista</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Učinki</label><ul>\
    <li><a target="_top" href="sl/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Preliv dveh predmetov</a></li>\
    <li><a target="_top" href="sl/text/shared/01/05350000.html?DbPAR=DRAW">3D-učinki</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Predmeti, risbe in bitne slike</label><ul>\
    <li><a target="_top" href="sl/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Sestavljanje predmetov in konstruiranje oblik</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Risanje izsekov in odsekov</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Podvajanje predmetov</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Sukanje predmetov</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Sestavljanje predmetov 3D</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Povezovanje črt</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/text2curve.html?DbPAR=DRAW">Pretvorba črk in znakov v predmete risanja</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/vectorize.html?DbPAR=DRAW">Pretvorba bitnih slik v vektorske</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/3d_create.html?DbPAR=DRAW">Pretvorba predmetov 2D v krivulje, mnogokotnike in 3D-predmete</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Nalaganje slogov črt in puščic</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/line_draw.html?DbPAR=DRAW">Risanje krivulj</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/line_edit.html?DbPAR=DRAW">Urejanje krivulj</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Vstavljanje slik</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/table_insert.html?DbPAR=DRAW">Vključevanje preglednic v prosojnice</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/move_object.html?DbPAR=DRAW">Premikanje predmetov</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/select_object.html?DbPAR=DRAW">Izbiranje spodaj ležečih predmetov</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/orgchart.html?DbPAR=DRAW">Ustvarjanje diagrama poteka</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Skupine in plasti</label><ul>\
    <li><a target="_top" href="sl/text/sdraw/guide/groups.html?DbPAR=DRAW">Združevanje predmetov</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/layers.html?DbPAR=DRAW">O plasteh</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Vstavljanje plasti</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Delo s plastmi</a></li>\
    <li><a target="_top" href="sl/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Premikanje predmetov na drugo plast</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Besedilo v risbah</label><ul>\
    <li><a target="_top" href="sl/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Dodajanje besedila</a></li>\
    <li><a target="_top" href="sl/text/simpress/guide/text2curve.html?DbPAR=DRAW">Pretvorba črk in znakov v predmete risanja</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Pogled</label><ul>\
    <li><a target="_top" href="sl/text/simpress/guide/change_scale.html?DbPAR=DRAW">Povečevanje/pomanjševanje z numerično tipkovnico</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Funkcionalnost zbirke podatkov (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Splošni podatki</label><ul>\
    <li><a target="_top" href="sl/text/sdatabase/main.html?DbPAR=BASE">Zbirka podatkov LibreOffice</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/database_main.html?DbPAR=BASE">Pregled zbirke podatkov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_new.html?DbPAR=BASE">Ustvarjanje nove zbirke podatkov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_tables.html?DbPAR=BASE">Delo s tabelami</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_queries.html?DbPAR=BASE">Delo s poizvedbami</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_forms.html?DbPAR=BASE">Delo z obrazci</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_reports.html?DbPAR=BASE">Ustvarjanje poročil</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_register.html?DbPAR=BASE">Registriranje in brisanje zbirke podatkov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_im_export.html?DbPAR=BASE">Izvažanje in uvažanje podatkov v Base</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Izvrševanje ukazov SQL</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formule (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Splošni podatki in uporabniški vmesnik</label><ul>\
    <li><a target="_top" href="sl/text/smath/main0000.html?DbPAR=MATH">Dobrodošli v pomoči za LibreOffice Math</a></li>\
    <li><a target="_top" href="sl/text/smath/main0503.html?DbPAR=MATH">Kaj ponuja LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">Elementi formul LibreOffice</label><ul>\
    <li><a target="_top" href="sl/text/smath/01/03090100.html?DbPAR=MATH">Unarni/binarni operatorji</a></li>\
    <li><a target="_top" href="sl/text/smath/01/03090200.html?DbPAR=MATH">Relacije</a></li>\
    <li><a target="_top" href="sl/text/smath/01/03090800.html?DbPAR=MATH">Operacije z množicami</a></li>\
    <li><a target="_top" href="sl/text/smath/01/03090400.html?DbPAR=MATH">Funkcije</a></li>\
    <li><a target="_top" href="sl/text/smath/01/03090300.html?DbPAR=MATH">Operatorji</a></li>\
    <li><a target="_top" href="sl/text/smath/01/03090600.html?DbPAR=MATH">Atributi</a></li>\
    <li><a target="_top" href="sl/text/smath/01/03090500.html?DbPAR=MATH">Oklepaji</a></li>\
    <li><a target="_top" href="sl/text/smath/01/03090700.html?DbPAR=MATH">Oblika</a></li>\
    <li><a target="_top" href="sl/text/smath/01/03091600.html?DbPAR=MATH">Drugi simboli</a></li>\
            </ul></li>\
    <li><a target="_top" href="sl/text/smath/guide/main.html?DbPAR=MATH">Navodila za uporabo LibreOffice Math</a></li>\
    <li><a target="_top" href="sl/text/smath/guide/keyboard.html?DbPAR=MATH">Tipke za bližnjice (Pripomočki LibreOffice Math za ljudi s posebnimi potrebami)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Pregled ukazov in menijev</label><ul>\
    <li><a target="_top" href="sl/text/smath/main0100.html?DbPAR=MATH">Meniji</a></li>\
    <li><a target="_top" href="sl/text/smath/main0200.html?DbPAR=MATH">Orodne vrstice</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Delo s formulami</label><ul>\
    <li><a target="_top" href="sl/text/smath/guide/align.html?DbPAR=MATH">Ročna poravnava delov formule</a></li>\
    <li><a target="_top" href="sl/text/smath/guide/attributes.html?DbPAR=MATH">Sprememba privzetih atributov</a></li>\
    <li><a target="_top" href="sl/text/smath/guide/brackets.html?DbPAR=MATH">Spajanje delov formule v oklepajih</a></li>\
    <li><a target="_top" href="sl/text/smath/guide/comment.html?DbPAR=MATH">Vnos komentarjev</a></li>\
    <li><a target="_top" href="sl/text/smath/guide/newline.html?DbPAR=MATH">Vnos preloma vrstice</a></li>\
    <li><a target="_top" href="sl/text/smath/guide/parentheses.html?DbPAR=MATH">Vstavljanje oklepajev</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Grafikoni in diagrami</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Splošni podatki</label><ul>\
    <li><a target="_top" href="sl/text/schart/main0000.html?DbPAR=CHART">Grafikoni v LibreOffice</a></li>\
    <li><a target="_top" href="sl/text/schart/main0503.html?DbPAR=CHART">Kaj ponuja LibreOffice Chart</a></li>\
    <li><a target="_top" href="sl/text/schart/04/01020000.html?DbPAR=CHART">Tipke za bližnjice za grafikone</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makri in programiranje</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Splošni podatki in uporabniški vmesnik</label><ul>\
    <li><a target="_top" href="sl/text/sbasic/shared/main0601.html?DbPAR=BASIC">Pomoč za LibreOffice Basic</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programiranje v jeziku LibreOffice Basic</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/00000002.html?DbPAR=BASIC">Slovarček za LibreOffice Basic</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01010210.html?DbPAR=BASIC">Osnove</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01020000.html?DbPAR=BASIC">Skladnja</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01030100.html?DbPAR=BASIC">Pregled IDE</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01030200.html?DbPAR=BASIC">Urejevalnik Basic</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01050100.html?DbPAR=BASIC">Okno za sledenje</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/main0211.html?DbPAR=BASIC">Orodna vrstica Makro</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makro</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Podpora za makre VBA</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Pregled ukazov</label><ul>\
    <li><a target="_top" href="sl/text/sbasic/shared/01020300.html?DbPAR=BASIC">Uporaba procedur, funkcij in lastnosti</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01020500.html?DbPAR=BASIC">Knjižnice, moduli in pogovorna okna</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funkcije, izjave in operatorji</label><ul>\
    <li><a target="_top" href="sl/text/sbasic/shared/03010000.html?DbPAR=BASIC">V/I funkcije zaslona</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020000.html?DbPAR=BASIC">V/I funkcije za datoteke</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030000.html?DbPAR=BASIC">Funkcije za datum in čas</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funkcije za ravnanje z napakami</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03060000.html?DbPAR=BASIC">Logični operatorji</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03070000.html?DbPAR=BASIC">Matematični operatorji</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numerične funkcije</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090000.html?DbPAR=BASIC">Nadzorovanje izvajanja programa</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100000.html?DbPAR=BASIC">Spremenljivke</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03040000.html?DbPAR=BASIC">Konstante v Basicu</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03110000.html?DbPAR=BASIC">Primerjalni operatorji</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120000.html?DbPAR=BASIC">Nizi</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">Predmeti UNO</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Klicanje funkcij programa Calc v makrih</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Izključne funkcije VBA</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03130000.html?DbPAR=BASIC">Drugi ukazi</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Abecedni seznam funkcij, izjav in operatorjev</label><ul>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080601.html?DbPAR=BASIC">Funkcija Abs</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03060100.html?DbPAR=BASIC">Operator AND</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03104200.html?DbPAR=BASIC">Funkcija Array</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120101.html?DbPAR=BASIC">Funkcija Asc</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120111.html?DbPAR=BASIC">Funkcija AscW</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080101.html?DbPAR=BASIC">Funkcija Atn</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03130100.html?DbPAR=BASIC">Ukaz Beep</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03010301.html?DbPAR=BASIC">Funkcija Blue</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090102.html?DbPAR=BASIC">Ukaz Select...Case</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100100.html?DbPAR=BASIC">Funkcija CBool</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120105.html?DbPAR=BASIC">Funkcija CByte</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100050.html?DbPAR=BASIC">Funkcija CCur</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030116.html?DbPAR=BASIC">Funkcija CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030115.html?DbPAR=BASIC">Funkcija CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030114.html?DbPAR=BASIC">Funkcija CDateFromUnoTime</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030113.html?DbPAR=BASIC">Funkcija CDateToUnoTime</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030112.html?DbPAR=BASIC">Funkcija CDateFromUnoDate</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030111.html?DbPAR=BASIC">Funkcija CDateToUnoDate</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030108.html?DbPAR=BASIC">Funkcija CdateFromIso</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030107.html?DbPAR=BASIC">Funkcija CDateToIso</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100300.html?DbPAR=BASIC">Funkcija CDate</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100400.html?DbPAR=BASIC">Funkcija CDbl</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100060.html?DbPAR=BASIC">Funkcija CDec</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100500.html?DbPAR=BASIC">Funkcija CInt</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100600.html?DbPAR=BASIC">Funkcija CLng</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/compatible.html?DbPAR=BASIC">Ukaz Option Compatible</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100900.html?DbPAR=BASIC">Funkcija CSng</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03101000.html?DbPAR=BASIC">Funkcija CStr</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090401.html?DbPAR=BASIC">Ukaz Call</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020401.html?DbPAR=BASIC">Ukaz ChDir</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020402.html?DbPAR=BASIC">Ukaz ChDrive</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090402.html?DbPAR=BASIC">Funkcija Choose</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120102.html?DbPAR=BASIC">Funkcija Chr</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120112.html?DbPAR=BASIC">Funkcija ChrW [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020101.html?DbPAR=BASIC">Ukaz Close</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03110100.html?DbPAR=BASIC">Primerjalni operatorji</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100700.html?DbPAR=BASIC">Ukaz Const</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120313.html?DbPAR=BASIC">Funkcija ConvertFromURL</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120312.html?DbPAR=BASIC">Funkcija ConvertToURL</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080102.html?DbPAR=BASIC">Funkcija Cos</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03132400.html?DbPAR=BASIC">Funkcija CreateObject</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03131800.html?DbPAR=BASIC">Funkcija CreateUnoDialog</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03132000.html?DbPAR=BASIC">Funkcija CreateUnoListener</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03131600.html?DbPAR=BASIC">Funkcija CreateUnoService</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03131500.html?DbPAR=BASIC">Funkcija CreateUnoStruct</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03132300.html?DbPAR=BASIC">Funkcija CreateUnoValue</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020403.html?DbPAR=BASIC">Funkcija CurDir</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100070.html?DbPAR=BASIC">Funkcija CVar</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03100080.html?DbPAR=BASIC">Funkcija CVErr</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030301.html?DbPAR=BASIC">Ukaz Date</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030110.html?DbPAR=BASIC">Funkcija DateAdd</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030120.html?DbPAR=BASIC">Funkcija DateDiff</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030130.html?DbPAR=BASIC">Funkcija DatePart</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030101.html?DbPAR=BASIC">Funkcija DateSerial</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030102.html?DbPAR=BASIC">Funkcija DateValue</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030103.html?DbPAR=BASIC">Funkcija Day</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140000.html?DbPAR=BASIC">Funkcija DDB [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090403.html?DbPAR=BASIC">Ukaz Declare</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03101100.html?DbPAR=BASIC">Ukaz DefBool</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03101300.html?DbPAR=BASIC">Ukaz DefDate</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03101400.html?DbPAR=BASIC">Ukaz DefDbl</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03101500.html?DbPAR=BASIC">Ukaz DefInt</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03101600.html?DbPAR=BASIC">Ukaz DefLng</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03101700.html?DbPAR=BASIC">Ukaz DefObj</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102000.html?DbPAR=BASIC">Ukaz DefVar</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03104300.html?DbPAR=BASIC">Funkcija DimArray</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102100.html?DbPAR=BASIC">Ukaz Dim</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020404.html?DbPAR=BASIC">Funkcija Dir</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090201.html?DbPAR=BASIC">Ukaz Do...Loop</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03110100.html?DbPAR=BASIC">Primerjalni operatorji</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090404.html?DbPAR=BASIC">Ukaz End</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/enum.html?DbPAR=BASIC">Ukaz Enum</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03130800.html?DbPAR=BASIC">Funkcija Environ</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020301.html?DbPAR=BASIC">Funkcija Eof</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03104600.html?DbPAR=BASIC">Funkcija EuqalUnoObjects</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03060200.html?DbPAR=BASIC">Operator Eqv</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03104700.html?DbPAR=BASIC">Ukaz Erase</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03050100.html?DbPAR=BASIC">Funkcija Erl</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03050200.html?DbPAR=BASIC">Funkcija Err</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Predmet Err (VBA)</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03050300.html?DbPAR=BASIC">Funkcija Error</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funkcije za ravnanje z napakami</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090412.html?DbPAR=BASIC">Ukaz Exit</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080201.html?DbPAR=BASIC">Funkcija Exp</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020405.html?DbPAR=BASIC">Funkcija FileAttr</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020406.html?DbPAR=BASIC">Ukaz FileCopy</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020407.html?DbPAR=BASIC">Funkcija FileDateTime</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020415.html?DbPAR=BASIC">Funkcija FileExists</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020408.html?DbPAR=BASIC">Funkcija FileLen</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103800.html?DbPAR=BASIC">Funkcija FindObject</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103900.html?DbPAR=BASIC">Funkcija FindPropertyObject</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080501.html?DbPAR=BASIC">Funkcija Fix</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090202.html?DbPAR=BASIC">Ukaz For...Next</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090202.html?DbPAR=BASIC">Ukaz For...Next</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120301.html?DbPAR=BASIC">Funkcija Format</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03150000.html?DbPAR=BASIC">Funkcija FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03170010.html?DbPAR=BASIC">Funkcija FormatNumber [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080503.html?DbPAR=BASIC">Funkcija Frac</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020102.html?DbPAR=BASIC">Funkcija FreeFile</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090405.html?DbPAR=BASIC">Funkcija FreeLibrary</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090406.html?DbPAR=BASIC">Ukaz Function</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090400.html?DbPAR=BASIC">Nadaljnji ukazi</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140001.html?DbPAR=BASIC">Funkcija FV [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080300.html?DbPAR=BASIC">Generiranje naključnih števil</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020409.html?DbPAR=BASIC">Funkcija GetAttr</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03132500.html?DbPAR=BASIC">Funkcija GetDefaultContext</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03132100.html?DbPAR=BASIC">Funkcija GetGuiType</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03131700.html?DbPAR=BASIC">Funkcija GetProcessServiceManager</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">Funkcija GetPathSeparator</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03131000.html?DbPAR=BASIC">Funkcija GetSolarVersion</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03130700.html?DbPAR=BASIC">Funkcija GetSystemTicks</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020201.html?DbPAR=BASIC">Ukaz Get</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103450.html?DbPAR=BASIC">Ukaz Global</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090301.html?DbPAR=BASIC">Ukaz GoSub...Return</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090302.html?DbPAR=BASIC">Ukaz GoTo</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03010302.html?DbPAR=BASIC">Funkcija Green</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03104400.html?DbPAR=BASIC">Funkcija HasUnoInterfaces</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080801.html?DbPAR=BASIC">Funkcija Hex</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030201.html?DbPAR=BASIC">Funkcija Hour</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090103.html?DbPAR=BASIC">Ukaz IIf</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090101.html?DbPAR=BASIC">Ukaz If...Then...Else</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03060300.html?DbPAR=BASIC">Operator Imp</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120401.html?DbPAR=BASIC">Funkcija InStr</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120411.html?DbPAR=BASIC">Funkcija InStrRev [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03160000.html?DbPAR=BASIC">Funkcija Input [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03010201.html?DbPAR=BASIC">Funkcija InputBox</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020202.html?DbPAR=BASIC">Ukaz Input#</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080502.html?DbPAR=BASIC">Funkcija Int</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140002.html?DbPAR=BASIC">Funkcija IPmt [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140003.html?DbPAR=BASIC">Funkcija IRR [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102200.html?DbPAR=BASIC">Funkcija IsArray</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102300.html?DbPAR=BASIC">Funkcija IsDate</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102400.html?DbPAR=BASIC">Funkcija IsEmpty</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102450.html?DbPAR=BASIC">Funkcija IsError</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03104000.html?DbPAR=BASIC">Funkcija IsMissing</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102600.html?DbPAR=BASIC">Funkcija IsNull</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102700.html?DbPAR=BASIC">Funkcija IsNumeric</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102800.html?DbPAR=BASIC">Funkcija IsObject</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03104500.html?DbPAR=BASIC">Funkcija IsUnoStruct</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120315.html?DbPAR=BASIC">Funkcija Join</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020410.html?DbPAR=BASIC">Ukaz Kill</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102900.html?DbPAR=BASIC">Funkcija LBound</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120302.html?DbPAR=BASIC">Funkcija LCase</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120304.html?DbPAR=BASIC">Ukaz LSet</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120305.html?DbPAR=BASIC">Funkcija LTrim</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120303.html?DbPAR=BASIC">Funkcija Left</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120402.html?DbPAR=BASIC">Funkcija Len</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103100.html?DbPAR=BASIC">Ukaz Let</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020203.html?DbPAR=BASIC">Ukaz Line Input #</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020302.html?DbPAR=BASIC">Funkcija Loc</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020303.html?DbPAR=BASIC">Funkcija Lof</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080202.html?DbPAR=BASIC">Funkcija Log</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120306.html?DbPAR=BASIC">Ukaz Mid, funkcija Mid</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030202.html?DbPAR=BASIC">Funkcija Minute</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140004.html?DbPAR=BASIC">Funkcija MIRR [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020411.html?DbPAR=BASIC">Ukaz MkDir</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03070600.html?DbPAR=BASIC">Operator Mod</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030104.html?DbPAR=BASIC">Funkcija Month</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03150002.html?DbPAR=BASIC">Funkcija MonthName [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03010102.html?DbPAR=BASIC">Funkcija MsgBox</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03010101.html?DbPAR=BASIC">Ukaz MsgBox</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020412.html?DbPAR=BASIC">Ukaz Name</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03060400.html?DbPAR=BASIC">Operator Not</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030203.html?DbPAR=BASIC">Funkcija Now</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140005.html?DbPAR=BASIC">Funkcija NPer [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140006.html?DbPAR=BASIC">Funkcija NPV [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numerične funkcije</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080802.html?DbPAR=BASIC">Funkcija Oct</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03050500.html?DbPAR=BASIC">Ukaz On Error GoTo ... Resume</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090303.html?DbPAR=BASIC">Ukaz On...GoSub; On...GoTo</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020103.html?DbPAR=BASIC">Ukaz Open</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103200.html?DbPAR=BASIC">Ukaz Option Base</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Ukaz Option ClassModule</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/compatible.html?DbPAR=BASIC">Ukaz Option Compatible</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103300.html?DbPAR=BASIC">Ukaz Option Explicit</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103350.html?DbPAR=BASIC">Ukaz Option VBASupport</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (v definiciji funkcije)</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03060500.html?DbPAR=BASIC">Operator Or</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/partition.html?DbPAR=BASIC">Funkcija Partition</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140007.html?DbPAR=BASIC">Funkcija Pmt [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140008.html?DbPAR=BASIC">Funkcija PPmt [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03010103.html?DbPAR=BASIC">Ukaz Print</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/property.html?DbPAR=BASIC">Ukaz Property</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103400.html?DbPAR=BASIC">Ukaz Public</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020204.html?DbPAR=BASIC">Ukaz Put</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140009.html?DbPAR=BASIC">Funkcija PV [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03010304.html?DbPAR=BASIC">Funkcija QBColor</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140010.html?DbPAR=BASIC">Funkcija Rate [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080301.html?DbPAR=BASIC">Ukaz Randomize</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03102101.html?DbPAR=BASIC">Ukaz ReDim</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03010303.html?DbPAR=BASIC">Funkcija Red</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090407.html?DbPAR=BASIC">Ukaz Rem</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/replace.html?DbPAR=BASIC">Funkcija Replace</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020104.html?DbPAR=BASIC">Ukaz Reset</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/Resume.html?DbPAR=BASIC">Ukaz Resume</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03010305.html?DbPAR=BASIC">Funkcija RGB</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120307.html?DbPAR=BASIC">Funkcija Right</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020413.html?DbPAR=BASIC">Ukaz RmDir</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080302.html?DbPAR=BASIC">Funkcija Rnd</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03170000.html?DbPAR=BASIC">Funkcija Round [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120308.html?DbPAR=BASIC">Ukaz RSet</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120309.html?DbPAR=BASIC">Funkcija RTrim</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030204.html?DbPAR=BASIC">Funkcija Second</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020304.html?DbPAR=BASIC">Funkcija Seek</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020305.html?DbPAR=BASIC">Ukaz Seek</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090102.html?DbPAR=BASIC">Ukaz Select...Case</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020414.html?DbPAR=BASIC">Ukaz SetAttr</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103700.html?DbPAR=BASIC">Ukaz Set</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080701.html?DbPAR=BASIC">Funkcija Sgn</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03130500.html?DbPAR=BASIC">Funkcija Shell</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080103.html?DbPAR=BASIC">Funkcija Sin</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140011.html?DbPAR=BASIC">Funkcija SLN [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120201.html?DbPAR=BASIC">Funkciji Space in Spc</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120201.html?DbPAR=BASIC">Funkciji Space in Spc</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120314.html?DbPAR=BASIC">Funkcija Split</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080401.html?DbPAR=BASIC">Funkcija Sqr</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080400.html?DbPAR=BASIC">Izračun kvadratnega korena</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">Predmet StarDesktop</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103500.html?DbPAR=BASIC">Ukaz Static</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090408.html?DbPAR=BASIC">Ukaz Stop</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120403.html?DbPAR=BASIC">Funkcija StrComp</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120103.html?DbPAR=BASIC">Funkcija Str</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120412.html?DbPAR=BASIC">Funkcija StrReverse [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120202.html?DbPAR=BASIC">Funkcija String</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090409.html?DbPAR=BASIC">Ukaz Sub</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090410.html?DbPAR=BASIC">Funkcija Switch</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03140012.html?DbPAR=BASIC">Funkcija SYD [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080104.html?DbPAR=BASIC">Funkcija Tan</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03132200.html?DbPAR=BASIC">Predmet ThisComponent</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030205.html?DbPAR=BASIC">Funkcija TimeSerial</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030206.html?DbPAR=BASIC">Funkcija TimeValue</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030302.html?DbPAR=BASIC">Ukaz Time</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030303.html?DbPAR=BASIC">Funkcija Timer</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03080100.html?DbPAR=BASIC">Trigonometrične funkcije</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120311.html?DbPAR=BASIC">Funkcija Trim</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03131300.html?DbPAR=BASIC">Funkcija TwipsPerPixelX</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03131400.html?DbPAR=BASIC">Funkcija TwipsPerPixelY</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090413.html?DbPAR=BASIC">Ukaz Type</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103600.html?DbPAR=BASIC">Funkcija TypeName; funkcija VarType</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03103000.html?DbPAR=BASIC">Funkcija UBound</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120310.html?DbPAR=BASIC">Funkcija UCase</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03120104.html?DbPAR=BASIC">Funkcija Val</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03130600.html?DbPAR=BASIC">Ukaz Wait</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03130610.html?DbPAR=BASIC">Ukaz WaitUntil</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030105.html?DbPAR=BASIC">Funkcija WeekDay</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03150001.html?DbPAR=BASIC">Funkcija WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090203.html?DbPAR=BASIC">Ukaz While...Wend</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03090411.html?DbPAR=BASIC">Ukaz With</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03020205.html?DbPAR=BASIC">Ukaz Write</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03060600.html?DbPAR=BASIC">Operator XOR</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03030106.html?DbPAR=BASIC">Funkcija Year</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03070100.html?DbPAR=BASIC">Operator »-«</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03070200.html?DbPAR=BASIC">Operator »*«</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03070300.html?DbPAR=BASIC">Operator »+«</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03070400.html?DbPAR=BASIC">Operator »/«</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03070500.html?DbPAR=BASIC">Operator »^«</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Napredne knjižnice Basic</label><ul>\
    <li><a target="_top" href="sl/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Knjižnica Tools</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Knjižnica DEPOT</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Knjižnica EURO</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Knjižnica FORMWIZARD</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Knjižnica GIMMICKS</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Knjižnica SCHEDULE</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Knjižnica SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Knjižnica TEMPLATE</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Vodniki</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/macro_recording.html?DbPAR=BASIC">Snemanje makra</a></li>\
    <li><a target="_top" href="sl/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Spreminjanje lastnosti kontrolnika v urejevalniku pogovornih oken</a></li>\
    <li><a target="_top" href="sl/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Izdelava kontrolnikov v urejevalniku pogovornih oken</a></li>\
    <li><a target="_top" href="sl/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Programski primeri za kontrolnike v urejevalniku pogovornih oken</a></li>\
    <li><a target="_top" href="sl/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Odpiranje pogovornega okna v Basicu</a></li>\
    <li><a target="_top" href="sl/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Ustvarjanje pogovornega okna Basic</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01030400.html?DbPAR=BASIC">Organiziranje knjižnic in modulov</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01020100.html?DbPAR=BASIC">Uporaba spremenljivk</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01020200.html?DbPAR=BASIC">Uporaba predmetov</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01030300.html?DbPAR=BASIC">Razhroščevanje programa Basic</a></li>\
    <li><a target="_top" href="sl/text/sbasic/shared/01040000.html?DbPAR=BASIC">Dogodkovno vodeni makri</a></li>\
    <li><a target="_top" href="sl/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Primeri programiranja v Basicu</a></li>\
    <li><a target="_top" href="sl/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Klicanje skriptov Python iz Basica</a></li>\
    <li><a target="_top" href="sl/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Pomoč za skripte v jeziku Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Splošni podatki in uporabniški vmesnik</label><ul>\
    <li><a target="_top" href="sl/text/sbasic/python/main0000.html?DbPAR=BASIC">Skripti v jeziku Python</a></li>\
    <li><a target="_top" href="sl/text/sbasic/python/python_ide.html?DbPAR=BASIC">Integrirano razvojno okolje za Python</a></li>\
    <li><a target="_top" href="sl/text/sbasic/python/python_locations.html?DbPAR=BASIC">Organizacija skriptov v Pythonu</a></li>\
    <li><a target="_top" href="sl/text/sbasic/python/python_shell.html?DbPAR=BASIC">Interaktivna lupina Python</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programiranje v jeziku Python</label><ul>\
    <li><a target="_top" href="sl/text/sbasic/python/python_programming.html?DbPAR=BASIC">Programiranje v Pythonu</a></li>\
    <li><a target="_top" href="sl/text/sbasic/python/python_examples.html?DbPAR=BASIC">Primeri v Pythonu</a></li>\
    <li><a target="_top" href="sl/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Iz Pythona v Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Namestitev LibreOffice</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Sprememba povezave pri datotekah vrste Microsoft Office</a></li>\
    <li><a target="_top" href="sl/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Varni način</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Pogoste teme pomoči</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Splošni podatki</label><ul>\
    <li><a target="_top" href="sl/text/shared/main0400.html?DbPAR=SHARED">Tipke za bližnjico</a></li>\
    <li><a target="_top" href="sl/text/shared/00/00000005.html?DbPAR=SHARED">Splošni slovarček</a></li>\
    <li><a target="_top" href="sl/text/shared/00/00000002.html?DbPAR=SHARED">Slovarček spletnih izrazov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/accessibility.html?DbPAR=SHARED">Dostopnost v LibreOffice</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/keyboard.html?DbPAR=SHARED">Bližnjice (dostopnost LibreOffice)</a></li>\
    <li><a target="_top" href="sl/text/shared/04/01010000.html?DbPAR=SHARED">Splošne tipke za bližnjice v LibreOffice</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/version_number.html?DbPAR=SHARED">Številke različic in gradenj</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice in Microsoft Office</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/ms_user.html?DbPAR=SHARED">Uporaba paketov Microsoft Office in LibreOffice</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Primerjava izrazov v Microsoft Office in LibreOffice</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Kako pretvorimo dokumente Microsoft Office</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Sprememba povezave pri datotekah vrste Microsoft Office</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Možnosti LibreOffice</label><ul>\
    <li><a target="_top" href="sl/text/shared/optionen/01000000.html?DbPAR=SHARED">Možnosti</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01010100.html?DbPAR=SHARED">Uporabniški podatki</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01010200.html?DbPAR=SHARED">Splošno</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01010300.html?DbPAR=SHARED">Poti</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01010400.html?DbPAR=SHARED">Pripomočki za pisanje</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01010600.html?DbPAR=SHARED">Splošno</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01010700.html?DbPAR=SHARED">Pisave</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01010800.html?DbPAR=SHARED">Pogled</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01010900.html?DbPAR=SHARED">Možnosti tiskanja</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01012000.html?DbPAR=SHARED">Barve programa</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01013000.html?DbPAR=SHARED">Pripomočki za invalide</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/java.html?DbPAR=SHARED">Napredno</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Strokovna prilagoditev</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Razvojno okolje Basic</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01020000.html?DbPAR=SHARED">Možnosti za nalaganje/shranjevanje</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01030000.html?DbPAR=SHARED">Internetne možnosti</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01040000.html?DbPAR=SHARED">Možnosti dokumenta z besedilom</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01050000.html?DbPAR=SHARED">Možnosti dokumenta HTML</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01060000.html?DbPAR=SHARED">Možnosti preglednice</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01070000.html?DbPAR=SHARED">Možnosti predstavitve</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01080000.html?DbPAR=SHARED">Možnosti risanja</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01090000.html?DbPAR=SHARED">Formula</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01110000.html?DbPAR=SHARED">Možnosti grafikona</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01130100.html?DbPAR=SHARED">Lastnosti VBA</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01140000.html?DbPAR=SHARED">Jeziki</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01150000.html?DbPAR=SHARED">Možnosti nastavitev jezika</a></li>\
    <li><a target="_top" href="sl/text/shared/optionen/01160000.html?DbPAR=SHARED">Možnosti za vire podatkov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Čarovniki</label><ul>\
    <li><a target="_top" href="sl/text/shared/autopi/01000000.html?DbPAR=SHARED">Čarovnik</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Čarovnik za pisma</label><ul>\
    <li><a target="_top" href="sl/text/shared/autopi/01010000.html?DbPAR=SHARED">Čarovnik za pisma</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Čarovnik za faks</label><ul>\
    <li><a target="_top" href="sl/text/shared/autopi/01020000.html?DbPAR=SHARED">Čarovnik za faks</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Čarovnik za dnevni red</label><ul>\
    <li><a target="_top" href="sl/text/shared/autopi/01040000.html?DbPAR=SHARED">Čarovnik za dnevni red</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Čarovnik za izvoz HTML</label><ul>\
    <li><a target="_top" href="sl/text/shared/autopi/01110000.html?DbPAR=SHARED">Izvoz v HTML</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Čarovnik za pretvorbo dokumenta</label><ul>\
    <li><a target="_top" href="sl/text/shared/autopi/01130000.html?DbPAR=SHARED">Pretvornik dokumentov</a></li>\
			</ul></li>\
    <li><a target="_top" href="sl/text/shared/autopi/01150000.html?DbPAR=SHARED">Čarovnik Pretvornik za Evro</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Prilagajanje LibreOffice</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/configure_overview.html?DbPAR=SHARED">Prilagajanje LibreOffice</a></li>\
    <li><a target="_top" href="sl/text/shared/01/packagemanager.html?DbPAR=SHARED">Upravitelj razširitev</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/flat_icons.html?DbPAR=SHARED">Spreminjanje pogleda z ikonami</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Dodajanje gumbov v orodne vrstice</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/workfolder.html?DbPAR=SHARED">Kako določimo novo delovno mapo</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/standard_template.html?DbPAR=SHARED">Spreminjanje privzetih predlog</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Registracija adresarja</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/formfields.html?DbPAR=SHARED">Vstavljanje in urejanje gumbov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Delo z uporabniškim vmesnikom</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Krmar za hiter dostop do predmetov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/navigator.html?DbPAR=SHARED">Krmar za pregled dokumenta</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/autohide.html?DbPAR=SHARED">Prikazovanje, sidranje in skrivanje oken</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/textmode_change.html?DbPAR=SHARED">Preklapljanje med vstavnim in prepisnim načinom</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Uporabljanje orodnih vrstic</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digitalni podpisi</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/digital_signatures.html?DbPAR=SHARED">O digitalnih podpisih</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Uporaba digitalnih podpisov</a></li>\
    <li><a target="_top" href="sl/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">Možnosti za PDF – zavihek Digitalni podpisi</a></li>\
    <li><a target="_top" href="sl/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Podpisovanje obstoječega PDF</a></li>\
    <li><a target="_top" href="sl/text/shared/01/addsignatureline.html?DbPAR=SHARED">Dodajanje črte za podpis v dokumente</a></li>\
    <li><a target="_top" href="sl/text/shared/01/signsignatureline.html?DbPAR=SHARED">Podpisovanje črte za podpis</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Tiskanje, faksiranje, pošiljanje</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/labels_database.html?DbPAR=SHARED">Tiskanje nalepk za naslove</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Črno-belo tiskanje</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/email.html?DbPAR=SHARED">Pošiljanje dokumentov kot e-pošte</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/fax.html?DbPAR=SHARED">Pošiljanje faksov in nastavitev programa LibreOffice za pošiljanje faksov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Povleci in spusti</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/dragdrop.html?DbPAR=SHARED">Način povleci in spusti v dokumentu LibreOffice</a></li>\
    <li><a target="_top" href="sl/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Premikanje in kopiranje besedila v dokumentih</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kopiranje delov preglednic v dokumente z besedilom</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kopiranje grafik med dokumenti</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kopiranje grafik iz galerije</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Način povleci in spusti v pogledu vira podatkov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Kopiraj in prilepi</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Kopiranje risanih predmetov v druge dokumente</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Kopiranje grafik med dokumenti</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Kopiranje grafik iz galerije</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Kopiranje delov preglednic v dokumente z besedilom</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Grafikoni in diagrami</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/chart_insert.html?DbPAR=SHARED">Vstavljanje grafikonov</a></li>\
    <li><a target="_top" href="sl/text/schart/main0000.html?DbPAR=SHARED">Grafikoni v LibreOffice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Nalaganje, shranjevanje, uvoz, izvoz, PDF</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/doc_open.html?DbPAR=SHARED">Odpiranje dokumentov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/import_ms.html?DbPAR=SHARED">Odpiranje dokumentov v drugih oblikah zapisa</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/doc_save.html?DbPAR=SHARED">Shranjevanje dokumentov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Samodejno shranjevanje dokumentov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/export_ms.html?DbPAR=SHARED">Shranjevanje dokumentov v drugih oblikah zapisa</a></li>\
    <li><a target="_top" href="sl/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Izvozi v PDF</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Uvažanje in izvažanje podatkov v besedilni obliki</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Povezave in sklici</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Vstavljanje hiperpovezav</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Relativne in absolutne povezave</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Urejanje hiperpovezav</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Sledenje različic dokumentov</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Primerjava različic dokumenta</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Spajanje različic</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Beleženje sprememb</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/redlining.html?DbPAR=SHARED">Beleženje in prikaz sprememb</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Sprejemanje ali zavračanje sprememb</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Upravljanje z različicami</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Nalepke in vizitke</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/labels.html?DbPAR=SHARED">Izdelava ter tiskanje nalepk in vizitk</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Vstavljanje podatkov iz zunanjih virov</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/copytable2application.html?DbPAR=SHARED">Vstavljanje podatkov iz preglednic</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/copytext2application.html?DbPAR=SHARED">Vstavljanje podatkov iz dokumentov z besedilom</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Vstavljanje, urejanje in shranjevanje bitnih slik</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Dodajanje grafik v Galerijo</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Samodejne funkcije</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Izklop samodejnega prepoznavanja URL-jev</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Iskanje in zamenjevanje</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/data_search2.html?DbPAR=SHARED">Iskanje s filtrom obrazca</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_search.html?DbPAR=SHARED">Iskanje po tabelah in dokumentih z obrazci</a></li>\
    <li><a target="_top" href="sl/text/shared/01/02100001.html?DbPAR=SHARED">Seznam regularnih izrazov</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Vodniki</label><ul>\
    <li><a target="_top" href="sl/text/shared/guide/linestyles.html?DbPAR=SHARED">Uporaba slogov črte</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/text_color.html?DbPAR=SHARED">Spreminjanje barve besedila</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/change_title.html?DbPAR=SHARED">Spreminjanje naslova dokumenta</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/round_corner.html?DbPAR=SHARED">Ustvarjanje okroglih robov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/background.html?DbPAR=SHARED">Določanje barv ozadja ali slik za ozadje</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/lineend_define.html?DbPAR=SHARED">Določitev koncev črte</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Določitev sloga črte</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Urejanje grafičnih predmetov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/line_intext.html?DbPAR=SHARED">Risanje črt v besedilu</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/aaa_start.html?DbPAR=SHARED">Prvi koraki</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Vstavljanje predmetov iz Galerije</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Vstavljanje nedeljivih presledkov, vezajev in delilnih vezajev</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Vstavljanje posebnih znakov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/tabs.html?DbPAR=SHARED">Vstavljanje in urejanje tabulatorskih mest</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/protection.html?DbPAR=SHARED">Zaščita vsebine v programu LibreOffice</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Zaščita zapisov</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Izbor največjega območja tiskanja na strani</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/measurement_units.html?DbPAR=SHARED">Izbiranje merskih enot</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/language_select.html?DbPAR=SHARED">Izbor jezika dokumenta</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Oblikovanje tabele</a></li>\
    <li><a target="_top" href="sl/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Izklop Označevanja in oštevilčevanja za posamezne odstavke</a></li>\
		</ul></li>\
	</ul></li></ul>\
';
