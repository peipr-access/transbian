document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Text Documents (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">ព័ត៌មាន​ទូទៅ និង​ការ​ប្រើ​ចំណុច​ប្រទាក់​អ្នកប្រើ</label><ul>\
    <li><a target="_top" href="km/text/swriter/main0000.html?DbPAR=WRITER">​សូម​ស្វាគមន៍​មក​កាន់​ជំនួយ LibreOffice Writer</a></li>\
    <li><a target="_top" href="km/text/swriter/main0503.html?DbPAR=WRITER">លក្ខណៈ​ពិសេស​របស់ LibreOffice Writer</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/main.html?DbPAR=WRITER">សេចក្តី​ណែនាំ​ក្នុង​ការ​ប្រើ LibreOffice Writer</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">ការ​ចត និង ការ​ផ្លាស់ប្តូរ​ទំហំ​បង្អួច</a></li>\
    <li><a target="_top" href="km/text/swriter/04/01020000.html?DbPAR=WRITER">គ្រាប់​ចុច​ផ្លូវកាត់ LibreOffice Writer</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/words_count.html?DbPAR=WRITER">ការ​រាប់​ពាក្យ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/keyboard.html?DbPAR=WRITER">ការ​ប្រើ​​គ្រាប់​ចុច​ផ្លូវ​កាត់ (LibreOffice Writer ភាព​អាច​ចូល​ដំណើរការ​បាន)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">ពាក្យ​បញ្ជា និង​សេចក្ដីយោង​ម៉ឺនុយ</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">ម៉ឺនុយ</label><ul>\
    <li><a target="_top" href="km/text/swriter/main0100.html?DbPAR=WRITER">ម៉ឺនុយ</a></li>\
    <li><a target="_top" href="km/text/swriter/main0101.html?DbPAR=WRITER">ឯកសារ</a></li>\
    <li><a target="_top" href="km/text/swriter/main0102.html?DbPAR=WRITER">កែ​សម្រួល</a></li>\
    <li><a target="_top" href="km/text/swriter/main0103.html?DbPAR=WRITER">ទិដ្ឋភាព</a></li>\
    <li><a target="_top" href="km/text/swriter/main0104.html?DbPAR=WRITER">បញ្ចូល</a></li>\
    <li><a target="_top" href="km/text/swriter/main0105.html?DbPAR=WRITER">ទ្រង់ទ្រាយ</a></li>\
    <li><a target="_top" href="km/text/swriter/main0115.html?DbPAR=WRITER">Styles</a></li>\
    <li><a target="_top" href="km/text/swriter/main0110.html?DbPAR=WRITER">តារាង</a></li>\
    <li><a target="_top" href="km/text/swriter/main0120.html?DbPAR=WRITER">Form Menu</a></li>\
    <li><a target="_top" href="km/text/swriter/main0106.html?DbPAR=WRITER">ឧបករណ៍</a></li>\
    <li><a target="_top" href="km/text/swriter/main0107.html?DbPAR=WRITER">បង្អួច</a></li>\
    <li><a target="_top" href="km/text/shared/main0108.html?DbPAR=WRITER">ជំនួយ</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">របារ​ឧបករណ៍</label><ul>\
    <li><a target="_top" href="km/text/swriter/main0200.html?DbPAR=WRITER">របារ​ឧបករណ៍</a></li>\
    <li><a target="_top" href="km/text/swriter/main0202.html?DbPAR=WRITER">របារ​ធ្វើ​ទ្រង់​ទ្រាយ</a></li>\
    <li><a target="_top" href="km/text/swriter/main0203.html?DbPAR=WRITER">Image Bar</a></li>\
    <li><a target="_top" href="km/text/swriter/main0204.html?DbPAR=WRITER">របារ​តារាង</a></li>\
    <li><a target="_top" href="km/text/swriter/main0205.html?DbPAR=WRITER">របារ​លក្ខណសម្បត្តិ​របស់​វត្ថុ​គំនូរ</a></li>\
    <li><a target="_top" href="km/text/swriter/main0206.html?DbPAR=WRITER">របារ​ចំណុច និង លេខរៀង</a></li>\
    <li><a target="_top" href="km/text/swriter/main0208.html?DbPAR=WRITER">របារ​ស្ថានភាព</a></li>\
    <li><a target="_top" href="km/text/swriter/main0210.html?DbPAR=WRITER">Print Preview</a></li>\
    <li><a target="_top" href="km/text/swriter/main0213.html?DbPAR=WRITER">បន្ទាត់</a></li>\
    <li><a target="_top" href="km/text/swriter/main0214.html?DbPAR=WRITER">របារ​​រូបមន្ត</a></li>\
    <li><a target="_top" href="km/text/swriter/main0215.html?DbPAR=WRITER">របារ​ស៊ុម</a></li>\
    <li><a target="_top" href="km/text/swriter/main0216.html?DbPAR=WRITER">របារ​វត្ថុ OLE</a></li>\
    <li><a target="_top" href="km/text/swriter/main0220.html?DbPAR=WRITER">របារ​វត្ថុ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/shared/main0201.html?DbPAR=WRITER">របារ​ស្តង់ដារ</a></li>\
    <li><a target="_top" href="km/text/shared/main0212.html?DbPAR=WRITER">របារ​ទិន្នន័យ​តារាង</a></li>\
    <li><a target="_top" href="km/text/shared/main0213.html?DbPAR=WRITER">របារ​រុករក​សំណុំ​បែបបទ</a></li>\
    <li><a target="_top" href="km/text/shared/main0214.html?DbPAR=WRITER">របារ​រចនា​សំណួរ</a></li>\
    <li><a target="_top" href="km/text/shared/main0226.html?DbPAR=WRITER">របារ​រចនា​សំណុំ​បែបបទ</a></li>\
    <li><a target="_top" href="km/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">របារ​ឧបករណ៍ LibreLogo</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">ការ​បង្កើត​ឯកសារ​អត្ថបទ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">រុករក និង ជ្រើស​ដោយ​ប្រើ​ក្តារ​ចុច</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">ប្រើ​ទស្សន៍​ទ្រនិច​ផ្ទាល់</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">ក្រាហ្វិក​នៅ​ក្នុង​ឯកសារ​អត្ថបទ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">ការ​បញ្ចូល​ក្រាហ្វិក</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">ការ​បញ្ចូល​ក្រាហ្វិក​ពី​ឯកសារ​មួយ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">បញ្ចូល​ក្រាហ្វិក​ពី​វិចិត្រសាល​ដោយ​ អូស និង ទម្លាក់</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">ការ​បញ្ចូល​រូបភាព​ស្កេនមួយ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">ការ​បញ្ចូល​គំនូសតាង Calc ទៅ​ក្នុង​ឯកសារ​អត្ថបទ​មួយ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">ការ​បញ្ចូល​ក្រាហ្វិក​ពី LibreOffice Draw ឬ​Impress</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">តារាង​នៅ​ក្នុង​ឯកសារ​អត្ថបទ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">បិទ ឬ​បើក​ការ​ទទួល​ស្គាល់​លេខ​ក្នុង​តារាង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/tablemode.html?DbPAR=WRITER">ការ​កែប្រែ​ជួរដេក និង ជួរឈរ​ដោយ​ប្រើ​ក្តារ​ចុច</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/table_delete.html?DbPAR=WRITER">ការ​លុប​តារាង ឬ​មាតិកា​តារាង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/table_insert.html?DbPAR=WRITER">ការ​បញ្ចូល​តារាង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">ធ្វើ​ក្បាល​តារាង​មួយ​ឡើង​វិញ​លើ​ទំព័រ​ថ្មី</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/table_sizing.html?DbPAR=WRITER">ការ​ផ្លាស់ប្ដូរ​ទំហំ​ជួរ​ដេក និង​ជួរ​ឈរ​នៅ​ក្នុង​តារាង​អត្ថបទ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">វត្ថុ​នៅ​ក្នុង​ឯកសារ​អត្ថបទ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/anchor_object.html?DbPAR=WRITER">ការ​ដាក់​ទីតាំង​វត្ថុ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/wrap.html?DbPAR=WRITER">រុំ​អត្ថបទ​ជុំ​វិញ​វត្ថុ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">ភាគ និង​ស៊ុម​នៅ​ក្នុង​ឯកសារ​អត្ថបទ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/sections.html?DbPAR=WRITER">ការ​ប្រើ​ភាគ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/section_edit.html?DbPAR=WRITER">ការ​កែសម្រួល​ភាគ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/section_insert.html?DbPAR=WRITER">បញ្ចូល​ភាគ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">តារាង​មាតិកា និង​លិបិក្រម</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">លិបិក្រម​កំណត់​ដោយ​អ្នក​ប្រើ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/indices_toc.html?DbPAR=WRITER">ការ​បង្កើត​តារាង​មាតិកា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/indices_index.html?DbPAR=WRITER">ការ​បង្កើត​លិបិក្រម​តាម​អក្សរក្រម</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">លិបិក្រម​លើ​ឯកសារ​ច្រើន</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/indices_literature.html?DbPAR=WRITER">ការ​បង្កើត​គន្ថនិទ្ទេស</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/indices_delete.html?DbPAR=WRITER">ការ​កែសម្រួល ឬ​ការ​លុប​ធាតុ​លិបិក្រម និង តារាង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/indices_edit.html?DbPAR=WRITER">ការ​ធ្វើ​បច្ចុប្បន្នភាព កែសម្រួល និង លុប​លិបិក្រម និង តារាង​មាតិកា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/indices_enter.html?DbPAR=WRITER">កំណត់​ធាតុ​លិបិក្រម ឬ​តារាង​មាតិកា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/indices_form.html?DbPAR=WRITER">ធ្វើ​ទ្រង់ទ្រាយ​លិបិក្រម ឬ​តារាង​មាតិកា</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">វាល​នៅ​ក្នុង​ឯកសារ​អត្ថបទ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/fields.html?DbPAR=WRITER">អំពី​វាល</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/fields_date.html?DbPAR=WRITER">ការ​បញ្ចូល​វាល​កាលបរិច្ឆេទ​ថេរ ឬ​ប្រែប្រួល</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/field_convert.html?DbPAR=WRITER">ការ​បម្លែង​វាល​ទៅ​ជា​អត្ថបទ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">ការ​រក​មើល​ឯកសារ​អត្ថបទ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">ការ​ចម្លង និង ការ​ផ្លាស់ទី​អត្ថបទ​ក្នុង​ឯកសារ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">រៀបចំ​ឯកសារ​ឡើង​វិញ​ដោយ​ប្រើ​កម្មវិធី​រុករក</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">ការ​បញ្ចូល​តំណ​ខ្ពស់​ជាមួយ​កម្មវិធី​រុករក</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/navigator.html?DbPAR=WRITER">​កម្មវិធី​រុករក​សម្រាប់​ឯកសារ​អត្ថបទ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">ការ​គណនា​ក្នុង​ឯកសារ​អត្ថបទ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">ការ​គណនា​ឆ្លង​តារាង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/calculate.html?DbPAR=WRITER">ការ​គណនា​ក្នុង​ឯកសារ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">គណនា និង បិទភ្ជាប់​លទ្ធផល​នៃ​រូបមន្ត​ក្នុង​ឯកសារ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">គណនា​ក្រឡា​សរុប​ក្នុង​តារាង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">គណនា​រូបមន្ត​ស្មុគ្រស្មាញ ក្នុង​ឯកសារ​អត្ថបទ ។</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">ការ​បង្ហាញ​លទ្ធផល​​ប្រមាណវិធី​នៃ​តារាង​មួយ ក្នុង​តារាង​មួយ​ផ្សេង​ទៀត</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">ការ​ធ្វើ​ទ្រង់ទ្រាយ​ឯកសារ​អត្ថបទ</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">ពុម្ព និង រចនាប័ទ្ម</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/templates_styles.html?DbPAR=WRITER">ពុម្ព និង រចនាប័ទ្ម</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">ឆ្លាស់​រចនាប័ទ្ម​ទំព័រ​នៅ​លើ​ទំព័រ​សេស និង គូ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/change_header.html?DbPAR=WRITER">បង្កើត​រចនាប័ទ្ម​ទំព័រ​មួយ ដោយ​ផ្អែក​លើ​ទំព័រ​បច្ចុប្បន្ន</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/load_styles.html?DbPAR=WRITER">ការ​ប្រើ​រចនាប័ទ្ម​ពី​ឯកសារ ឬ​ពុម្ព​ផ្សេង​ទៀត</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">ការ​បង្កើត​រចនាប័ទ្ម​ថ្មី​ពី​ជម្រើស</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/stylist_update.html?DbPAR=WRITER">ការ​ធ្វើ​រចនាប័ទ្ម​ឲ្យ​ទាន់​សម័យ​ពី​ជម្រើស</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/template_create.html?DbPAR=WRITER">ការ​បង្កើត​ពុម្ព​ឯកសារ​មួយ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/template_default.html?DbPAR=WRITER">ការ​ផ្លាស់ប្តូរ​ពុម្ព​លំនាំដើម</a></li>\
			</ul></li>\
    <li><a target="_top" href="km/text/swriter/guide/pageorientation.html?DbPAR=WRITER">ផ្លាស់ប្តូរ​ទិស​ទំព័រ (បញ្ឈរ ឬ​ផ្ដេក)</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/text_capital.html?DbPAR=WRITER">ការ​ប្តូរ​លក្ខណៈ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/hidden_text.html?DbPAR=WRITER">លាក់​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">កំណត់​បឋមកថា និង បាតកថា​ផ្សេង​ៗ​គ្នា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">ការ​បញ្ចូល​លេខ និង ឈ្មោះ​ជំពូក​ក្នុង​បឋមកថា ឬ​បាតកថា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">ការ​អនុវត្តការ​ធ្វើ​​​ទ្រង់ទ្រាយ​អត្ថបទ ខណៈ​ពេល​អ្នក​វាយ​បញ្ចូល</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/reset_format.html?DbPAR=WRITER">កំណត់​គុណ​លក្ខណៈ​ពុម្ព​អក្សរ​ឡើង​វិញ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">អនុវត្ត​រចនាប័ទ្ម​ក្នុង​របៀប​បំពេញ​ទ្រង់ទ្រាយ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/wrap.html?DbPAR=WRITER">រុំ​អត្ថបទ​ជុំ​វិញ​វត្ថុ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/text_centervert.html?DbPAR=WRITER">ប្រើ​ស៊ុម​ដើម្បី​តម្រឹម​ឲ្យ​អត្ថបទ​នៅ​កណ្តាល​ទំព័រមួយ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">គូស​បញ្ជាក់​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/text_rotate.html?DbPAR=WRITER">ការ​បង្វិល​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/page_break.html?DbPAR=WRITER">ការ​លុប និង បញ្ចូល​ការ​បំបែក​ទំព័រ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/pagestyles.html?DbPAR=WRITER">ការ​បង្កើត និង ការ​អនុវត្ត​រចនាប័ទ្ម​ទំព័រ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/subscript.html?DbPAR=WRITER">ធ្វើ​អត្ថបទ​ទៅ​ជា​អក្សរ​តូច​ក្រោម ឬ​អក្សរ​តូច​លើ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">ធាតុ​អត្ថបទ​ពិសេស</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/captions.html?DbPAR=WRITER">ការ​ប្រើ​ចំណងជើង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/conditional_text.html?DbPAR=WRITER">អត្ថបទ​​លក្ខខណ្ឌ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">អត្ថបទ​លក្ខខណ្ឌ សម្រាប់​ចំនួន​ទំព័រ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/fields_date.html?DbPAR=WRITER">ការ​បញ្ចូល​វាល​កាលបរិច្ឆេទ​ថេរ ឬ​ប្រែប្រួល</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/fields_enter.html?DbPAR=WRITER">ការ​បន្ថែម​វាលបញ្ចូល</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">ការ​បញ្ចូល​លេខ​ទំព័រ​នៃ​ទំព័រ​បន្ត​បន្ទាប់​គ្នា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">ការ​បញ្ចូល​លេខ​ទំព័រ​ក្នុង​បាតកថា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/hidden_text.html?DbPAR=WRITER">លាក់​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">កំណត់​បឋមកថា និង បាតកថា​ផ្សេង​ៗ​គ្នា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">ការ​បញ្ចូល​លេខ និង ឈ្មោះ​ជំពូក​ក្នុង​បឋមកថា ឬ​បាតកថា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">ការ​សួរ​ទិន្នន័យ​អ្នក​ប្រើ​ក្នុងវាល ឬ​លក្ខខណ្ឌ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">ការ​បញ្ចូល និង​ ​ការ​កែសម្រួល​លេខ​យោង និង លេខ​យោង​ចុង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">គម្លាត​រវាង​លេខ​យោង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/header_footer.html?DbPAR=WRITER">អំពី​បឋមកថា និង បាតកថា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/header_with_line.html?DbPAR=WRITER">ការ​ធ្វើ​ទ្រង់ទ្រាយ​បឋមកថា ឬ​បាតកថា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/text_animation.html?DbPAR=WRITER">ការ​ធ្វើ​ឲ្យ​អត្ថបទ​មាន​ចលនា</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">ការ​បង្កើត​សំបុត្រ​សំណុំ​បែបបទ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">អនុគមន៍​ស្វ័យប្រវត្តិ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">ការ​បន្ថែម​ករណី​លើកលែង ទៅ​បញ្ជី​កែ​ស្វ័យ​ប្រវត្តិ​</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/autotext.html?DbPAR=WRITER">ប្រើ​អត្ថបទ​ស្វ័យ​ប្រវត្តិ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">បង្កើត​បញ្ជី​ដែល​មាន​ចំណុច ឬ​លេខ​រៀង នៅ​ពេល​អ្នក​វាយ​បញ្ចូល</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/auto_off.html?DbPAR=WRITER">បិទ​កែ​ស្វ័យ​ប្រវត្តិ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">ពិនិត្យ​​អក្ខរាវិរុទ្ធ​ដោយ​ស្វ័យ​ប្រវត្តិ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">បិទ ឬ​បើក​ការ​ទទួល​ស្គាល់​លេខ​ក្នុង​តារាង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">ការ​ដាក់​​សហ​សញ្ញា</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">លេខរៀង និង​បញ្ជី</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">ការ​បន្ថែម​លេខ​ជំពូក​ទៅ​ចំណងជើង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">បង្កើត​បញ្ជី​ដែល​មាន​ចំណុច ឬ​លេខ​រៀង នៅ​ពេល​អ្នក​វាយ​បញ្ចូល</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the Chapter Level of Numbered and Bulleted Lists</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">ផ្សំ​បញ្ជី​ដែល​មាន​លេខ​រៀង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">បន្ថែម​លេខរៀង​បន្ទាត់</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">ការ​កែប្រែ​លេខរៀង​ក្នុង​បញ្ជី​ដែល​មាន​លេខរៀង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/number_sequence.html?DbPAR=WRITER">ការ​កំណត់​ជួរ​លេខ​</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">ការ​បន្ថែម​លេខ​រៀង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/using_numbering.html?DbPAR=WRITER">លេខ​រៀង និង រចនាប័ទ្ម​លេខ​រៀង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">ការ​បន្ថែម​ចំណុច</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">ការ​ពិនិត្យ​អក្ខរាវិរុទ្ធ កម្រង​វេវចនសព្ទ និង​ភាសា</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">ពិនិត្យ​​អក្ខរាវិរុទ្ធ​ដោយ​ស្វ័យ​ប្រវត្តិ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">ការ​យក​ពាក្យ​ចេញ​ពី វចនានុក្រម​កំណត់​ដោយ​អ្នក​ប្រើ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">កម្រង​វេវចនសព្ទ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">ការ​ពិនិត្យអក្ខរាវិរុទ្ធ និងវេយ្យាករណ៍</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">ព័ត៌មាន​ជំនួយ​ដំណោះស្រាយ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">ការ​បញ្ចូល​អត្ថបទ​ពី​មុខ​តារាង​មួយ នៅ​កំពូល​ទំព័រ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">ទៅ​កាន់​កន្លែង​ចំណាំ​ជាក់លាក់</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/send2html.html?DbPAR=WRITER">ការ​រក្សាទុក​ឯកសារ​អត្ថបទ​ក្នុង​ទ្រង់ទ្រាយ HTML</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">ការ​បញ្ចូល​ឯកសារ​អត្ថបទ​ទាំងមូល</a></li>\
    <li><a target="_top" href="km/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">ឯកសារ​មេ</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/globaldoc.html?DbPAR=WRITER">ឯកសារ​មេ និង​ឯកសារ​រង</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">តំណ និង​សេចក្ដីយោង</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/references.html?DbPAR=WRITER">ការ​បញ្ចូល​សេចក្តី​យោង​ឆ្លង</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">ការ​បញ្ចូល​តំណ​ខ្ពស់​ជាមួយ​កម្មវិធី​រុករក</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">ការ​បោះពុម្ព</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/printer_tray.html?DbPAR=WRITER">ជ្រើស​ថាស​ក្រដាស​ម៉ាស៊ីន​បោះពុម្ព</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/print_preview.html?DbPAR=WRITER">មើល​ទំព័រ​មួយ​ជា​មុន មុន​ពេល​បោះពុម្ព</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/print_small.html?DbPAR=WRITER">ការ​បោះពុម្ព​ទំព័រ​ច្រើន​ក្នុង​មួយ​សន្លឹក</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/pagestyles.html?DbPAR=WRITER">ការ​បង្កើត និង ការ​អនុវត្ត​រចនាប័ទ្ម​ទំព័រ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">ស្វែងរក និង​ជំនួស</label><ul>\
    <li><a target="_top" href="km/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="km/text/shared/01/02100001.html?DbPAR=WRITER">បញ្ជី​កន្សោម​ធម្មតា</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML Documents (Writer Web)</label><ul>\
    <li><a target="_top" href="km/text/shared/07/09000000.html?DbPAR=WRITER">ទំព័រ​បណ្ដាញ</a></li>\
    <li><a target="_top" href="km/text/shared/02/01170700.html?DbPAR=WRITER">តម្រង​ HTML និង សំណុំ​បែប​បទ</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/send2html.html?DbPAR=WRITER">ការ​រក្សាទុក​ឯកសារ​អត្ថបទ​ក្នុង​ទ្រង់ទ្រាយ HTML</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Spreadsheets (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">ព័ត៌មាន​ទូទៅ និង​ការ​ប្រើ​ចំណុច​ប្រទាក់​អ្នកប្រើ</label><ul>\
    <li><a target="_top" href="km/text/scalc/main0000.html?DbPAR=CALC">សូម​ស្វាគមន៍​មក​កាន់​ជំនួយ​ LibreOffice Calc</a></li>\
    <li><a target="_top" href="km/text/scalc/main0503.html?DbPAR=CALC">លក្ខណៈ​ពិសេស​របស់ LibreOffice Calc</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/keyboard.html?DbPAR=CALC">គ្រាប់​ចុច​ផ្លូវ​កាត់ (ភាព​អាច​ចូល​ដំណើរ​ការ​បាន​ក្នុង LibreOffice Calc)</a></li>\
    <li><a target="_top" href="km/text/scalc/04/01020000.html?DbPAR=CALC">គ្រាប់​ចុច​ផ្លូវ​កាត់ សម្រាប់​សៀវភៅ​បញ្ជី</a></li>\
    <li><a target="_top" href="km/text/scalc/05/02140000.html?DbPAR=CALC">លេខ​កំហុស​ក្នុង​ LibreOffice Calc</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060112.html?DbPAR=CALC">រូបមន្ត​បន្ថែម​សម្រាប់​សរសេរ​កម្មវិធី​ក្នុង LibreOffice Calc</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/main.html?DbPAR=CALC">សេចក្តី​ណែនាំ​សម្រាប់​ការ​ប្រើ LibreOffice Calc</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">ពាក្យ​បញ្ជា និង​សេចក្ដីយោង​ស៊ុម</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">ម៉ឺនុយ</label><ul>\
    <li><a target="_top" href="km/text/scalc/main0100.html?DbPAR=CALC">ម៉ឺនុយ</a></li>\
    <li><a target="_top" href="km/text/scalc/main0101.html?DbPAR=CALC">ឯកសារ</a></li>\
    <li><a target="_top" href="km/text/scalc/main0102.html?DbPAR=CALC">កែ​សម្រួល</a></li>\
    <li><a target="_top" href="km/text/scalc/main0103.html?DbPAR=CALC">ទិដ្ឋភាព</a></li>\
    <li><a target="_top" href="km/text/scalc/main0104.html?DbPAR=CALC">បញ្ចូល</a></li>\
    <li><a target="_top" href="km/text/scalc/main0105.html?DbPAR=CALC">ទ្រង់ទ្រាយ</a></li>\
    <li><a target="_top" href="km/text/scalc/main0116.html?DbPAR=CALC">Sheet</a></li>\
    <li><a target="_top" href="km/text/scalc/main0112.html?DbPAR=CALC">ទិន្នន័យ</a></li>\
    <li><a target="_top" href="km/text/scalc/main0106.html?DbPAR=CALC">ឧបករណ៍</a></li>\
    <li><a target="_top" href="km/text/scalc/main0107.html?DbPAR=CALC">បង្អួច</a></li>\
    <li><a target="_top" href="km/text/shared/main0108.html?DbPAR=CALC">ជំនួយ</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">របារ​ឧបករណ៍</label><ul>\
    <li><a target="_top" href="km/text/scalc/main0200.html?DbPAR=CALC">របារ​ឧបករណ៍</a></li>\
    <li><a target="_top" href="km/text/scalc/main0202.html?DbPAR=CALC">របារ​ធ្វើ​ទ្រង់​ទ្រាយ</a></li>\
    <li><a target="_top" href="km/text/scalc/main0203.html?DbPAR=CALC">របារ​លក្ខណសម្បត្តិ​របស់​វត្ថុ​គំនូរ</a></li>\
    <li><a target="_top" href="km/text/scalc/main0205.html?DbPAR=CALC">របារ​ធ្វើ​ទ្រង់​ទ្រាយ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/scalc/main0206.html?DbPAR=CALC">របារ​​រូបមន្ត</a></li>\
    <li><a target="_top" href="km/text/scalc/main0208.html?DbPAR=CALC">របារ​ស្ថានភាព</a></li>\
    <li><a target="_top" href="km/text/scalc/main0210.html?DbPAR=CALC">របារ​មើល​ទំព័រ​ជា​មុន</a></li>\
    <li><a target="_top" href="km/text/scalc/main0214.html?DbPAR=CALC">Image Bar</a></li>\
    <li><a target="_top" href="km/text/scalc/main0218.html?DbPAR=CALC">របារ​ឧបករណ៍</a></li>\
    <li><a target="_top" href="km/text/shared/main0201.html?DbPAR=CALC">របារ​ស្តង់ដារ</a></li>\
    <li><a target="_top" href="km/text/shared/main0212.html?DbPAR=CALC">របារ​ទិន្នន័យ​តារាង</a></li>\
    <li><a target="_top" href="km/text/shared/main0213.html?DbPAR=CALC">របារ​រុករក​សំណុំ​បែបបទ</a></li>\
    <li><a target="_top" href="km/text/shared/main0214.html?DbPAR=CALC">របារ​រចនា​សំណួរ</a></li>\
    <li><a target="_top" href="km/text/shared/main0226.html?DbPAR=CALC">របារ​រចនា​សំណុំ​បែបបទ</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">ប្រភេទ​អនុគមន៍ និង​សញ្ញា​ប្រមាណវិធី</label><ul>\
    <li><a target="_top" href="km/text/scalc/01/04060000.html?DbPAR=CALC">អ្នក​ជំនួយការ អនុគមន៍</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060100.html?DbPAR=CALC">អនុគមន៍​តាម​ប្រភេទ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060107.html?DbPAR=CALC">អនុគមន៍​អារេ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060120.html?DbPAR=CALC">អនុគមន៍​​ប្រមាណ​វិធី​ប៊ីត​</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060101.html?DbPAR=CALC">អនុគមន៍​មូលដ្ឋាន​ទិន្នន័យ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060102.html?DbPAR=CALC">អនុគមន៍ កាលបរិច្ឆេទ & ពេលវេលា</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060103.html?DbPAR=CALC">អនុគមន៍​ហេរញវត្ថុ ផ្នែក​១</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060119.html?DbPAR=CALC">អនុគមន៍​ហិរញ្ញវត្ថុ ផ្នែក​ទី​ពីរ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060118.html?DbPAR=CALC">អនុគមន៍​ហិរញ្ញវត្ថុ ផ្នែក​ទី​បី</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060104.html?DbPAR=CALC">អនុគមន៍​ព័ត៌មាន</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060105.html?DbPAR=CALC">អនុគមន៍​តក្ក</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060106.html?DbPAR=CALC">អនុគមន៍​គណិតវិទ្យា</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060108.html?DbPAR=CALC">អនុគមន៍​ស្ថិតិ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060181.html?DbPAR=CALC">អនុគមន៍​ស្ថិតិ ផ្នែក​ទី​មួយ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060182.html?DbPAR=CALC">អនុគមន៍​ស្ថិតិ ផ្នែក​ទី​ពីរ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060183.html?DbPAR=CALC">អនុគមន៍​ស្ថិតិ ផ្នែក​ទី​បី</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060184.html?DbPAR=CALC">អនុគមន៍​ស្ថិតិ ផ្នែក​ទី​បួន</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060185.html?DbPAR=CALC">អនុគមន៍​ស្ថិតិ ផ្នែក​ទី​ប្រាំ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060109.html?DbPAR=CALC">អនុគមន៍​សៀវភៅ​បញ្ជី</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060110.html?DbPAR=CALC">អនុគមន៍​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060111.html?DbPAR=CALC">អនុគមន៍​បន្ថែម</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060115.html?DbPAR=CALC">អនុគមន៍​បន្ថែម បញ្ជី​នៃ​អនុគមន៍​វិភាគ ផ្នែក​ទី​មួយ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060116.html?DbPAR=CALC">អនុគមន៍​បន្ថែម បញ្ជី​នៃ​អនុគមន៍​វិភាគ ផ្នែក​ទី​ពីរ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/04060199.html?DbPAR=CALC">សញ្ញា​ប្រមាណ​វិធី​ក្នុ LibreOffice Calc</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/userdefined_function.html?DbPAR=CALC">អនុគមន៍​កំណត់​ដោយ​អ្នក​ប្រើ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/webquery.html?DbPAR=CALC">ការ​បញ្ចូល​ទិន្នន័យ​ខាង​ក្រៅ​ក្នុង​តារាង (WebQuery)</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/html_doc.html?DbPAR=CALC">ការ​រក្សា​ទុក និង​បើក​សន្លឹក​ក្នុង HTML</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/csv_formula.html?DbPAR=CALC">ការ​នាំ​ចូល និង​នាំ​ចេញ​ឯកសារ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">ការ​​ធ្វើ​ទ្រង់ទ្រាយ</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/text_rotate.html?DbPAR=CALC">ការ​បង្វិល​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/text_wrap.html?DbPAR=CALC">ការ​សរសេរ​អត្ថបទ​ច្រើន​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/text_numbers.html?DbPAR=CALC">ការ​ធ្វើ​ទ្រង់ទ្រាយ​លេខ​ជា​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/super_subscript.html?DbPAR=CALC">អក្សរ​តូច​លើ / អក្សរ​តូច​ក្រោម​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/row_height.html?DbPAR=CALC">ការ​ផ្លាស់ប្តូរ​កម្ពស់​ជួរ​ដេក ឬ​ទទឹង​ជួរ​ឈរ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">ការ​អនុវត្ត​ទ្រង់ទ្រាយ​តាម​លក្ខខណ្ឌ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">ការ​បន្លិច​លេខ​អវិជ្ជមាន</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">ការ​ផ្តល់​ទ្រង់ទ្រាយ​ដោយ​រូបមន្ត</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">ការ​បញ្ចូល​លេខ​ដែល​ផ្តើម​ដោយ​លេខ​សូន្យ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/format_table.html?DbPAR=CALC">ការ​ធ្វើ​ទ្រង់ទ្រាយ​សៀវភៅ​បញ្ជី</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/format_value.html?DbPAR=CALC">ការ​ធ្វើ​ទ្រង់ទ្រាយ​លេខ​ជា​ទសភាគ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/value_with_name.html?DbPAR=CALC">ការ​ដាក់​ឈ្មោះ​ក្រឡា</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/table_rotate.html?DbPAR=CALC">ការ​បង្វិល​តារាង (ការ​ផ្លាស់​កន្លែង)</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/rename_table.html?DbPAR=CALC">ការ​ប្តូរ​ឈ្មោះ​សន្លឹក</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/year2000.html?DbPAR=CALC">ឆ្នាំ 19xx/20xx</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">ការ​ប្រើ​លេខ​ដែល​បាន​បង្គត់​</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/currency_format.html?DbPAR=CALC">ក្រឡា​ក្នុង​ទ្រង់ទ្រាយ​រូបិយប័ណ្ណ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/autoformat.html?DbPAR=CALC">ការ​ប្រើ​ទ្រង់ទ្រាយ​ស្វ័យ​ប្រវត្តិ សម្រាប់​តារាង</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/note_insert.html?DbPAR=CALC">ការ​បញ្ចូល និង​កែសម្រួលមតិយោបល់</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/design.html?DbPAR=CALC">ការ​ជ្រើស​ស្បែក​សម្រាប់​សន្លឹក</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/fraction_enter.html?DbPAR=CALC">ការ​បញ្ចូល​ប្រភាគ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">តម្រង និង​តម្រៀប</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/filters.html?DbPAR=CALC">ការ​អនុវត្ត​តម្រង</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/specialfilter.html?DbPAR=CALC">តម្រង ៖ ការ​អនុវត្ត​តម្រង​កម្រិត​ខ្ពស់</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/autofilter.html?DbPAR=CALC">ការ​អនុវត្ត​តម្រង​ស្វ័យ​ប្រវត្តិ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/sorted_list.html?DbPAR=CALC">ការ​អនុវត្ត​បញ្ជី​តម្រៀប</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">ការ​បោះពុម្ព</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/print_title_row.html?DbPAR=CALC">ការ​បោះពុម្ព​ជួរ​ដេក ឬ​ជួរ​ឈរ​លើ​គ្រប់​ទំព័រ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/print_landscape.html?DbPAR=CALC">ការ​បោះពុម្ព​សន្លឹក​ក្នុង​ទ្រង់ទ្រាយ​ផ្ដេក</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/print_details.html?DbPAR=CALC">ការ​បោះពុម្ព​សេចក្តី​លម្អិត​សន្លឹក</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/print_exact.html?DbPAR=CALC">ការ​កំណត់​ចំនួន​ទំព័រ​សម្រាប់​បោះពុម្ព</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">ជួរ​ទិន្នន័យ</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/database_define.html?DbPAR=CALC">ការ​កំណត់​ជួរ​មូលដ្ឋាន​ទិន្នន័យ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/database_filter.html?DbPAR=CALC">ការច្រោះ​ជួរ​ក្រឡា</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/database_sort.html?DbPAR=CALC">តម្រៀប​ទិន្នន័យ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">តារាង​អ្នក​​ជំនួយ​ការ​ទិន្នន័យ</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/datapilot.html?DbPAR=CALC">តារាង​អ្នក​​ជំនួយ​ការ​ទិន្នន័យ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">ការ​បង្កើត​តារាង​អ្នកជំនួយការ​ទិន្នន័យ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">ការ​លុប​​តារាង​អ្នក​ជំនួយ​ការ​ទិន្នន័យ​</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">ការ​កែ​សម្រួល​តារាង​អ្នក​ជំនួយ​ការ​ទិន្នន័យ​</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">ការ​ត្រង​តារាង​អ្នក​ជំនួយ​ការ​ទិន្នន័យ​</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">ការ​ជ្រើស​ជួរ​លទ្ធផល​តារាង​​អ្នក​ជំនួយ​ការ​​ទិន្នន័យ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">ធ្វើ​បច្ចុប្បន្នភាព​តារាង​អ្នកជំនួយ​ការ​ទិន្នន័យ</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivot Chart</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">ឆាក</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/scenario.html?DbPAR=CALC">ប្រើ​សាច់រឿង</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotals</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">សេចក្ដីយោង</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">អាសយដ្ឋាន និង​សេចក្ដីយោង​ដាច់ខាត និង​ប្រែប្រួល</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/cellreferences.html?DbPAR=CALC">ការ​យោង​ក្រឡា​មួយ​ក្នុង​ឯកសារ​ផ្សេង​ទៀត</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">សេចក្តី​យោង​ទៅ​សន្លឹក​ផ្សេង និង​ការ​យោង URLs</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">ការ​យោង​ក្រឡា​ដោយ​អូស និង​ទម្លាក់</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/address_auto.html?DbPAR=CALC">ការ​ទទួល​ស្គាល់​ឈ្មោះ​ជា​អាសយដ្ឋាន</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">ការ​មើល ជ្រើស និង​ចម្លង</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/table_view.html?DbPAR=CALC">ការ​ផ្លាស់ប្តូរ​ទិដ្ឋភាព​តារាង</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/formula_value.html?DbPAR=CALC">ការ​បង្ហាញ​រូបមន្ត ឬ​តម្លៃ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/line_fix.html?DbPAR=CALC">ការ​បង្កក​ជួរ​ដេក ឬ​ជួរ​ឈរ​ជា​ក្បាល</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/multi_tables.html?DbPAR=CALC">ការ​រុករក​តាម​រយៈ​ផ្ទាំង​សន្លឹក</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/edit_multitables.html?DbPAR=CALC">ការ​ចម្លង​ទៅ​សន្លឹក​ច្រើន</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/cellcopy.html?DbPAR=CALC">ចម្លង​តែ​ក្រឡា​ដែល​មើល​ឃើញ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/mark_cells.html?DbPAR=CALC">ការ​ជ្រើស​ក្រឡា​ច្រើន</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">រូបមន្ត និង​ការ​គណនា</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/formulas.html?DbPAR=CALC">ការ​គណនា​ជាមួយ​រូបមន្ត</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/formula_copy.html?DbPAR=CALC">ការ​ចម្លង​រូបមន្ត</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/formula_enter.html?DbPAR=CALC">ការ​បញ្ចូល​រូបមន្ត</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/formula_value.html?DbPAR=CALC">ការ​បង្ហាញ​រូបមន្ត ឬ​តម្លៃ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/calculate.html?DbPAR=CALC">ការ​គណនា​ក្នុង​សៀវភៅ​បញ្ជី</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/calc_date.html?DbPAR=CALC">ការ​គណនា​ជាមួយ​កាល​បរិច្ឆេទ និង​ពេល​វេលា</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/calc_series.html?DbPAR=CALC">ការ​គណនា​ស៊េរី​ដោយ​ស្វ័យ​ប្រវត្តិ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">ការ​គណនា​ភាព​ខុស​គ្នា​នៃ​ពេល​វេលា</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/matrixformula.html?DbPAR=CALC">ការ​បញ្ចូល​រូបមន្ត ម៉ាទ្រីស</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">ការ​ការពារ</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/cell_protect.html?DbPAR=CALC">ការ​ការពារ​ក្រឡា​ពី​ការ​ផ្លាស់ប្តូរ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">ការ​មិន​ការពារ​ក្រឡា</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">ផ្សេងៗ</label><ul>\
    <li><a target="_top" href="km/text/scalc/guide/auto_off.html?DbPAR=CALC">ការ​ធ្វើ​ឲ្យ​ការ​ផ្លាស់ប្តូរ​ស្វ័យ​ប្រវត្តិ​អសកម្ម</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/consolidate.html?DbPAR=CALC">ការ​បង្រួប​បង្រួម​ទិន្នន័យ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/goalseek.html?DbPAR=CALC">ការ​អនុវត្ត​សមីការ</a></li>\
    <li><a target="_top" href="km/text/scalc/01/solver.html?DbPAR=CALC">កម្មវិធី​ដោះស្រាយ</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/multioperation.html?DbPAR=CALC">ការ​អនុវត្ត​ប្រមាណ​វិធី​ច្រើន</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/multitables.html?DbPAR=CALC">ការ​អនុវត្ត​សន្លឹក​ច្រើន</a></li>\
    <li><a target="_top" href="km/text/scalc/guide/validity.html?DbPAR=CALC">សុពលភាព​នៃ​មាតិកា​ក្រឡា</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentations (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">ព័ត៌មាន​ទូទៅ និង​ការ​ប្រើ​ចំណុចប្រទាក់​អ្នកប្រើ</label><ul>\
    <li><a target="_top" href="km/text/simpress/main0000.html?DbPAR=IMPRESS">សូម​ស្វាគមន៍​​មក​កាន់​​ជំនួយ​របស់​ LibreOffice Impress</a></li>\
    <li><a target="_top" href="km/text/simpress/main0503.html?DbPAR=IMPRESS">លក្ខណៈ​ពិសេស​របស់​ LibreOffice Impress</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">ការ​ប្រើ​គ្រាប់ចុច​ផ្លូវកាត់​ក្នុង LibreOffice Impress</a></li>\
    <li><a target="_top" href="km/text/simpress/04/01020000.html?DbPAR=IMPRESS">គ្រាប់​ចុច​ផ្លូវ​កាត់​សម្រាប់​ LibreOffice Impress​</a></li>\
    <li><a target="_top" href="km/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Keyboard Shortcuts</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/main.html?DbPAR=IMPRESS">សេចក្តី​ណែ​នាំ​​ដើម្បី​​ប្រើ​ LibreOffice Impress</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">ពាក្យ​បញ្ជា និង​សេចក្ដីយោង​ម៉ឺនុយ</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">ម៉ឺនុយ</label><ul>\
    <li><a target="_top" href="km/text/simpress/main0100.html?DbPAR=IMPRESS">ម៉ឺនុយ</a></li>\
    <li><a target="_top" href="km/text/simpress/main0101.html?DbPAR=IMPRESS">ឯកសារ</a></li>\
    <li><a target="_top" href="km/text/simpress/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="km/text/simpress/main0103.html?DbPAR=IMPRESS">ទិដ្ឋភាព</a></li>\
    <li><a target="_top" href="km/text/simpress/main0104.html?DbPAR=IMPRESS">បញ្ចូល</a></li>\
    <li><a target="_top" href="km/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="km/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="km/text/simpress/main0114.html?DbPAR=IMPRESS">បញ្ចាំង​ស្លាយ</a></li>\
    <li><a target="_top" href="km/text/simpress/main_tools.html?DbPAR=IMPRESS">Tools</a></li>\
    <li><a target="_top" href="km/text/simpress/main0107.html?DbPAR=IMPRESS">បង្អួច</a></li>\
    <li><a target="_top" href="km/text/shared/main0108.html?DbPAR=IMPRESS">ជំនួយ</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">របារ​ឧបករណ៍</label><ul>\
    <li><a target="_top" href="km/text/simpress/main0200.html?DbPAR=IMPRESS">របារ​ឧបករណ៍</a></li>\
    <li><a target="_top" href="km/text/simpress/main0202.html?DbPAR=IMPRESS">របារ​បន្ទាត់ និង​បំពេញ</a></li>\
    <li><a target="_top" href="km/text/simpress/main0203.html?DbPAR=IMPRESS">របារ​ធ្វើ​ទ្រង់​ទ្រាយ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/simpress/main0204.html?DbPAR=IMPRESS">របារ​ទិដ្ឋភាព​ស្លាយ</a></li>\
    <li><a target="_top" href="km/text/simpress/main0206.html?DbPAR=IMPRESS">របារ​ស្ថានភាព</a></li>\
    <li><a target="_top" href="km/text/simpress/main0209.html?DbPAR=IMPRESS">បន្ទាត់</a></li>\
    <li><a target="_top" href="km/text/simpress/main0210.html?DbPAR=IMPRESS">របារគូរ</a></li>\
    <li><a target="_top" href="km/text/simpress/main0211.html?DbPAR=IMPRESS">របារ​គ្រោង</a></li>\
    <li><a target="_top" href="km/text/simpress/main0212.html?DbPAR=IMPRESS">របារ​ឧបករណ៍​តម្រៀប​ស្លាយ</a></li>\
    <li><a target="_top" href="km/text/simpress/main0213.html?DbPAR=IMPRESS">របារ​ជម្រើស</a></li>\
    <li><a target="_top" href="km/text/simpress/main0214.html?DbPAR=IMPRESS">Image Bar</a></li>\
    <li><a target="_top" href="km/text/shared/main0201.html?DbPAR=IMPRESS">របារ​ស្តង់ដារ</a></li>\
    <li><a target="_top" href="km/text/shared/main0213.html?DbPAR=IMPRESS">របារ​រុករក​សំណុំ​បែបបទ</a></li>\
    <li><a target="_top" href="km/text/shared/main0226.html?DbPAR=IMPRESS">របារ​រចនា​សំណុំ​បែបបទ</a></li>\
    <li><a target="_top" href="km/text/shared/main0227.html?DbPAR=IMPRESS">របារ កែសម្រួល​ចំណុច</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="km/text/simpress/guide/html_export.html?DbPAR=IMPRESS">ការ​រក្សា​ទុក​ការ​បង្ហាញ​ក្នុង​ទ្រង់​ទ្រាយ​ HTML ។</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/html_import.html?DbPAR=IMPRESS">ការ​នាំ​ចូល​ទំព័រ​ HTML ទៅ​ក្នុង​ការ​បង្ហាញ</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">កំពុង​ផ្ទុក​បញ្ជី​ ពណ៌​ ពណ៌​ជម្រាល​ និង​ ឆ្នូត​ៗ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">កំពុង​នាំ​ចេញ​ចលនា​ក្នុង​ទ្រង់​ទ្រាយ​ GIF</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">រួម​ទាំង​សៀវភៅ​បញ្ជី​ក្នុង​ស្លាយ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">ការ​បញ្ចូល​ក្រាហ្វិក</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">កំពុង​ចម្លង​ស្លាយ​ពី​ការ​បង្ហាញ​ដទៃ​ទៀត​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">ការ​​ធ្វើ​ទ្រង់ទ្រាយ</label><ul>\
    <li><a target="_top" href="km/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">កំពុង​ផ្ទុក​បញ្ជី​ ពណ៌​ ពណ៌​ជម្រាល​ និង​ ឆ្នូត​ៗ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">ការ​ផ្ទុក​រចនាប័ទ្ម​​​បន្ទាត់​ និង​ ព្រួញ​​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">ការ​កំណត់​ពណ៌​ផ្ទាល់​ខ្លួន​​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">បង្កើត​ការ​បំពេញ​ពណ៌​ជម្រាល​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">ការ​ជំនួស​ពណ៌​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">ការ​រៀប​ចំ ការ​តម្រឹម​ និង​ការ​ចែក​ចាយ​ វត្ថុ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/background.html?DbPAR=IMPRESS">ការ​ផ្លាស់​ប្តូរ​ការ​បំពេញ​ផ្ទៃ​ខាង​ក្រោយ​ស្លាយ</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/footer.html?DbPAR=IMPRESS">ការ​បន្ថែម​ បឋមកថា​ ឬ​ បាត​កថា​មួយ ​ទៅ​គ្រប់​ស្លាយ​ទាំង​អស់</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/move_object.html?DbPAR=IMPRESS">ការ​ផ្លាស់​ទី​វត្ថុ​</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">ការ​បោះពុម្ព</label><ul>\
    <li><a target="_top" href="km/text/simpress/guide/printing.html?DbPAR=IMPRESS">ការ​បោះ​ពុម្ព​ការ​បង្ហាញ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">ការ​បោះ​ពុម្ព​ស្លាយ ​ឲ្យ​សម​នឹង​ទំហំ​ក្រដាស​មួយ​</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">បែបផែន</label><ul>\
    <li><a target="_top" href="km/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">កំពុង​នាំ​ចេញ​ចលនា​ក្នុង​ទ្រង់​ទ្រាយ​ GIF</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">ការ​ធ្វើ​ឲ្យ​វត្ថុ​មាន​ចលនា​ ក្នុង​​​ស្លាយ​បង្ហាញ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">​ដំណើរ​ផ្លាស់​ប្តូរ​ស្លាយ​​​មាន​ចលនា​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">វត្ថុ​ពីរ​​លេច​កាត់​​បន្តិច​ម្តងៗ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">ការ​បង្កើត​រូប​ភាព​ GFI ដែល​មាន​ចលនា​</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">វត្ថុ ក្រាហ្វិក និង​រូបភាព</label><ul>\
    <li><a target="_top" href="km/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">ការ​​​ផ្សំ​វត្ថុ​ និង​ ការសង់​រាង​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/groups.html?DbPAR=IMPRESS">ការ​ដាក់​វត្ថុ​ជា​ក្រុម​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">ការ​គូរ​ចម្រៀង និង​ភាគ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">ការ​ចម្លង​វត្ថុ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">ការ​បង្វិល​វត្ថុ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">បណ្តុំ​​វត្ថុ​​​ត្រីមាត្រ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">ការ​តភ្ជាប់​បន្ទាត់​​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">ការ​បម្លែង​តួអក្សរ​អត្ថបទ​ជា​វត្ថុ​គំនូរ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">បម្លែង​រូប​ភាព​ប្រភេទ​(GIF,JPG,PNG)​ ​​ជា​​ក្រាហ្វិក​​​វ៉ិចទ័រ​​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">ការ​បម្លែង​វត្ថុ​ទ្វេមាត្រ​ជា​ខ្សែ​​កោង ​ជា​ពហុ​កោណ​ និង​ ​ជា​វត្ថុ​ត្រីមាត្រ</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">ការ​ផ្ទុក​រចនាប័ទ្ម​​​បន្ទាត់​ និង​ ព្រួញ​​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">ការ​គូរ​ខ្សែ​កោង​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">ការ​កែ​សម្រួល​ខ្សែ​កោង​​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">ការ​បញ្ចូល​ក្រាហ្វិក</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">រួម​ទាំង​សៀវភៅ​បញ្ជី​ក្នុង​ស្លាយ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/move_object.html?DbPAR=IMPRESS">ការ​ផ្លាស់​ទី​វត្ថុ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/select_object.html?DbPAR=IMPRESS">ការ​ជ្រើស​វត្ថុ​ដែល​នៅ​ក្រោម​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">ការ​បង្កើត​​​គំនូស​តាង​លំហូ​មួយ</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text in Presentations</label><ul>\
    <li><a target="_top" href="km/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">ការ​បន្ថែម​អត្ថបទ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">ការ​បម្លែង​តួអក្សរ​អត្ថបទ​ជា​វត្ថុ​គំនូរ​</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">ការ​មើល</label><ul>\
    <li><a target="_top" href="km/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">កំពុង​ផ្លាស់​ប្តូរ​លំដាប់​ស្លាយ</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">ពង្រីក​ដោយ​ប្រើ​បន្ទះ​គ្រាប់​ចុច​</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Slide Shows</label><ul>\
    <li><a target="_top" href="km/text/simpress/guide/show.html?DbPAR=IMPRESS">បង្ហាញ​ការ​បញ្ចាំង​ស្លាយ</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/individual.html?DbPAR=IMPRESS">ការ​បង្កើត​​ការ​បញ្ចាំង​ផ្ទាល់​ខ្លួន​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">ពេល​វេលា​សម​នៃ​ការ​​ផ្លាស់​ប្តូរ​ស្លាយ​</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Drawings (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="km/text/sdraw/main0000.html?DbPAR=DRAW">សូម​ស្វាគមន៍ការ​​មក​កាន់​ជំនួយ​របស់​ LibreOffice Draw​​​</a></li>\
    <li><a target="_top" href="km/text/sdraw/main0503.html?DbPAR=DRAW">លក្ខណៈ​ពិសេស​របស់ LibreOffice ​​Draw</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/keyboard.html?DbPAR=DRAW">គ្រាប់​ចុច​ផ្លូវ​កាត់​សម្រាប់​វត្ថុ​គំនូរ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/04/01020000.html?DbPAR=DRAW">គ្រាប់​ចុច​ផ្លូវ​កាត់ ​សម្រាប់​គំនូរ</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/main.html?DbPAR=DRAW">សេចក្តី​ណែនាំ​ដើម្បី​ប្រើ​ LibreOffice Draw</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menus</label><ul>\
    <li><a target="_top" href="km/text/sdraw/main0100.html?DbPAR=DRAW">ម៉ឺនុយ</a></li>\
    <li><a target="_top" href="km/text/sdraw/main0101.html?DbPAR=DRAW">ឯកសារ</a></li>\
    <li><a target="_top" href="km/text/sdraw/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="km/text/sdraw/main0103.html?DbPAR=DRAW">ទិដ្ឋភាព</a></li>\
    <li><a target="_top" href="km/text/sdraw/main_insert.html?DbPAR=DRAW">Insert</a></li>\
    <li><a target="_top" href="km/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="km/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="km/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="km/text/sdraw/main_tools.html?DbPAR=DRAW">Tools</a></li>\
    <li><a target="_top" href="km/text/simpress/main0107.html?DbPAR=DRAW">បង្អួច</a></li>\
    <li><a target="_top" href="km/text/shared/main0108.html?DbPAR=DRAW">ជំនួយ</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Toolbars</label><ul>\
    <li><a target="_top" href="km/text/sdraw/main0200.html?DbPAR=DRAW">របារ​ឧបករណ៍</a></li>\
    <li><a target="_top" href="km/text/sdraw/main0210.html?DbPAR=DRAW">របារគូរ</a></li>\
    <li><a target="_top" href="km/text/sdraw/main0213.html?DbPAR=DRAW">របារ​ជម្រើស</a></li>\
    <li><a target="_top" href="km/text/shared/main0201.html?DbPAR=DRAW">របារ​ស្តង់ដារ</a></li>\
    <li><a target="_top" href="km/text/shared/main0213.html?DbPAR=DRAW">របារ​រុករក​សំណុំ​បែបបទ</a></li>\
    <li><a target="_top" href="km/text/shared/main0226.html?DbPAR=DRAW">របារ​រចនា​សំណុំ​បែបបទ</a></li>\
    <li><a target="_top" href="km/text/shared/main0227.html?DbPAR=DRAW">របារ កែសម្រួល​ចំណុច</a></li>\
    <li><a target="_top" href="km/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D-Settings</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Loading, Saving, Importing, and Exporting</label><ul>\
    <li><a target="_top" href="km/text/simpress/guide/palette_files.html?DbPAR=DRAW">កំពុង​ផ្ទុក​បញ្ជី​ ពណ៌​ ពណ៌​ជម្រាល​ និង​ ឆ្នូត​ៗ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">ការ​បញ្ចូល​ក្រាហ្វិក</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatting</label><ul>\
    <li><a target="_top" href="km/text/simpress/guide/palette_files.html?DbPAR=DRAW">កំពុង​ផ្ទុក​បញ្ជី​ ពណ៌​ ពណ៌​ជម្រាល​ និង​ ឆ្នូត​ៗ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">ការ​ផ្ទុក​រចនាប័ទ្ម​​​បន្ទាត់​ និង​ ព្រួញ​​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/color_define.html?DbPAR=DRAW">ការ​កំណត់​ពណ៌​ផ្ទាល់​ខ្លួន​​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/gradient.html?DbPAR=DRAW">បង្កើត​ការ​បំពេញ​ពណ៌​ជម្រាល​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">ការ​ជំនួស​ពណ៌​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">ការ​រៀប​ចំ ការ​តម្រឹម​ និង​ការ​ចែក​ចាយ​ វត្ថុ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/background.html?DbPAR=DRAW">ការ​ផ្លាស់​ប្តូរ​ការ​បំពេញ​ផ្ទៃ​ខាង​ក្រោយ​ស្លាយ</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/move_object.html?DbPAR=DRAW">ការ​ផ្លាស់​ទី​វត្ថុ​</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Printing</label><ul>\
    <li><a target="_top" href="km/text/simpress/guide/printing.html?DbPAR=DRAW">ការ​បោះ​ពុម្ព​ការ​បង្ហាញ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/print_tofit.html?DbPAR=DRAW">ការ​បោះ​ពុម្ព​ស្លាយ ​ឲ្យ​សម​នឹង​ទំហំ​ក្រដាស​មួយ​</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effects</label><ul>\
    <li><a target="_top" href="km/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">វត្ថុ​ពីរ​​លេច​កាត់​​បន្តិច​ម្តងៗ​</a></li>\
    <li><a target="_top" href="km/text/shared/01/05350000.html?DbPAR=DRAW">បែបផែន​ត្រីមាត្រ</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objects, Graphics, and Bitmaps</label><ul>\
    <li><a target="_top" href="km/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">ការ​​​ផ្សំ​វត្ថុ​ និង​ ការសង់​រាង​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">ការ​គូរ​ចម្រៀង និង​ភាគ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">ការ​ចម្លង​វត្ថុ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">ការ​បង្វិល​វត្ថុ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">បណ្តុំ​​វត្ថុ​​​ត្រីមាត្រ​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/join_objects.html?DbPAR=DRAW">ការ​តភ្ជាប់​បន្ទាត់​​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/text2curve.html?DbPAR=DRAW">ការ​បម្លែង​តួអក្សរ​អត្ថបទ​ជា​វត្ថុ​គំនូរ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/vectorize.html?DbPAR=DRAW">បម្លែង​រូប​ភាព​ប្រភេទ​(GIF,JPG,PNG)​ ​​ជា​​ក្រាហ្វិក​​​វ៉ិចទ័រ​​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/3d_create.html?DbPAR=DRAW">ការ​បម្លែង​វត្ថុ​ទ្វេមាត្រ​ជា​ខ្សែ​​កោង ​ជា​ពហុ​កោណ​ និង​ ​ជា​វត្ថុ​ត្រីមាត្រ</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">ការ​ផ្ទុក​រចនាប័ទ្ម​​​បន្ទាត់​ និង​ ព្រួញ​​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/line_draw.html?DbPAR=DRAW">ការ​គូរ​ខ្សែ​កោង​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/line_edit.html?DbPAR=DRAW">ការ​កែ​សម្រួល​ខ្សែ​កោង​​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">ការ​បញ្ចូល​ក្រាហ្វិក</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/table_insert.html?DbPAR=DRAW">រួម​ទាំង​សៀវភៅ​បញ្ជី​ក្នុង​ស្លាយ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/move_object.html?DbPAR=DRAW">ការ​ផ្លាស់​ទី​វត្ថុ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/select_object.html?DbPAR=DRAW">ការ​ជ្រើស​វត្ថុ​ដែល​នៅ​ក្រោម​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/orgchart.html?DbPAR=DRAW">ការ​បង្កើត​​​គំនូស​តាង​លំហូ​មួយ</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Groups and Layers</label><ul>\
    <li><a target="_top" href="km/text/sdraw/guide/groups.html?DbPAR=DRAW">ការ​ដាក់​វត្ថុ​ជា​ក្រុម​</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserting Layers</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="km/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text in Drawings</label><ul>\
    <li><a target="_top" href="km/text/sdraw/guide/text_enter.html?DbPAR=DRAW">ការ​បន្ថែម​អត្ថបទ​</a></li>\
    <li><a target="_top" href="km/text/simpress/guide/text2curve.html?DbPAR=DRAW">ការ​បម្លែង​តួអក្សរ​អត្ថបទ​ជា​វត្ថុ​គំនូរ​</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Viewing</label><ul>\
    <li><a target="_top" href="km/text/simpress/guide/change_scale.html?DbPAR=DRAW">ពង្រីក​ដោយ​ប្រើ​បន្ទះ​គ្រាប់​ចុច​</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Database Functionality (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">General Information</label><ul>\
    <li><a target="_top" href="km/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="km/text/shared/guide/database_main.html?DbPAR=BASE">ទិដ្ឋភាព​ទូទៅរបស់​​មូល​ដ្ឋាន​ទិន្នន័យ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_new.html?DbPAR=BASE">ការ​បង្កើត​មូលដ្ឋាន​ទិន្នន័យ​ថ្មី​មួយ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_tables.html?DbPAR=BASE">ការ​ធ្វើ​ការ​ជាមួយ​តារាង​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_queries.html?DbPAR=BASE">ការ​​ធ្វើ​ការ​ជាមួយ​សំណួរ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_forms.html?DbPAR=BASE">ការ​ធ្វើ​ការ​ជាមួយ​សំណុំ​បែប​បទ​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_reports.html?DbPAR=BASE">បង្កើត​របាយការណ៍</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_register.html?DbPAR=BASE">ការ​ចុះឈ្មោះ​ និង លុប​មូលដ្ឋានទិន្នន័យ​មួយ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_im_export.html?DbPAR=BASE">នាំចេញ និង​នាំចូល​ទិន្នន័យ​ក្នុង Base</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_enter_sql.html?DbPAR=BASE">ការ​ប្រតិបត្តិ​ពាក្យ​បញ្ជា​ SQL</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formulas (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">ព័ត៌មាន​ទូទៅ និង​ការ​ប្រើ​ចំណុច​ប្រទាក់​អ្នកប្រើ</label><ul>\
    <li><a target="_top" href="km/text/smath/main0000.html?DbPAR=MATH">សូម​ស្វាគមន៍​មក​កាន់​ជំនួយ​ LibreOffice Math​</a></li>\
    <li><a target="_top" href="km/text/smath/main0503.html?DbPAR=MATH">លក្ខណៈ​ពិសេស​របស់ LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formula Elements</label><ul>\
    <li><a target="_top" href="km/text/smath/01/03090100.html?DbPAR=MATH">សញ្ញា​ប្រមាណ​វិធី​មួយ​អង្គ/ពីរ​អង្គ</a></li>\
    <li><a target="_top" href="km/text/smath/01/03090200.html?DbPAR=MATH">ទំនាក់​ទំនង</a></li>\
    <li><a target="_top" href="km/text/smath/01/03090800.html?DbPAR=MATH">សញ្ញា​ប្រមាណ​វិធី​សំណុំ</a></li>\
    <li><a target="_top" href="km/text/smath/01/03090400.html?DbPAR=MATH">អនុគមន៍</a></li>\
    <li><a target="_top" href="km/text/smath/01/03090300.html?DbPAR=MATH">សញ្ញា​ប្រមាណ​វិធី</a></li>\
    <li><a target="_top" href="km/text/smath/01/03090600.html?DbPAR=MATH">គុណ​លក្ខណៈ</a></li>\
    <li><a target="_top" href="km/text/smath/01/03090500.html?DbPAR=MATH">តង្កៀប</a></li>\
    <li><a target="_top" href="km/text/smath/01/03090700.html?DbPAR=MATH">ទ្រង់ទ្រាយ</a></li>\
    <li><a target="_top" href="km/text/smath/01/03091600.html?DbPAR=MATH">និមិត្ត​សញ្ញា​ផ្សេង​ទៀត</a></li>\
            </ul></li>\
    <li><a target="_top" href="km/text/smath/guide/main.html?DbPAR=MATH">សេចក្តី​ណែនាំ​សម្រាប់​ការ​ប្រើ​ប្រាស់ LibreOffice Math</a></li>\
    <li><a target="_top" href="km/text/smath/guide/keyboard.html?DbPAR=MATH">ផ្លូវ​កាត់ (ភាព​​អាច​ចូល​ដំណើរ​ការ​បាន​របស់ LibreOffice Math)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">ពាក្យ​បញ្ជា និង​សេចក្ដីយោង​ម៉ឺនុយ</label><ul>\
    <li><a target="_top" href="km/text/smath/main0100.html?DbPAR=MATH">ម៉ឺនុយ</a></li>\
    <li><a target="_top" href="km/text/smath/main0200.html?DbPAR=MATH">របារ​ឧបករណ៍</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">ការ​ធ្វើការ​ជាមួួ​រូបមន្ត</label><ul>\
    <li><a target="_top" href="km/text/smath/guide/align.html?DbPAR=MATH">ការ​តម្រឹម​ផ្នែក​រូបមន្ត​ដោយ​ដៃ</a></li>\
    <li><a target="_top" href="km/text/smath/guide/attributes.html?DbPAR=MATH">ការ​ប្តូរ​គុណ​លក្ខណៈ​លំនាំដើម</a></li>\
    <li><a target="_top" href="km/text/smath/guide/brackets.html?DbPAR=MATH">ការ​បញ្ចូល​ផ្នែក​រូបមន្ត​ចូល​គ្នា​ក្នុង​តង្កៀប</a></li>\
    <li><a target="_top" href="km/text/smath/guide/comment.html?DbPAR=MATH">ការ​បញ្ចូល​មតិយោបល់</a></li>\
    <li><a target="_top" href="km/text/smath/guide/newline.html?DbPAR=MATH">ការ​បញ្ចូល​កា​រចុះ​បន្ទាត់</a></li>\
    <li><a target="_top" href="km/text/smath/guide/parentheses.html?DbPAR=MATH">ការ​​បញ្ចូល​តង្កៀប</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">គំនូសតាង និង​ដ្យាក្រាម</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">ព័ត៌មាន​ទូទៅ</label><ul>\
    <li><a target="_top" href="km/text/schart/main0000.html?DbPAR=CHART">គំនូស​តាង​ក្នុង LibreOffice</a></li>\
    <li><a target="_top" href="km/text/schart/main0503.html?DbPAR=CHART">លក្ខណៈ​ពិសេស​របស់ LibreOffice Chart</a></li>\
    <li><a target="_top" href="km/text/schart/04/01020000.html?DbPAR=CHART">ផ្លូវ​កាត់​ សម្រាប់​គំនូស​តាង​</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Macros and Scripting</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="km/text/sbasic/shared/main0601.html?DbPAR=BASIC">ជំនួយ LibreOffice Basic</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01000000.html?DbPAR=BASIC">សរសេរ​កម្មវិធី​ជាមួយ LibreOffice Basic</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/00000002.html?DbPAR=BASIC">សទ្ទានុក្រម​មូលដ្ឋាន LibreOffice</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01010210.html?DbPAR=BASIC">មូលដ្ឋាន​</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01020000.html?DbPAR=BASIC">វាក្យ​សម្ពន្ធ​​</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01030100.html?DbPAR=BASIC">ទិដ្ឋភាព IDE ទូទៅ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01030200.html?DbPAR=BASIC">កម្មវិធី​និពន្ធ Basic</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01050100.html?DbPAR=BASIC">បង្អួច​ការ​ឃ្លាំ​មើល</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/main0211.html?DbPAR=BASIC">របារ​ឧបករណ៍​ម៉ាក្រូ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/05060700.html?DbPAR=BASIC">ម៉ាក្រូ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Command Reference</label><ul>\
    <li><a target="_top" href="km/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01020500.html?DbPAR=BASIC">បណ្ណាល័យ ម៉ូឌុល និង​ប្រអប់</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Functions, Statements, and Operators</label><ul>\
    <li><a target="_top" href="km/text/sbasic/shared/03010000.html?DbPAR=BASIC">អនុគមន៍​អេក្រង់ I/O</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020000.html?DbPAR=BASIC">អនុគមន៍ File I/O</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030000.html?DbPAR=BASIC">អនុគមន៍​កាល​បរិច្ឆេទ និង​ពេល​វេលា</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03050000.html?DbPAR=BASIC">អនុគមន៍ ដោះស្រាយ​កំហុស</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03060000.html?DbPAR=BASIC">សញ្ញា​ប្រមាណ​វិធី​តក្ក​វិជ្ជា</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03070000.html?DbPAR=BASIC">សញ្ញា​ប្រមាណវិធី​គណិតវិទ្យា</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080000.html?DbPAR=BASIC">អនុគមន៍​លេខ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090000.html?DbPAR=BASIC">ការ​ត្រួតត្រា​ដំណើរការ​ប្រតិបត្តិ​កម្មវិធី</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100000.html?DbPAR=BASIC">អថេរ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03110000.html?DbPAR=BASIC">សញ្ញា​ប្រមាណ​វិធី​ប្រៀបធៀប</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120000.html?DbPAR=BASIC">ខ្សែ​អក្សរ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Calling Calc Functions in Macros</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03130000.html?DbPAR=BASIC">ពាក្យ​បញ្ជា​ផ្សេង​ទៀត</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alphabetic List of Functions, Statements, and Operators</label><ul>\
    <li><a target="_top" href="km/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03050000.html?DbPAR=BASIC">អនុគមន៍ ដោះស្រាយ​កំហុស</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090400.html?DbPAR=BASIC">សេចក្តី​ថ្លែង​ការណ៍ Further</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080300.html?DbPAR=BASIC">ការ​បង្កើត​ចំនួន​ចៃដន្យ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input # Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080000.html?DbPAR=BASIC">អនុគមន៍​លេខ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080400.html?DbPAR=BASIC">ការ​គណនា​ឫស​ការេ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03080100.html?DbPAR=BASIC">អនុគមន៍​ត្រីកោណមាត្រ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write Statement</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Advanced Basic Libraries</label><ul>\
    <li><a target="_top" href="km/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guides</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/macro_recording.html?DbPAR=BASIC">ការ​កត់​ត្រា​ម៉ាក្រូ​មួយ</a></li>\
    <li><a target="_top" href="km/text/sbasic/guide/control_properties.html?DbPAR=BASIC">ការ​ផ្លាស់​ប្តូរ​លក្ខណសម្បត្តិ​នៃ​វត្ថុ​បញ្ជា ក្នុង​កម្មវិធី​និពន្ធ​ប្រអប់</a></li>\
    <li><a target="_top" href="km/text/sbasic/guide/insert_control.html?DbPAR=BASIC">ការ​បង្កើត​វត្ថុ​បញ្ជា​ក្នុង​កម្មវិធី​និពន្ធ​ប្រអប់</a></li>\
    <li><a target="_top" href="km/text/sbasic/guide/sample_code.html?DbPAR=BASIC">ឧទាហរណ៍​កម្មវិធី សម្រាប់​វត្ថុ​បញ្ជា​ក្នុង​កម្មវិធី​និពន្ធ​ប្រអប់</a></li>\
    <li><a target="_top" href="km/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="km/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">ការ​បង្កើត​ប្រអប់ Basic មួយ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01030400.html?DbPAR=BASIC">ការ​រៀបចំ​បណ្ណាល័យ និង​ម៉ូឌុល</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01020100.html?DbPAR=BASIC">ការ​ប្រើ​អថេរ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01020200.html?DbPAR=BASIC">ការ​ប្រើ​វត្ថុ</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01030300.html?DbPAR=BASIC">ការ​បំបាត់​កំហុស​កម្មវិធី Basic</a></li>\
    <li><a target="_top" href="km/text/sbasic/shared/01040000.html?DbPAR=BASIC">ម៉ាក្រូ​ព្រឹត្តិការណ៍​ដែល​បាន​ផ្តល់</a></li>\
    <li><a target="_top" href="km/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="km/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic to Python</a></li>\
    <li><a target="_top" href="km/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python Scripts Help</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="km/text/sbasic/python/main0000.html?DbPAR=BASIC">Python Scripts</a></li>\
    <li><a target="_top" href="km/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE for Python</a></li>\
    <li><a target="_top" href="km/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="km/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programming with Python</label><ul>\
    <li><a target="_top" href="km/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="km/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python examples</a></li>\
    <li><a target="_top" href="km/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice Installation</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">ការ​ផ្លាស់​ប្តូរ​ការ​បញ្ចូល​នៃ​​ប្រភេទ​ឯកសារ​របស់ Microsoft Office</a></li>\
    <li><a target="_top" href="km/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Safe Mode</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">ប្រធានបទ​ជំនួយ​ទូទៅ</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">ព័ត៌មាន​ទូទៅ</label><ul>\
    <li><a target="_top" href="km/text/shared/main0400.html?DbPAR=SHARED">គ្រាប់​ចុច​ផ្លូវ​កាត់</a></li>\
    <li><a target="_top" href="km/text/shared/00/00000005.html?DbPAR=SHARED">សទ្ទានុក្រម​ទូទៅ</a></li>\
    <li><a target="_top" href="km/text/shared/00/00000002.html?DbPAR=SHARED">សទ្ទានុក្រម​ពាក្យ​អ៊ីនធឺណិត</a></li>\
    <li><a target="_top" href="km/text/shared/guide/accessibility.html?DbPAR=SHARED">ភាព​អាច​ចូល​ដំណើរ​ការ​ក្នុង​ LibreOffice</a></li>\
    <li><a target="_top" href="km/text/shared/guide/keyboard.html?DbPAR=SHARED">​ផ្លូវ​កាត់ (ភាព​អាច​​ចូល​ដំណើរ​ការ LibreOffice )</a></li>\
    <li><a target="_top" href="km/text/shared/04/01010000.html?DbPAR=SHARED">គ្រាប់​ចុច​ផ្លូវ​កាត់​ទូទៅ​ក្នុង LibreOffice​​​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/version_number.html?DbPAR=SHARED">កំណែ​ និង លេខ​ស្ថាបនា</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice និង Microsoft Office</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/ms_user.html?DbPAR=SHARED">ការ​ប្រើ​ Microsoft Office និង LibreOffice</a></li>\
    <li><a target="_top" href="km/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">ការ​ប្រៀប​ធៀប ​Microsoft Office និង ពាក្យ​របស់​ LibreOffice</a></li>\
    <li><a target="_top" href="km/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">អំពី​ការ​បម្លែង​ឯកសារ​របស់​ Microsoft Office</a></li>\
    <li><a target="_top" href="km/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">ការ​ផ្លាស់​ប្តូរ​ការ​បញ្ចូល​នៃ​​ប្រភេទ​ឯកសារ​របស់ Microsoft Office</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">ជម្រើស LibreOffice</label><ul>\
    <li><a target="_top" href="km/text/shared/optionen/01000000.html?DbPAR=SHARED">ជម្រើស</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01010100.html?DbPAR=SHARED">ទិន្នន័យ​​អ្នក​ប្រើ</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01010200.html?DbPAR=SHARED">ទូទៅ</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01010300.html?DbPAR=SHARED">ផ្លូវ</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01010400.html?DbPAR=SHARED">ជំនួយ​សរសេរ</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01010600.html?DbPAR=SHARED">ទូទៅ</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01010700.html?DbPAR=SHARED">ពុម្ព​​អក្សរ</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01010800.html?DbPAR=SHARED">ទិដ្ឋភាព</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01010900.html?DbPAR=SHARED">ជម្រើស​​បោះពុម្ព</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01012000.html?DbPAR=SHARED">Application Colors</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01013000.html?DbPAR=SHARED">ភាព​អាច​ចូល​ដំណើរ​ការ</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/java.html?DbPAR=SHARED">កម្រិត​ខ្ពស់</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/opencl.html?DbPAR=SHARED">Open CL</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01020000.html?DbPAR=SHARED">ជម្រើស​ផ្ទុក​/​រក្សា​ទុក</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01030000.html?DbPAR=SHARED">ជម្រើស​អ៊ីនធឺណិត</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01040000.html?DbPAR=SHARED">ជម្រើស​ឯកសារ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01050000.html?DbPAR=SHARED">ជម្រើស​​ឯកសារ HTML</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01060000.html?DbPAR=SHARED">ជម្រើស​សៀវភៅ​បញ្ជី</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01070000.html?DbPAR=SHARED">ជម្រើស​ការ​បង្ហាញ</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01080000.html?DbPAR=SHARED">ជម្រើស​គំនូរ</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01090000.html?DbPAR=SHARED">រូបមន្ត</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01110000.html?DbPAR=SHARED">ជម្រើស​គំនូស​តាង</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01130100.html?DbPAR=SHARED">លក្ខណសម្បត្តិ VBA</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01140000.html?DbPAR=SHARED">ភាសា</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01150000.html?DbPAR=SHARED">ជម្រើស​ការ​កំណត់​ភាសា</a></li>\
    <li><a target="_top" href="km/text/shared/optionen/01160000.html?DbPAR=SHARED">ជម្រើស​ប្រភព​ទិន្នន័យ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">អ្នកជំនួយការ</label><ul>\
    <li><a target="_top" href="km/text/shared/autopi/01000000.html?DbPAR=SHARED">អ្នក​ជំនួយ​ការ​​</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">អ្នក​ជំនួយការ​សំបុត្រ</label><ul>\
    <li><a target="_top" href="km/text/shared/autopi/01010000.html?DbPAR=SHARED">អ្នក​ជំនួយការ​សំបុត្រ</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">អ្នកជំនួយ​ការ​ទូរសារ</label><ul>\
    <li><a target="_top" href="km/text/shared/autopi/01020000.html?DbPAR=SHARED">អ្នកជំនួយ​ការ​ទូរសារ</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">អ្នក​ជំនួយការ​របៀប​វារៈ</label><ul>\
    <li><a target="_top" href="km/text/shared/autopi/01040000.html?DbPAR=SHARED">អ្នក​ជំនួយការ​របៀប​វារៈ</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">អ្នកជំនួយការ​នាំចេញ HTML</label><ul>\
    <li><a target="_top" href="km/text/shared/autopi/01110000.html?DbPAR=SHARED">នាំចេញ HTML</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">អ្នកជំនួយការ​កម្មវិធី​បម្លែង​ឯកសារ</label><ul>\
    <li><a target="_top" href="km/text/shared/autopi/01130000.html?DbPAR=SHARED">កម្មវិធី​បម្លែង​ឯកសារ</a></li>\
			</ul></li>\
    <li><a target="_top" href="km/text/shared/autopi/01150000.html?DbPAR=SHARED">អ្នក​ជំនួយ​ការ​កម្មវិធី​បម្លែង​អឺរ៉ូ​</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">ការ​កំណត់​រចនាសម្ព័ន្ធ LibreOffice</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/configure_overview.html?DbPAR=SHARED">ការ​កំណត់​រចនាសម្ព័ន្ធ​ LibreOffice</a></li>\
    <li><a target="_top" href="km/text/shared/01/packagemanager.html?DbPAR=SHARED">កម្មវិធី​គ្រប់​គ្រង​ផ្នែក​បន្ថែម</a></li>\
    <li><a target="_top" href="km/text/shared/guide/flat_icons.html?DbPAR=SHARED">ការ​ផ្លាស់​ប្តូរ​ទិដ្ឋភាព​រូប​តំណាង</a></li>\
    <li><a target="_top" href="km/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">ការ​បន្ថែម​ប៊ូតុង​ទៅ​របារ​ឧបករណ៍</a></li>\
    <li><a target="_top" href="km/text/shared/guide/workfolder.html?DbPAR=SHARED">ផ្លាស់ប្ដូរ​ថត​ធ្វើការ​របស់​អ្នក</a></li>\
    <li><a target="_top" href="km/text/shared/guide/standard_template.html?DbPAR=SHARED">ការ​ផ្លាស់​ប្តូរ​ពុម្ព​លំនាំ​ដើម​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_addressbook.html?DbPAR=SHARED">ការ​ចុះ​ឈ្មោះ​សៀវភៅ​អាសយដ្ឋាន​មួយ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/formfields.html?DbPAR=SHARED">ប៊ូតុង​បញ្ចូល​ និង កែ​សម្រួល</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">ធ្វើការ​ជាមួយ​ចំណុចប្រទាក់​អ្នកប្រើ</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">ការ​រុករក ដើម្បី​ទៅ​ដល់​វត្ថុ​បាន​រហ័ស</a></li>\
    <li><a target="_top" href="km/text/shared/guide/navigator.html?DbPAR=SHARED">កម្មវិធី​រុករក​សម្រាប់​ទិដ្ឋភាព​ទូទៅ​ឯកសារ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/autohide.html?DbPAR=SHARED">ការ​បង្ហាញ​ ការ​ចត​ និង ការ​លាក់​បង្អួច</a></li>\
    <li><a target="_top" href="km/text/shared/guide/textmode_change.html?DbPAR=SHARED">ការ​ប្តូរ​រវាង​របៀប​បញ្ជាន់​​ និង របៀប​សរសេរ​ជាន់​លើ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">ការ​ប្រើ​របារឧបករណ៍​</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digital Signatures</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/digital_signatures.html?DbPAR=SHARED">អំពី​ហត្ថលេខា​ឌីជីថល</a></li>\
    <li><a target="_top" href="km/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">អនុវត្ត​ហត្ថលេខា​ឌីជីថល</a></li>\
    <li><a target="_top" href="km/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="km/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="km/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="km/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="km/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">ការ​បោះពុម្ព ទូរសារ និង​ផ្ញើ</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/labels_database.html?DbPAR=SHARED">ការ​បោះពុម្ព​ស្លាក​អាសយដ្ឋាន</a></li>\
    <li><a target="_top" href="km/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">ការ​បោះពុម្ព​ជា​ពណ៌​ស​​ខ្មៅ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/email.html?DbPAR=SHARED">ការ​ផ្ញើ​ឯកសារ​ជា​អ៊ីមែល</a></li>\
    <li><a target="_top" href="km/text/shared/guide/fax.html?DbPAR=SHARED">ការ​ផ្ញើ​ទូរសារ និង ការ​កំណត់​រចនា​សម្ព័ន្ធ​ LibreOffice ដើម្បី​ផ្ញើ​ទូរសារ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">អូស និង​ទម្លាក់</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/dragdrop.html?DbPAR=SHARED">អូស​ និង ទម្លាក់ក្នុង​ឯកសារ LibreOffice</a></li>\
    <li><a target="_top" href="km/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">ការ​ចម្លង និង ការ​ផ្លាស់ទី​អត្ថបទ​ក្នុង​ឯកសារ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">ការ​ចម្លង​ផ្ទៃ​សៀវភៅ​បញ្ជី​​ទៅ​​ឯកសារ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">ការ​ចម្លង​ក្រាហ្វិក​រវាង​ឯកសារ​ជា​ច្រើន​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">ការ​ចម្លង​​ក្រាហ្វិក​ពី​វិចិត្រសាល​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">អូស​ និង​ទម្លាក់​​ជាមួយ​​ទិដ្ឋភាព​ប្រភព​​ទិន្នន័យ​</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">ចម្លង និង​បិទភ្ជាប់</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">ការ​ចម្លង​វត្ថុ​គំនូរ​ទៅ​ក្នុង​ឯកសារ​ផ្សេងៗទៀត</a></li>\
    <li><a target="_top" href="km/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">ការ​ចម្លង​ក្រាហ្វិក​រវាង​ឯកសារ​ជា​ច្រើន​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">ការ​ចម្លង​​ក្រាហ្វិក​ពី​វិចិត្រសាល​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">ការ​ចម្លង​ផ្ទៃ​សៀវភៅ​បញ្ជី​​ទៅ​​ឯកសារ​អត្ថបទ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">គំនូសតាង និង​ដ្យាក្រាម</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/chart_insert.html?DbPAR=SHARED">ការ​បញ្ចូល​គំនូស​តាង​</a></li>\
    <li><a target="_top" href="km/text/schart/main0000.html?DbPAR=SHARED">គំនូស​តាង​ក្នុង LibreOffice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Load, Save, Import, Export, PDF</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/doc_open.html?DbPAR=SHARED">ការបើក​ឯកសារ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/import_ms.html?DbPAR=SHARED">ការ​បើក​ឯកសារ​ដែល​បាន​រក្សា​ទុក​ក្នុង​ទ្រង់​ទ្រាយ​ផ្សេង</a></li>\
    <li><a target="_top" href="km/text/shared/guide/doc_save.html?DbPAR=SHARED">ការ​រក្សា​ទុក​ឯកសារ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/doc_autosave.html?DbPAR=SHARED">ការ​រក្សា​ទុក​ឯកសារ​ដោយ​ស្វ័យ​ប្រវត្តិ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/export_ms.html?DbPAR=SHARED">ការ​រក្សា​ទុក​ឯកសារ​ក្នុង​ទ្រង់ទ្រាយ​ផ្សេងៗ</a></li>\
    <li><a target="_top" href="km/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">នាំចេញ​ជា PDF</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">ការ​នាំ​ចូល​ និង នាំ​ចេញ​ទិន្នន័យ​ក្នុង​ទ្រង់​ទ្រាយ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">តំណ និង​សេចក្ដីយោង</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">ការ​បញ្ចូល​តំណ​ខ្ពស់</a></li>\
    <li><a target="_top" href="km/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">តំណ​ទំនាក់​ទំនង និង ពេញ​លេញ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">ការ​កែ​សម្រួល​តំណ​ខ្ពស់</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">ការ​តាមដាន​កំណែ​ឯកសារ</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">កា​រប្រៀប​ធៀប​​កំណែ​របស់​ឯកសារ​មួយ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">ការ​បញ្ចូល​កំណែ​​ចូល​គ្នា​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/redlining_enter.html?DbPAR=SHARED">ការ​កត់​ត្រា​ការ​ផ្លាស់​ប្តូរ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/redlining.html?DbPAR=SHARED">ការ​កត់ត្រា​ និង ការ​បង្ហាញ​ការ​ផ្លាស់​ប្តូរ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/redlining_accept.html?DbPAR=SHARED">ការ​ទទួល​យក​ ឬ ច្រាន​ចោល​ការ​ផ្លាស់​ប្តូរ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/redlining_versions.html?DbPAR=SHARED">ការ​គ្រប់គ្រង​កំណែរ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">ការ​រចនា​ស្លាក​ និង​នាម​ប័ណ្ណ</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/labels.html?DbPAR=SHARED">ការ​បង្កើត​ និង បោះពុម្ព​ស្លាក​ និង នាមប័ណ្ណ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">ការ​បញ្ចូល​ទិន្នន័យ​ខាងក្រៅ</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/copytable2application.html?DbPAR=SHARED">ការ​បញ្ចូល​ទិន្នន័យ​ពី​សៀវភៅ​បញ្ជី</a></li>\
    <li><a target="_top" href="km/text/shared/guide/copytext2application.html?DbPAR=SHARED">ការ​បញ្ចូល​ទិន្នន័យ​ពី​ឯកសារ​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">ការ​បញ្ចូល​ កែសម្រួល​ រក្សាទុក​រូបភាព</a></li>\
    <li><a target="_top" href="km/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">ការ​បន្ថែម​ក្រាហ្វិក​ទៅ​វិចិត្រសាល</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">អនុគមន៍​ស្វ័យប្រវត្តិ</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/autocorr_url.html?DbPAR=SHARED">បិទ​ការ​ទទួល​ URL ដោយ​ស្វ័យ​ប្រវត្តិ​</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">ស្វែងរក និង​ជំនួស</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/data_search2.html?DbPAR=SHARED">ការ​ស្វែង​រក​ជាមួយ​តម្រង​សំណុំ​បែប​បទ​មួយ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_search.html?DbPAR=SHARED">ការ​ស្វែង​រក​ឯកសារ​តារាង​ និង​ សំណុំ​បែប​បទ​</a></li>\
    <li><a target="_top" href="km/text/shared/01/02100001.html?DbPAR=SHARED">បញ្ជី​កន្សោម​ធម្មតា</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">ណែនាំ</label><ul>\
    <li><a target="_top" href="km/text/shared/guide/linestyles.html?DbPAR=SHARED">ការ​អនុវត្ត​រចនាប័ទ្ម​បន្ទាត់</a></li>\
    <li><a target="_top" href="km/text/shared/guide/text_color.html?DbPAR=SHARED">ការ​ផ្លាស់​ប្តូរ​ពណ៌​របស់​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/change_title.html?DbPAR=SHARED">ការ​ផ្លាស់​ប្តូរ​ចំណង​ជើង​​របស់​ឯកសារ​មួយ​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/round_corner.html?DbPAR=SHARED">ការ​បង្កើត​ជ្រុង​មូល</a></li>\
    <li><a target="_top" href="km/text/shared/guide/background.html?DbPAR=SHARED">កំណត់​ពណ៌​ផ្ទៃ​ខាង​ក្រោយ ឬ​ក្រាហ្វិក​ផ្ទៃ​ខាង​ក្រោយ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/lineend_define.html?DbPAR=SHARED">ការ​កំណត់​ចុង​បន្ទាត់</a></li>\
    <li><a target="_top" href="km/text/shared/guide/linestyle_define.html?DbPAR=SHARED">ការ​កំណត់​រចនាប័ទ្ម​បន្ទាត់​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">កែ​សម្រួល​វត្ថុ​ក្រាហ្វិក</a></li>\
    <li><a target="_top" href="km/text/shared/guide/line_intext.html?DbPAR=SHARED">ការ​គូរ​បន្ទាត់​ក្នុង​អត្ថបទ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/aaa_start.html?DbPAR=SHARED">ជំហានទី១</a></li>\
    <li><a target="_top" href="km/text/shared/guide/gallery_insert.html?DbPAR=SHARED">ការ​បញ្ចូល​វត្ថុ​ពី​វិចិត្រសាល</a></li>\
    <li><a target="_top" href="km/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="km/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">ការ​បញ្ចូល​តួអក្សរ​ពិសេស</a></li>\
    <li><a target="_top" href="km/text/shared/guide/tabs.html?DbPAR=SHARED">ការ​បញ្ចូល​ និង កែ​សម្រួល​ឈប់​ថេប</a></li>\
    <li><a target="_top" href="km/text/shared/guide/protection.html?DbPAR=SHARED">ការ​ការពារ​មាតិកា​កក្នុង​ LibreOffice</a></li>\
    <li><a target="_top" href="km/text/shared/guide/redlining_protect.html?DbPAR=SHARED">ការ​ការ​ពារ​កំណត់​ត្រា</a></li>\
    <li><a target="_top" href="km/text/shared/guide/pageformat_max.html?DbPAR=SHARED">ជ្រើស​ផ្ទៃ​បោះពុម្ព​អតិបរមា​នៅ​លើ​ទំព័រ​មួយ​</a></li>\
    <li><a target="_top" href="km/text/shared/guide/measurement_units.html?DbPAR=SHARED">ការ​ជ្រើស​ឯកតា​រង្វាស់</a></li>\
    <li><a target="_top" href="km/text/shared/guide/language_select.html?DbPAR=SHARED">ការ​ជ្រើស​ភាសា​ឯកសារ</a></li>\
    <li><a target="_top" href="km/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">រចនា​តារាង</a></li>\
    <li><a target="_top" href="km/text/shared/guide/numbering_stop.html?DbPAR=SHARED">ការ​បិទ​ចំណុច​ និង លេខរៀង​​សម្រាប់​កថាខណ្ឌ​នីមួយៗ</a></li>\
		</ul></li>\
	</ul></li></ul>\
';
