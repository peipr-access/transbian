document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Text Documents (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="dz/text/swriter/main0000.html?DbPAR=WRITER">LibreOffice རའི་ཊར་གྲོགས་རམ་ནང་ལུ་བྱོན་པ་ལེགས་སོ་ཡོད།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0503.html?DbPAR=WRITER">LibreOffice རྩོམ་འབྲི་པ་གི་ཁྱད་རྣམ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/main.html?DbPAR=WRITER">LibreOffice རྩོམ་འབྲི་པ་ལག་ལེན་འཐབ་ནིའི་དོན་ལུ་ བསླབ་སྟོན།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">ཌོཀ་དང་ཚད་བསྐྱར་བཟོ་འབད་ནིའི་སྒོ་སྒྲིག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/04/01020000.html?DbPAR=WRITER">LibreOffice རྩོམ་འབྲི་པ་གི་དོན་ལུ་ མགྱོགས་ཐབས་ཀྱི་ལྡེ་མིག</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/words_count.html?DbPAR=WRITER">མིང་ཚིག་ཚུ་གྱངས་ཁ་རྐྱབས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/keyboard.html?DbPAR=WRITER">མགྱོགས་ཐབས་ལྡེ་མིག་ལག་ལེན་འཐབ་དོ་ (LibreOffice རྩོམ་འབྲི་པ་འཛུལ་སྤྱོད་)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">དཀར་ཆག་ཚུ།</label><ul>\
    <li><a target="_top" href="dz/text/swriter/main0100.html?DbPAR=WRITER">དཀར་ཆག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0101.html?DbPAR=WRITER">ཡིག་སྣོད།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0102.html?DbPAR=WRITER">ཞུན་དག་འབད།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0103.html?DbPAR=WRITER">སྟོན།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0104.html?DbPAR=WRITER">བཙུགས།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0105.html?DbPAR=WRITER">རྩ་སྒྲིག</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0115.html?DbPAR=WRITER">Styles</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0110.html?DbPAR=WRITER">ཐིག་ཁྲམ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0120.html?DbPAR=WRITER">Form Menu</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0106.html?DbPAR=WRITER">ལག་ཆས་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0107.html?DbPAR=WRITER">སྒོ་སྒྲིག</a></li>\
    <li><a target="_top" href="dz/text/shared/main0108.html?DbPAR=WRITER">གྲོགས་རམ།</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">ག་ཆས་ཕྲ་རིང་ཚུ།</label><ul>\
    <li><a target="_top" href="dz/text/swriter/main0200.html?DbPAR=WRITER">ལག་ཆས་ཕྲ་རིང་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0202.html?DbPAR=WRITER">ཕྲ་རིང་རྩ་སྒྲིག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0203.html?DbPAR=WRITER">Image Bar</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0204.html?DbPAR=WRITER">ཐིག་ཁྲམ་གི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0205.html?DbPAR=WRITER">དངོས་པོ་རྒྱུ་དངོས་ཀྱི་ཕྲ་རིང་ཚུ་འབྲིས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0206.html?DbPAR=WRITER">འགོ་ཚག་དང་ཕྲ་རིང་ཨང་རྟགས་བཀོད་ནི།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0208.html?DbPAR=WRITER">གནད་ཚད་ཀྱི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0210.html?DbPAR=WRITER">Print Preview</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0213.html?DbPAR=WRITER">ཐག་ཤིང།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0214.html?DbPAR=WRITER">མན་ངག་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0215.html?DbPAR=WRITER">གཞི་ཁྲམ་གྱི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0216.html?DbPAR=WRITER">ཨོ་ཨེལ་ཨི་-དངོས་པོའི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/swriter/main0220.html?DbPAR=WRITER">ཚིག་ཡིག་དངོས་པོ་གི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0201.html?DbPAR=WRITER">ཚད་ལྡན་གྱི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0212.html?DbPAR=WRITER">ཐིག་ཁྲམ་གནད་སྡུད་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0213.html?DbPAR=WRITER">འབྲི་ཤོག་འགྲུལ་བསྐྱོད་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0214.html?DbPAR=WRITER">བཀོད་སྒྲིག་ཕྲ་རིང་ འདྲི་དཔྱད་འབད།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0226.html?DbPAR=WRITER">འབྲི་ཤོག་བཀོད་སྒྲིག་ལག་ཆས་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo Toolbar</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">Creating Text Documents</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">ལྡེ་སྒྲོམ་དང་གཅིག་ཁར་འགྲུལ་བསྐྱོད་དང་སེལ་འཐུ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">ཐད་ཀར་འོད་རྟགས་འདི་ལག་ལེན་འཐབ་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Graphics in Text Documents</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">ཚད་རིས་ཚུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">ཡིག་སྣོད་ཅིག་ལས་ཚད་རིས་ཅིག་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">ཚད་རིས་ཚུ་ འདྲུད་-དང་-བཀོག་བཞག་དང་གཅིག་ཁར་ སྟོན་ཁང་འདི་ལས་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">ཞིབ་ལྟ་འབད་ཡོད་པའི་གཟུགས་བརྙན་ཅིག་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">ཚིག་ཡིག་གི་ཡིག་ཆ་ཅིག་ནང་ལུ་ ཀེལཀི་དཔེ་རིས་ཅིག་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">ཚད་རིས་ཚུ་ LibreOffice འབྲི་ནི་ཡང་ན་གོ་བརྡ་སྤྲོད་ནིལས་བཙུགས་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tables in Text Documents</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">ཨང་ངོས་འཛིན་འབད་ནི་འདི་ ཐིག་ཁྲམ་ཚུ་ནང་ ཨཱོན་ཡང་ན་ཨོཕ་ཊཱན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/tablemode.html?DbPAR=WRITER">ལྡེ་སྒྲོམ་གྱིས་སྦེ་ གྲལ་ཐིག་ཚུ་དང་ཀེར་ཐིག་ཚུ་ལེགས་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/table_delete.html?DbPAR=WRITER">ཐིག་ཁྲམ་ཚུ་ཡང་ན་ཐིག་ཁྲམ་གྱི་ནང་དོན་ཚུ་བཏོནགཏང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/table_insert.html?DbPAR=WRITER">ཐིག་ཁྲམ་ཚུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">ཤོག་ལེབ་གསརཔ་ཅིག་གུ་ལུ་ཐིག་ཁྲམ་གྱི་མགོ་ཡིག་ཅིག་ཡང་བསྐྱར་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/table_sizing.html?DbPAR=WRITER">ཚིག་ཡིག་ཐིག་ཁྲམ་ཅིག་ནང་གྱལ་ཚུ་དང་ཀེར་ཐིག་ཚུ་ཚད་བསྐྱར་བཟོ་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objects in Text Documents</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/anchor_object.html?DbPAR=WRITER">དངོས་པོ་ཚུ་གནས་ས་བཟོ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/wrap.html?DbPAR=WRITER">ཚིག་ཡིག་འདི་དངོས་པོ་ཚུ་གི་མཐའ་སྐོར་ཏེ་ལོག་མཚམས་བཟོ་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sections and Frames in Text Documents</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/sections.html?DbPAR=WRITER">དབྱེ་ཚན་ཚུ་ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/section_edit.html?DbPAR=WRITER">དབྱེ་ཚན་ཚུ་ཞུན་དག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/section_insert.html?DbPAR=WRITER">དབྱེ་ཚན་ཚུ་བཙུགས་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Tables of Contents and Indexes</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">ལག་ལེན་པ་-ངེས་འཛིན་འབད་ཡོད་པའི་ཟུར་ཐོ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/indices_toc.html?DbPAR=WRITER">ནང་དོན་ཚུའི་ཐིག་ཁྲམ་ཅིག་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/indices_index.html?DbPAR=WRITER">ཀ་ཁའི་གོ་རིམ་གྱི་ཟུར་ཐོ་ཚུ་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">ཡིག་ཆ་ལེ་ཤ་ཅིག་སྤུབས་མི་ཟུར་ཐོ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/indices_literature.html?DbPAR=WRITER">དེབ་ཐོ་ཅིག་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/indices_delete.html?DbPAR=WRITER">ཟུར་ཐོ་དང་ཐིག་ཁྲམ་གྱི་ཐོ་བཀོད་ཚུ་ཞུན་དག་དང་བཏོན་གཏང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/indices_edit.html?DbPAR=WRITER">ནང་དོན་ཚུ་གི་ཟུར་ཐོ་ཚུ་དང་ཐིག་ཁྲམ་ཚུ་ དུས་མཐུན་ ཞུན་དག་ དང་ བཏོན་གཏང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/indices_enter.html?DbPAR=WRITER">ནང་དོན་ཚུ་གི་ཟུར་ཐོ་ཡང་ན་ཐིག་ཁྲམ་གྱི་ཐོ་བཀོད་ཚུ་ངེས་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/indices_form.html?DbPAR=WRITER">ཟུར་ཐོ་ཡང་ན་ནང་དོན་ཚུའི་ཐིག་ཁྲམ་ཅིག་རྩ་སྒྲིག་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Fields in Text Documents</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/fields.html?DbPAR=WRITER">ས་སྒོ་ཚུ་གི་སྐོར་ལས།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/fields_date.html?DbPAR=WRITER">གཏན་བཟོས་ཡང་ན་འགྱུར་ཅན་གནད་སྡུད་ས་སྒོ་ཅིག་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/field_convert.html?DbPAR=WRITER">ས་སྒོ་འདི་ཚིག་ཡིག་ལུ་གཞི་བསྒྱུར་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navigating Text Documents</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">ཡིག་ཆ་ཚུ་ནང་ལུ་ ཚིག་ཡིག་སྤོ་བཤུད་དང་འདྲ་བཤུས་རྐྱབས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">འགྲུལ་བསྐྱོད་པ་ལག་ལེན་འཐབ་ཐོག་ ཡིག་ཆ་ཅིག་ལོག་བདེ་ཞིབ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">འགྲུལ་བསྐྱོད་པ་དང་ཅིག་ཁར་ཚད་བརྒལ་འབྲེལ་ལམ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/navigator.html?DbPAR=WRITER">ཚིག་ཡིག་གི་ཡིག་ཆ་ཚུའི་དོན་ལུ་འགྲུལ་བསྐྱོད་པ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">ཚིག་ཡིག་ཡིག་ཆ་ཚུ་ནང་རྩིས་སྟོན་འབད་དོ།</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">ཐིག་ཁྲམ་ཚུ་ཡན་ཆད་རྩིས་སྟོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/calculate.html?DbPAR=WRITER">ཚིག་ཡིག་ཡིག་ཆ་ཚུ་ནང་རྩིས་སྟོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">ཚིག་ཡིག་ཡིག་ཆ་ནང་གི་མན་ངག་ནང་ལུ་གྲུབ་འབྲས་འདི་རྩིས་སྟོན་དང་སྦྱར་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">ཐིག་ཁྲམ་ཚུ་ནང་ནང་ཐིག་གི་བསྡོམས་རྩིས་སྟོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">ཚིག་ཡིག་ཡིག་ཆ་ནང་ལུ་གོ་དཀའ་བའི་མན་ངག་ཚུ་རྩིས་སྟོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">ཐིག་ཁྲམ་སོ་སོ་ནང་ལུ་ཐིག་ཁྲམ་རྩིས་སྟོན་གྱི་གྲུབ་འབྲས་བཀྲམ་སྟོན་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatting Text Documents</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">ཊེམ་པེལེཏིསི་དང་བཟོ་རྣམ་ཚུ།</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/templates_styles.html?DbPAR=WRITER">ཊེམ་པེལེཏིསི་དང་བཟོ་རྣམ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">ཡ་ཅན་དང་ཆ་ཅན་ཤོག་ལེབ་ཚུ་གུ་སྤེལ་མ་ལོག་ལེབ་ཀྱི་བཟོ་རྣམ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/change_header.html?DbPAR=WRITER">ད་ལྟོའི་ཤོག་ལེབ་ལུ་གཞི་བཞག་སྟེ་ ཤོག་ལེབ་ཀྱི་བཟོ་རྣམ་ཅིག་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/load_styles.html?DbPAR=WRITER">བཟོ་རྣམ་ཚུ་ ཡིག་ཆ་ཡང་ན་ཊེམ་པེལེཊི་གཞན་མི་ཅིག་ལས་ ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">སེལ་འཐུ་འབད་ནི་ཚུ་ལས་བཟོ་རྣམ་གསརཔ་ཚུ་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/stylist_update.html?DbPAR=WRITER">སེལ་འཐུ་འབད་ནི་ལས་བཟོ་རྣམ་ཚུ་དུས་མཐུན་བཟོ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/template_create.html?DbPAR=WRITER">ཡིག་ཆ་གི་ཊེམ་པེལེཊི་ཅིག་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/template_default.html?DbPAR=WRITER">སྔོན་སྒྲིག་ཊེམ་པེལེཊི་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
			</ul></li>\
    <li><a target="_top" href="dz/text/swriter/guide/pageorientation.html?DbPAR=WRITER">ཤོག་ལེབ་ཀྱི་ཕྱོགས་བསྒྱུར་བཅོས་འབད་དོ་(ཀེ་ཀེ་ ཡང་ན་ཡར་ཕྲང་)</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/text_capital.html?DbPAR=WRITER">ཚིག་ཡིག་གི་ཡིག་གུ་འདི་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/hidden_text.html?DbPAR=WRITER">ཚིག་ཡིག་སྦ་བཞག་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">མགོ་ཡིག་ཚུ་དང་མཇུག་ཡིག་སོ་སོ་ཚུ་ངེས་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">མགོ་ཡིག་ཡང་ན་ མཇུག་ཡིག་ནང་ལུ་ ལེའུ་གི་མིང་དང་ཨང་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">ཁྱོད་ཀྱིས་ཡིག་དཔར་རྐྱབས་པའི་སྐབས་ ཚིག་ཡིག་རྩ་སྒྲིག་འབད་ནི་འཇུག་སྤྱོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/reset_format.html?DbPAR=WRITER">ཡིག་གཟུགས་ཀྱི་ཁྱད་ཆོས་ཚུ་སླར་སྒྲིག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">བཀང་ནིའི་རྩ་སྒྲིག་གི་ཐབས་ལམ་ནང་ལུ་བཟོ་རྣམ་ཚུ་འཇུག་སྤྱོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/wrap.html?DbPAR=WRITER">ཚིག་ཡིག་འདི་དངོས་པོ་ཚུ་གི་མཐའ་སྐོར་ཏེ་ལོག་མཚམས་བཟོ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/text_centervert.html?DbPAR=WRITER">ཤོག་ལེབ་གུ་ལུ་ཚིག་ཡིག་ཅིག་དབུས་སྒྲིག་འབད་ནིའི་དོན་ལས་གཞི་ཁྲམ་ཅིག་ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">ཚིག་ཡིག་གཙོ་བཏོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/text_rotate.html?DbPAR=WRITER">ཚིག་ཡིག་བསྒྱིར་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/page_break.html?DbPAR=WRITER">ཤོག་ལེབ་ཀྱི་བར་མཚམས་ཚུ་ བཙུགས་ནི་དང་བཏོན་གཏང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/pagestyles.html?DbPAR=WRITER">ཤོག་ལེབ་ཀྱི་བཟོ་རྣམ་ཚུ་ གསར་བསྐྲུན་དང་འཇུག་སྤྱོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/subscript.html?DbPAR=WRITER">ཚིག་ཡིག་སྟེང་ཡིག་ཡང་ན་འོག་ཡིག་བཟོ་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Special Text Elements</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/captions.html?DbPAR=WRITER">དཔར་བཤད་ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/conditional_text.html?DbPAR=WRITER">གནས་སྟངས་ཚིག་ཡིག</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">ཤོག་ལེབ་གྱངས་ཁ་རྐྱབས་ནིའི་དོན་ལུ་གནས་སྟངས་ཚིག་ཡིག</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/fields_date.html?DbPAR=WRITER">གཏན་བཟོས་ཡང་ན་འགྱུར་ཅན་གནད་སྡུད་ས་སྒོ་ཅིག་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/fields_enter.html?DbPAR=WRITER">ཨིན་པུཊི་ས་སྒོ་ཚུ་ཁ་སྐོང་རྐྱབས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">འཕྲོ་མཐུད་ཤོག་ལེབ་ཚུ་གི་ཤོག་ལེབ་ཨང་ཚུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">མཇུག་ཡིག་ཚུ་ནང་ཤོག་ལེབ་ཨང་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/hidden_text.html?DbPAR=WRITER">ཚིག་ཡིག་སྦ་བཞག་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">མགོ་ཡིག་ཚུ་དང་མཇུག་ཡིག་སོ་སོ་ཚུ་ངེས་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">མགོ་ཡིག་ཡང་ན་ མཇུག་ཡིག་ནང་ལུ་ ལེའུ་གི་མིང་དང་ཨང་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">ས་སྒོ་ཚུ་ཡང་ན་གནས་སྟངས་ཚུ་ནང་ ལག་ལེན་པའི་གནད་སྡུད་འདྲི་དཔྱད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">མཇུག་གི་དྲན་ཐོ་ཡང་ན་མཐའི་དྲན་འཛིན་ཚུ་ བཙུགས་ནི་དང་ཞུན་དག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">མཇུག་གི་དྲན་ཐོ་ཚུ་གི་བར་ན་བར་སྟོང་བཞག་ཐངས།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/header_footer.html?DbPAR=WRITER">མགོ་ཡིག་ཚུ་དང་མཇུག་ཡིག་ཚུ་གི་སྐོར།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/header_with_line.html?DbPAR=WRITER">མགོ་ཡིག་ཡང་ན་མཇུག་ཡིག་རྩ་སྒྲིག་བཟོ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/text_animation.html?DbPAR=WRITER">ཚིག་ཡིག་བསྒུལ་བཟོ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">འབྲི་ཤོག་ཡིག་གུ་ཅིག་གསར་བསྐྲུན་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automatic Functions</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">དམིགས་བསལ་ཚུ་རང་བཞིན་ནོར་བཅོས་ཐོ་ཡིག་འདི་ལུ་ཁ་སྐོང་རྐྱབས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/autotext.html?DbPAR=WRITER">རང་བཞིན་ཚིག་ཡིག་ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">ཁྱོད་ཀྱིས་ཡིག་དཔར་རྐྱབས་ད་གཅིག་ཁར་ཨང་བཏགས་ཡོདཔ་ཡང་ན་འགོ་ཚག་འབད་ཡོད་པའི་ཐོ་ཡིག་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/auto_off.html?DbPAR=WRITER">Turning Off AutoCorrect</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">རང་བཞིན་གྱིས་སྡེབ་ཞིབ་དཔྱད་འབད།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">ཨང་ངོས་འཛིན་འབད་ནི་འདི་ ཐིག་ཁྲམ་ཚུ་ནང་ ཨཱོན་ཡང་ན་ཨོཕ་ཊཱན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">སྦྲེལ་རྟགས་བཀལ་ནི།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numbering and Lists</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">དཔར་བཤད་ཚུ་ལུ་ལེའུ་གི་ཨང་གྲངས་ཚུ་ཁ་སྐོང་རྐྱབས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">ཁྱོད་ཀྱིས་ཡིག་དཔར་རྐྱབས་ད་གཅིག་ཁར་ཨང་བཏགས་ཡོདཔ་ཡང་ན་འགོ་ཚག་འབད་ཡོད་པའི་ཐོ་ཡིག་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the Chapter Level of Numbered and Bulleted Lists</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">ཨང་བཏགས་ཡོད་པའི་ཐོ་ཡིག་ཚུ་མམཉམ་མཐུད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">གྲལ་ཐིག་གི་ཨང་ཁ་སྐོང་རྐྱབས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">ཨང་བཏགས་ཡོད་པའི་ཐོ་ཡིག་ཅིག་ནང་ལུ་ ཨང་བཏགས་ནི་ལེགས་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/number_sequence.html?DbPAR=WRITER">ཨང་གི་ཁྱབ་ཚད་ཚུ་ངེས་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">ཨང་བཏགས་ནི་ཁ་སྐོང་རྐྱབས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/using_numbering.html?DbPAR=WRITER">ཨང་བཏགས་ནི་དང་ཨང་བཏགས་ནིའི་བཟོ་རྣམ་ཚུ་</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">འགོ་ཚག་ཚུ་ཁ་སྐོང་རྐྱབས་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Spellchecking, Thesaurus, and Languages</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">རང་བཞིན་གྱིས་སྡེབ་ཞིབ་དཔྱད་འབད།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">ལག་ལེན་པ་ངེས་འཛིན་འབད་ཡོད་པའི་ཚིག་མཛོད་ཅིག་ནང་ལས་མིང་ཚིག་ཚུ་རྩ་བསྐྲད་གཏང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">མངོན་བརྗོད།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Checking Spelling and Grammar</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Troubleshooting Tips</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">ཤོག་ལེབ་ཀྱི་མགོ་ལུ་ཐིག་ཁྲམ་ཅིག་ ཚིག་ཡིག་གི་གདོང་ཁར་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">དམིགས་བསལ་གྱི་དེབ་རྟགས་ལུ་འགྱོ་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/send2html.html?DbPAR=WRITER">ཨེཆ་ཊི་ཨེམ་ཨེལ་རྩ་སྒྲིག་ནང་ ཚིག་ཡིག་གི་ཡིག་ཆ་ཚུ་སྲུང་བཞག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">ཚིག་ཡིག་གི་ཡིག་ཆ་ཧྲིལ་བུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Master Documents</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/globaldoc.html?DbPAR=WRITER">ཡིག་ཆ་ཨམ་ཚུ་དང་ཡན་ལག་ཡིག་ཆ་ཚུ་ལག་ལེན་འཐབ་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Links and References</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/references.html?DbPAR=WRITER">ཕན་ཚུན་གཞི་བསྟུན་ཚུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">འགྲུལ་བསྐྱོད་པ་དང་ཅིག་ཁར་ཚད་བརྒལ་འབྲེལ་ལམ་བཙུགས་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">དཔར་བསྐྲུན་འབད་དོ།</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/printer_tray.html?DbPAR=WRITER">དཔར་འཕྲུལ་ཤོག་ཀུའི་ཤོག་སྣོད་ཚུ་སེལ་འཐུ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/print_preview.html?DbPAR=WRITER">ཤོག་ལེབ་དཔར་བསྐྲུན་མ་འབད་བའི་ཧེ་མ་ སྔོན་ལྟ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/print_small.html?DbPAR=WRITER">སྣ་མང་ཤོག་ལེབ་ཚུ་ ལེབ་གྲངས་གཅིག་གུ་དཔར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/pagestyles.html?DbPAR=WRITER">ཤོག་ལེབ་ཀྱི་བཟོ་རྣམ་ཚུ་ གསར་བསྐྲུན་དང་འཇུག་སྤྱོད་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Searching and Replacing</label><ul>\
    <li><a target="_top" href="dz/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="dz/text/shared/01/02100001.html?DbPAR=WRITER">དུས་རྒྱུན་གསལ་བརྗོད་ཚུ་གི་ཐོ་ཡིག</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML Documents (Writer Web)</label><ul>\
    <li><a target="_top" href="dz/text/shared/07/09000000.html?DbPAR=WRITER">ཝེབ་ཀྱི་ཤོག་ལེབ་ཚུ་</a></li>\
    <li><a target="_top" href="dz/text/shared/02/01170700.html?DbPAR=WRITER">ཨེཆི་ཊི་ཨེམ་ཨེལ་ ཚགས་མ་དང་འབྲི་ཤོག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/send2html.html?DbPAR=WRITER">ཨེཆ་ཊི་ཨེམ་ཨེལ་རྩ་སྒྲིག་ནང་ ཚིག་ཡིག་གི་ཡིག་ཆ་ཚུ་སྲུང་བཞག་འབད་དོ།</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Spreadsheets (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="dz/text/scalc/main0000.html?DbPAR=CALC">LibreOffice ཀེལཀི་ གྲོགས་རམ་ལུ་ འབྱོན་པ་ལེགས་སོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0503.html?DbPAR=CALC">LibreOffice ཀེལཀི་ཁྱད་རྣམ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/keyboard.html?DbPAR=CALC">མགྱོགས་ཐབས་ལྡེ་མིག་ཚུ་(LibreOffice ཀེལཀི་འཛུལ་སྤྱོད་)།</a></li>\
    <li><a target="_top" href="dz/text/scalc/04/01020000.html?DbPAR=CALC">ཤོག་ཁྲམ་ཚུ་གི་དོན་ལུ་ མགྱོགས་ཐབས་ལྡེ་མིག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/05/02140000.html?DbPAR=CALC">LibreOffice ཀེལ་སི་ནང་ ཨང་རྟགས་ཚུ་འཛོལ་བ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060112.html?DbPAR=CALC">LibreOffice ཀེལ་སི་ ནང་ ལས་རིམ་བཟོ་ལས་དོན་ལུ་ ཨེཌི་ཨིནསི།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/main.html?DbPAR=CALC">LibreOffice ཀེལཀི་ལག་ལེན་འཐབ་ནི་གི་དོན་ལུ་ བསླབ་སྟོན།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">དཀར་ཆག་ཚུ།</label><ul>\
    <li><a target="_top" href="dz/text/scalc/main0100.html?DbPAR=CALC">དཀར་ཆག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0101.html?DbPAR=CALC">ཡིག་སྣོད།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0102.html?DbPAR=CALC">ཞུན་དག</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0103.html?DbPAR=CALC">མཐོང་སྣང་།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0104.html?DbPAR=CALC">བཙུགས།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0105.html?DbPAR=CALC">རྩ་སྒྲིག</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0116.html?DbPAR=CALC">Sheet</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0112.html?DbPAR=CALC">གནད་སྡུད།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0106.html?DbPAR=CALC">ལག་ཆས་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0107.html?DbPAR=CALC">སྒོ་སྒྲིག</a></li>\
    <li><a target="_top" href="dz/text/shared/main0108.html?DbPAR=CALC">གྲོགས་རམ།</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">ག་ཆས་ཕྲ་རིང་ཚུ།</label><ul>\
    <li><a target="_top" href="dz/text/scalc/main0200.html?DbPAR=CALC">ལག་ཆས་ཕྲ་རིང་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0202.html?DbPAR=CALC">ཕྲ་རིང་རྩ་སྒྲིག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0203.html?DbPAR=CALC">པར་རིས་དངོས་པོའི་རྒྱུ་དངོས་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0205.html?DbPAR=CALC">ཚིག་ཡིག་རྩ་སྒྲིག་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0206.html?DbPAR=CALC">མན་ངག་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0208.html?DbPAR=CALC">གནས་ཚད་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0210.html?DbPAR=CALC">ཤོག་ལེབ་སྔོན་ལྟ་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0214.html?DbPAR=CALC">Image Bar</a></li>\
    <li><a target="_top" href="dz/text/scalc/main0218.html?DbPAR=CALC">ལག་ཆས་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0201.html?DbPAR=CALC">ཚད་ལྡན་གྱི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0212.html?DbPAR=CALC">ཐིག་ཁྲམ་གནད་སྡུད་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0213.html?DbPAR=CALC">འབྲི་ཤོག་འགྲུལ་བསྐྱོད་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0214.html?DbPAR=CALC">བཀོད་སྒྲིག་ཕྲ་རིང་ འདྲི་དཔྱད་འབད།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0226.html?DbPAR=CALC">འབྲི་ཤོག་བཀོད་སྒྲིག་ལག་ཆས་ཕྲ་རིང་།</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Functions Types and Operators</label><ul>\
    <li><a target="_top" href="dz/text/scalc/01/04060000.html?DbPAR=CALC">ལས་འགན་ཝི་ཛརཌི།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060100.html?DbPAR=CALC">དབྱེ་རིམ་གྱིས་འབད་ལས་འགན་འགན་</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060107.html?DbPAR=CALC">ཨེ་རེ་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060120.html?DbPAR=CALC">Bit Operation Functions</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060101.html?DbPAR=CALC">གནད་སྡུད་གཞི་རྟེན་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060102.html?DbPAR=CALC">ཚེས་ དུས་ཚོད་ལས་འགན་ཚུ།(&T)</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060103.html?DbPAR=CALC">དངུལ་འབྲེལ་ལས་འགན་གྱི་ཡན་ལག་དང་པ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060119.html?DbPAR=CALC">དངུལ་འབྲེལ་ལས་འགན་ཚུའི་ ལེའུ་གཉིས་ལུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060118.html?DbPAR=CALC">དངུལ་འབྲེལ་ལས་འགན་ཚུའི་ ལེའུ་གསུམ་པ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060104.html?DbPAR=CALC">བརྡ་དོན་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060105.html?DbPAR=CALC">ལས་འགན་གཏན་ཚིག་ཅན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060106.html?DbPAR=CALC">ཨང་རྩིས་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060108.html?DbPAR=CALC">གྲངས་ཀྱི་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060181.html?DbPAR=CALC">གྲངས་ཀྱི་ལས་འགན་ཚུའི་ཡན་ལག་དང་པ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060182.html?DbPAR=CALC">གྲངས་ཀྱི་ ལས་འགན་ཚུའི་ལེའུ་ གཉིས་པ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060183.html?DbPAR=CALC">གྲངས་ཀྱི་ལས་འགན་ཚུའི་ ཡན་ལག་གསུམ་པ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060184.html?DbPAR=CALC">གྲངས་ཀྱི་ལས་འགན་ཡན་ལག་བཞི་བ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060185.html?DbPAR=CALC">གྲངས་ཀྱི་ལས་འགན་ཡན་ལག་ལྔ་པ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060109.html?DbPAR=CALC">ཤོག་ཁྲམ་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060110.html?DbPAR=CALC">ཚིག་ཡིག་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060111.html?DbPAR=CALC">Add-in ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060115.html?DbPAR=CALC">ཨེཌི་ཨིནསི་ ལས་འགན་ཚུ། དཔྱད་ཞིབ་ལས་འགན་ཚུའི་ཐོ་ཡིག་ལེའུ་གཅིག</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060116.html?DbPAR=CALC">ཨེཌི་ཨིན་ ལས་འགན་ཚུ། དཔྱད་ཞིབ་ལས་འགན་ཚུའི་ཐོ་ཡིག་གི་ ལེའུ་གཉིས་པ།(-i)</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/04060199.html?DbPAR=CALC">LibreOffice ཀེལ་སི་ ནང་ལུ་ བཀོལ་སྤྱོདཔ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/userdefined_function.html?DbPAR=CALC">ལག་ལེན་པ་-ངེས་འཛིན་འབད་ཡོད་པའི་ལས་འགན་ཚུ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/webquery.html?DbPAR=CALC">ཐིག་ཁྲམ་ནང་ ཕྱིའི་གནད་སྡུད་བཙུགས་དོ་(ཝེབ་ཀིཝི་རི་)།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/html_doc.html?DbPAR=CALC">ཨེཅ་ཊི་ཨེམ་ཨེལ་ནང་ ལེབ་གྲངས་ཚུ་སྲུང་ནི་དང་ཁ་ཕྱེ་ནི།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/csv_formula.html?DbPAR=CALC">ཚིག་ཡིག་ཡིག་སྣོད་ཚུ་ ནང་འདྲེན་དང་ཕྱིར་འདྲེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">རྩ་སྒྲིག་འབད་དོ།</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/text_rotate.html?DbPAR=CALC">བསྒྱིར་ནིའི་ཚིག་ཡིག</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/text_wrap.html?DbPAR=CALC">སྣ་མང་-གྲལ་ཐིག་ཚིག་ཡིག་ བྲིས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/text_numbers.html?DbPAR=CALC">ཨང་གྲངས་ཚུ་ཚིག་ཡིག་སྦེ་ རྩ་སྒྲིག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/super_subscript.html?DbPAR=CALC">ཚིག་ཡིག་སྟེང་ཡིག་/འོག་ཡིག</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/row_height.html?DbPAR=CALC">གྲལ་ཐིག་མཐོ་ཚད་ ཡང་ན་ ཀེར་ཐིག་རྒྱ་ཚད་ བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">གནས་སྟངས་ཅན་གྱི་རྩ་སྒྲིག་ འཇུག་སྤྱོད་འབད།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">མེད་ཆ་ཨང་གྲངས་ཚུ་ གཙོ་དམིགས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">མན་ངག་གི་ཐོག་ལས་ རྩ་སྒྲིག་འགན་སྤྲོད་འབད་ནི།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">ཀླད་ཀོར་གྱིས་སྔོན་བསྐྱོད་འབད་དེ་ ཨང་གྲངས་ཅིག་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/format_table.html?DbPAR=CALC">ཤོག་ཁྲམ་ཚུ་རྩ་སྒྲིག་བཟོ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/format_value.html?DbPAR=CALC">ཨང་གྲངས་ཚུ་བཅུ་ཚག་དང་བཅས་ རྩ་སྒྲིག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/value_with_name.html?DbPAR=CALC">མིང་བཏགས་ནང་ཐིག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/table_rotate.html?DbPAR=CALC">བསྒྱིར་བའི་ཐིག་ཁྲམ་ཚུ་(གོ་རིམ་དཀྲུགས་དོ་)།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/rename_table.html?DbPAR=CALC">ལེབ་གྲངས་ལུ་བསྐྱར་མིང་བཏགས་པ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/year2000.html?DbPAR=CALC">གནམ་ལོ་ ༡༩xx/༢༠xx</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">ཧྲིལ་གྲངས་ཅན་གྱི་ཨང་གྲངས་ ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/currency_format.html?DbPAR=CALC">དངུལ་གྱི་རྩ་སྒྲིག་ནང་ ནང་ཐིག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/autoformat.html?DbPAR=CALC">ཐིག་ཁྲམ་དོན་ལུ་ རང་བཞིན་རྩ་སྒྲིག་ ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/note_insert.html?DbPAR=CALC">དྲན་འཛིན་ཚུ་ བཙུགས་ནི་དང་ཞུན་དག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/design.html?DbPAR=CALC">ལེབ་གྲངས་་དོན་ལུ་ བརྗོད་དོན་ཚུ་སེལ་འཐུ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/fraction_enter.html?DbPAR=CALC">དཔྱ་ཕྲན་བཙུགས་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtering and Sorting</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/filters.html?DbPAR=CALC">ཚགས་མ་ཚུ་ འཇུག་སྤྱོད་འབད་དོ་</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/specialfilter.html?DbPAR=CALC">ཚགས་མ་: མཐོ་རིམ་ཅན་གྱི་ཚགས་མ་ཚུ་ འཇུག་སྤྱོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/autofilter.html?DbPAR=CALC">རང་བཞིན་ཚགས་མ་ འཇུག་སྤྱོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/sorted_list.html?DbPAR=CALC">དབྱེ་སེལ་ཐོ་ཡིག་ཚུ་ འཇུག་སྤྱོད་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">དཔར་བསྐྲུན་འབད་དོ།</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/print_title_row.html?DbPAR=CALC">ཤོག་ལེབ་རེ་རེ་བཞིན་གྱི་གུ་ གྲལ་ཐིག་དང་ཀེར་ཐིག་ཚུ་ དཔར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/print_landscape.html?DbPAR=CALC">ཀེ་ཀེ་རྩ་སྒྲིག་ནང་ ལེབ་གྲངས་དཔར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/print_details.html?DbPAR=CALC">ལེབ་གྲངས་ཀྱི་རྒྱས་བཤད་ དཔར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/print_exact.html?DbPAR=CALC">དཔར་བསྐྲུན་གྱི་དོན་ལུ་ ཤོག་ལེབ་ཀྱི་ཨང་གྲངས་ངེས་འཛིན་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Data Ranges</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/database_define.html?DbPAR=CALC">གནད་སྡུད་གཞི་རྟེན་གྱི་ཁྱབ་ཚད་ཚུ་ ངེས་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/database_filter.html?DbPAR=CALC">ནང་ཐིག་ཁྱབ་ཚད་ཚུ་བཙགས་དོ་</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/database_sort.html?DbPAR=CALC">Sorting Data</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Pivot Table</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/datapilot.html?DbPAR=CALC">པི་ཝོཊི་ཐིག་ཁྲམ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">ཌ་ཊ་པའི་ལོཊི་ཐིག་ཁྲམ་ཚུ་ གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">ཌ་ཊ་པའི་ལོཊི་ཐིག་ཁྲམ་ཚུ་ བཏོན་གཏང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">ཌ་ཊ་པའི་ལོཊི་ཐིག་ཁྲམ་ཚུ་ ཞུན་དག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">ཌ་ཊ་པའི་ལོཊི་ཐིག་ཁྲམ་ཚུ་ བཙགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">ཌ་ཊ་པའི་ལོཊི་ཨའུཊི་པུཊི་ཁྱབ་ཚད་ཚུ་ སེལ་འཐུ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">ཌ་ཊ་པའི་ལོཊི་ཐིག་ཁྲམ་ཚུ་ དུས་མཐུན་བཟོ་དོ།</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivot Chart</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">འཆར་བཤད་ཚུ།</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/scenario.html?DbPAR=CALC">འཆརབཤད་ལག་ལེན་འཐབ་དོ།</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Subtotals</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">References</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">ཁ་བྱང་དང་གཞི་བསྟུན་ཚུ་ ཡང་དག་དང་འབྲེལ་བའི་</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/cellreferences.html?DbPAR=CALC">ཡིག་ཆ་གཞན་མི་ཅིག་ནང་ ནང་ཐིག་ཅིག་གཞི་བསྟུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">ལེབ་གྲངས་གཞན་མི་ལུ་གཞི་བསྟུན་དང་ གཞི་བསྟུན་ ཡུ་ཨར་ཨེལསི།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">འདྲུད་ནི་དང་བཀོག་བཞག་ཐོག་ལས་ ནང་ཐིག་ཚུ་གཞི་བསྟུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/address_auto.html?DbPAR=CALC">མིང་ཚུ་ཁ་བྱང་བཏགས་ནི་སྦེ་ ངོས་འཛིན་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Viewing, Selecting, Copying</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/table_view.html?DbPAR=CALC">ཐིག་ཁྲམ་གྱི་མཐོང་སྣང་ བསྒྱུར་བཅོས་འབད་དོ།༉</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/formula_value.html?DbPAR=CALC">མན་ངག་ ཡང་ན་ བེ་ལུསི་ བཀྲམ་སྟོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/line_fix.html?DbPAR=CALC">གྲལ་ཐིག་ཚུ་དང་ ཡང་ན་ ཀེར་ཐིག་ཚུ་ མགོ་ཡིག་སྦེ་ཐོགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/multi_tables.html?DbPAR=CALC">ལེབ་གྲངས་མཆོང་ལྡེ་ལས་བརྒྱུད་དེ་ འགྲུལ་བསྐྱོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/edit_multitables.html?DbPAR=CALC">སྣ་མང་ལེབ་གྲངས་ལུ་ འདྲ་བཤུས་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/cellcopy.html?DbPAR=CALC">མཐོང་ཚུགས་པའི་ནང་ཐིག་ཚུ་རྐྱངམ་ཅིག་ འདྲ་བཤུས་རྐྱབས།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/mark_cells.html?DbPAR=CALC">སྣ་མང་ནང་ཐིག་ཚུ་ སེལ་འཐུ་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formulas and Calculations</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/formulas.html?DbPAR=CALC">མན་ངག་གི་ཐོག་ལས་ རྩིས་སྟོན་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/formula_copy.html?DbPAR=CALC">མན་ངག་ཚུ་འདྲ་བཤུས་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/formula_enter.html?DbPAR=CALC">Entering Formulas</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/formula_value.html?DbPAR=CALC">མན་ངག་ ཡང་ན་ བེ་ལུསི་ བཀྲམ་སྟོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/calculate.html?DbPAR=CALC">ཤོག་ཁྲམ་ རྩིས་སྟོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/calc_date.html?DbPAR=CALC">ཚེས་གྲངས་དང་ཆུ་ཚོད་ཀྱི་ཐོག་ལས་ རྩིས་སྟོན།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/calc_series.html?DbPAR=CALC">རྒྱུན་རིམ་འདི་རང་བཞིན་གྱིས་ རྩིས་སྟོན་འབད་བའི་བསྒང་།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">དུས་ཀྱི་ཁྱད་པར་ རྩིས་སྟོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/matrixformula.html?DbPAR=CALC">མེ་ཊིགསི་མན་ངག་ བཙུགས་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">ཉེན་སྐྱོབ།</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/cell_protect.html?DbPAR=CALC">ནང་ཐིག་ཚུ་བསྒྱུར་བཅོས་འབད་ནི་ལས་ ཉེན་སྐྱོབ་འབད་ནི།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">ཉེན་སྐྱོབ་འབད་བཤོལ་བའི་ནང་ཐིག་ཚུ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">སྣ་ཚོགས་ཚུ།</label><ul>\
    <li><a target="_top" href="dz/text/scalc/guide/auto_off.html?DbPAR=CALC">རང་བཞིན་གྱི་བསྒྱུར་བཅོས་ཚུ་ ཤུགས་མེད་བཟོ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/consolidate.html?DbPAR=CALC">གནད་སྡུད་རྩ་བརྟན་བཟོ་ནི།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/goalseek.html?DbPAR=CALC">དམིགས་གཏད་འཚོལ་བ་ འཇུག་སྤྱོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/01/solver.html?DbPAR=CALC">Solver</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/multioperation.html?DbPAR=CALC">སྣ་མང་བཀོལ་སྤྱོད་ འཇུག་སྤྱོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/multitables.html?DbPAR=CALC">སྣ་མང་ལེབ་གྲངས་ འཇུག་སྤྱོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/scalc/guide/validity.html?DbPAR=CALC">ནང་ཐིག་ནང་དོན་གྱི་ ནུས་ལྡན་དུས་ཚོད།</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentations (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="dz/text/simpress/main0000.html?DbPAR=IMPRESS">LibreOffice ཨིམ་པེརེསི་གྲོགས་རམ་ལུ་བྱོན་པ་ལེགས་སོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0503.html?DbPAR=IMPRESS">LibreOffice ཨིམ་པེརེསི་ཁྱད་རྣམ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">LibreOffice ཨིམ་པེརེསི་ནང་མགྱོགས་ཐབས་ལྡེ་མིག་ཚུ་ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/04/01020000.html?DbPAR=IMPRESS">LibreOffice ཨིམ་པེརེསི་གི་དོན་ལུ་མགྱོགས་ཐབས་ལྡེ་མིག།</a></li>\
    <li><a target="_top" href="dz/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Keyboard Shortcuts</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/main.html?DbPAR=IMPRESS">LibreOffice ཨིམ་པེརེསི་ལག་ལེན་འཐབ་ནིའི་དོན་ལུ་བསླབ་སྟོན་ཚུ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">དཀར་ཆག་ཚུ།</label><ul>\
    <li><a target="_top" href="dz/text/simpress/main0100.html?DbPAR=IMPRESS">དཀར་ཆག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0101.html?DbPAR=IMPRESS">ཡིག་སྣོད།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0103.html?DbPAR=IMPRESS">མཐོང་སྣང་།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0104.html?DbPAR=IMPRESS">བཙུགས།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="dz/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0114.html?DbPAR=IMPRESS">བཤུད་བརྙན།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main_tools.html?DbPAR=IMPRESS">Tools</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0107.html?DbPAR=IMPRESS">སྒོ་སྒྲིག</a></li>\
    <li><a target="_top" href="dz/text/shared/main0108.html?DbPAR=IMPRESS">གྲོགས་རམ།</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">ག་ཆས་ཕྲ་རིང་ཚུ།</label><ul>\
    <li><a target="_top" href="dz/text/simpress/main0200.html?DbPAR=IMPRESS">ལག་ཆས་ཕྲ་རིང་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0202.html?DbPAR=IMPRESS">གྲལ་ཐིག་དང་ཕྲ་རིང་བཀང་དོ་</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0203.html?DbPAR=IMPRESS">ཚིག་ཡིག་རྩ་སྒྲིག་འབད་ནིའི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0204.html?DbPAR=IMPRESS">བཤུད་མཐོང་སནང་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0206.html?DbPAR=IMPRESS">གནས་ཚད་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0209.html?DbPAR=IMPRESS">ཐིག་ཤིང་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0210.html?DbPAR=IMPRESS">པར་རིས་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0211.html?DbPAR=IMPRESS">མཐའ་ཐིག་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0212.html?DbPAR=IMPRESS">བཤུད་དབྱེ་སེལ་འབད་མི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0213.html?DbPAR=IMPRESS">གདམ་ཁ་ཚུའི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0214.html?DbPAR=IMPRESS">Image Bar</a></li>\
    <li><a target="_top" href="dz/text/shared/main0201.html?DbPAR=IMPRESS">ཚད་ལྡན་གྱི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0213.html?DbPAR=IMPRESS">འབྲི་ཤོག་འགྲུལ་བསྐྱོད་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0226.html?DbPAR=IMPRESS">འབྲི་ཤོག་བཀོད་སྒྲིག་ལག་ཆས་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0227.html?DbPAR=IMPRESS">ས་ཚིགས་ཕྲ་རིང་ཚུ་ཞུན་དག་འབད།</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="dz/text/simpress/guide/html_export.html?DbPAR=IMPRESS">ཨེཆ་ཊི་ཨེམ་ཨེལ་རྩ་སྒྲིག་ནང་གསལ་སྟོན་སྲུངསབཞག་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/html_import.html?DbPAR=IMPRESS">གསལ་སྟོན་ཚུ་ནང་ལུ་ཨེཆ་ཊི་ཨེམ་ཨེལ་ཤོག་ལེབ་ཚུ་ནང་འདྲེན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">ཚོས་གཞི་དང་སྟེགས་རིས་དེ་ལས་སྐེདཔ་བཏོགས་ནིའི་ཐོ་ཡིག་ཚུ་མངོན་གསལ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">ཇི་ཨའི་ཨེཕ་རྩ་སྒྲིག་ནང་བསྒུལ་བཟོ་ཚུ་ཕྱིར་འདྲེན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">བཤུད་ཚུ་ནང་ཤོག་ཁྲམ་ཚུ་གྲངས་སུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">ཚད་རིས་ཚུ་ བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">གསལ་སྟོན་གཞན་ཚུ་ལས་བཤུད་ཚུ་འདར་བཤུས་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">རྩ་སྒྲིག་འབད་དོ།</label><ul>\
    <li><a target="_top" href="dz/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">ཚོས་གཞི་དང་སྟེགས་རིས་དེ་ལས་སྐེདཔ་བཏོགས་ནིའི་ཐོ་ཡིག་ཚུ་མངོན་གསལ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">གྲལ་ཐིག་དང་མདའ་རྟགས་བཟོ་རྣམ་ཚུ་མངོན་གསལ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">སྲོལ་སྒྲིག་ཚོས་གཞི་ཚུ་ ངེས་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">སྟེགས་རིས་ཀྱི་བཀང་བ་ཚུ་ གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">ཚོས་གཞི་ཚུ་ ཚབ་མ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">དངོས་པོ་ཚུ་ བདེ་ཞིབ་དང་ཕྲང་སྒྲིག་ དེ་ལས་བགོ་བཀྲམ་འབད་ནི།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/background.html?DbPAR=IMPRESS">བཤུད་རྒྱབ་གཞི་བཀང་ནི་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/footer.html?DbPAR=IMPRESS">བཤུད་ཚུ་ཆ་མཉམ་ལུ་མགོ་ཡིག་ཡང་ན་འཇུག་ཡིག་ཁ་སྐོང་རྐྱབས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/move_object.html?DbPAR=IMPRESS">དངོས་པོ་ཚུ་སྤོ་བཤུད་འབད་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">དཔར་བསྐྲུན་འབད་དོ།</label><ul>\
    <li><a target="_top" href="dz/text/simpress/guide/printing.html?DbPAR=IMPRESS">དཔར་བསྐྲུན་འབད་ནིའི་གསལ་སྟོན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">ཤོག་ལེབ་ཀྱི་ཚད་ཚུད་སྒྲིག་འབད་ནི་ལུ་བཤུ་དདཔར་བསྐྲུན་འབད་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">ནུས་ཅན་ཚུ།</label><ul>\
    <li><a target="_top" href="dz/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">ཇི་ཨའི་ཨེཕ་རྩ་སྒྲིག་ནང་བསྒུལ་བཟོ་ཚུ་ཕྱིར་འདྲེན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">གསལ་སྟོན་བཤུད་ཚུ་ནང་བསྒུལ་ཅན་བཟོ་ནིའི་དངོས་པོ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">བཤུད་འགྱུར་བ་ཚུ་བསྒུལ་ཅན་བཟོ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">དངོས་པོ་གཉིས་ སྐེདཔ་བཏོག་ཡལ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">བསྒུལ་ཅན་བཟོས་པའི་ཇི་ཨའི་ཨེཕ་གཟུགས་བརྙན་ཚུ་གསར་བསྐྲུན་འབད་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objects, Graphics, and Bitmaps</label><ul>\
    <li><a target="_top" href="dz/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">དངོས་པོ་ཚུ་མཉམ་མཐུད་དང་ དབྱིབས་ཚུ་བཟོ་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/groups.html?DbPAR=IMPRESS">དངོས་པོ་ཚུ་སྡེ་ཚན་བཟོ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">དུམ་ཚན་དང་ཆ་བགོས་ཚུ་ བྲིས།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">དངོས་པོ་ཚུ་ངོ་བཤུས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">དངོས་པོ་ཚུ་ བསྒྱིར་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">༣ཌི་ དངོས་པོ་ཚུ་ འཛོམས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">གྲལ་ཐིག་ཚུ་མཐུད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">ཚིག་ཡིག་ཡིག་འབྲུ་ཚུ་འབྲི་ནིའི་དངོས་པོ་ཚུ་ནང་ལུ་གཞི་བསྒྱུར་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">བིཊི་མེཔ་གཟུགས་བརྙན་ཚུ་མཉམ་ཐིག་ཚད་རིས་ཚུ་ནང་ལུ་གཞི་བསྒྱུར་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">༢་ཌི་དངོས་པོ་འདི་ གུག་གུགཔ་ཚུ་དང་ཟུར་མང་དབྱིབས་ཚུ་༣་ཌི་དངོས་པོ་ཚུ་ལུ་གཞི་བསྒྱུར་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">གྲལ་ཐིག་དང་མདའ་རྟགས་བཟོ་རྣམ་ཚུ་མངོན་གསལ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">གུག་གུགཔ་ཚུ་འབྲི་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">གུག་གུགཔ་ཚུ་ཞུན་དག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">ཚད་རིས་ཚུ་ བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">བཤུད་ཚུ་ནང་ཤོག་ཁྲམ་ཚུ་གྲངས་སུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/move_object.html?DbPAR=IMPRESS">དངོས་པོ་ཚུ་སྤོ་བཤུད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/select_object.html?DbPAR=IMPRESS">འོག་ལུ་ཡོད་པའི་དངོས་པོ་ཚུ་སེལ་འཐུ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">འབབ་རྒྱུན་དཔེ་རིས་གསར་བསྐྲུན་འབད་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text in Presentations</label><ul>\
    <li><a target="_top" href="dz/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">ཚིག་ཡིག་ ཁ་སྐོང་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">ཚིག་ཡིག་ཡིག་འབྲུ་ཚུ་འབྲི་ནིའི་དངོས་པོ་ཚུ་ནང་ལུ་གཞི་བསྒྱུར་འབད་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Viewing</label><ul>\
    <li><a target="_top" href="dz/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">བཤུད་ཀྱི་གོ་རིམ་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">ལྡེ་གདན་གཅིག་ཁར་རྒྱས་ཟུམ་འབད་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Slide Shows</label><ul>\
    <li><a target="_top" href="dz/text/simpress/guide/show.html?DbPAR=IMPRESS">བཤུད་བརྙན་ཅིག་སྟོན་དོ་</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/individual.html?DbPAR=IMPRESS">སྲོལ་སྒྲིག་བཤུད་བརྙན་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">བཤུད་བསྒྱུར་བཅོས་ཚུ་གི་མཐའ་སྦྱང་འབད་ནིའི་དུས་འཛིན་ཚུ།</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Drawings (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="dz/text/sdraw/main0000.html?DbPAR=DRAW">LibreOffice ཌཱ་གྲོགས་རམ་ལུ་ འབྱོན་པ་ལེགས་སོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main0503.html?DbPAR=DRAW">LibreOfficeཌཱ་ཁྱད་རྣམ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/keyboard.html?DbPAR=DRAW">དངོས་པོ་ཚུ་འབྲི་ནིའི་དོན་ལུ་ མགྱོགས་ཐབས་ལྡེ་མིག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/04/01020000.html?DbPAR=DRAW">པར་རིས་ཀྱི་དོན་ལུ་ མགྱོགས་ཐབས་ལྡེ་མིག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/main.html?DbPAR=DRAW">LibreOfficeཌཱ་ ལག་ལེན་འཐབ་ནིའི་དོན་ལས་ བསླབ་སྟོན་ཚུ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menus</label><ul>\
    <li><a target="_top" href="dz/text/sdraw/main0100.html?DbPAR=DRAW">དཀར་ཆག</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main0101.html?DbPAR=DRAW">ཡིག་སྣོད།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main0103.html?DbPAR=DRAW">མཐོང་སྣང་།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main_insert.html?DbPAR=DRAW">Insert</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main_tools.html?DbPAR=DRAW">Tools</a></li>\
    <li><a target="_top" href="dz/text/simpress/main0107.html?DbPAR=DRAW">སྒོ་སྒྲིག</a></li>\
    <li><a target="_top" href="dz/text/shared/main0108.html?DbPAR=DRAW">གྲོགས་རམ།</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Toolbars</label><ul>\
    <li><a target="_top" href="dz/text/sdraw/main0200.html?DbPAR=DRAW">ལག་ཆས་ཕྲ་རིང་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main0210.html?DbPAR=DRAW">པར་རིས་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/main0213.html?DbPAR=DRAW">གདམ་ཁ་ཚུའི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0201.html?DbPAR=DRAW">ཚད་ལྡན་གྱི་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0213.html?DbPAR=DRAW">འབྲི་ཤོག་འགྲུལ་བསྐྱོད་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0226.html?DbPAR=DRAW">འབྲི་ཤོག་བཀོད་སྒྲིག་ལག་ཆས་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/main0227.html?DbPAR=DRAW">ས་ཚིགས་ཕྲ་རིང་ཚུ་ཞུན་དག་འབད།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">3D-Settings</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Loading, Saving, Importing, and Exporting</label><ul>\
    <li><a target="_top" href="dz/text/simpress/guide/palette_files.html?DbPAR=DRAW">ཚོས་གཞི་དང་སྟེགས་རིས་དེ་ལས་སྐེདཔ་བཏོགས་ནིའི་ཐོ་ཡིག་ཚུ་མངོན་གསལ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">ཚད་རིས་ཚུ་ བཙུགས་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatting</label><ul>\
    <li><a target="_top" href="dz/text/simpress/guide/palette_files.html?DbPAR=DRAW">ཚོས་གཞི་དང་སྟེགས་རིས་དེ་ལས་སྐེདཔ་བཏོགས་ནིའི་ཐོ་ཡིག་ཚུ་མངོན་གསལ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">གྲལ་ཐིག་དང་མདའ་རྟགས་བཟོ་རྣམ་ཚུ་མངོན་གསལ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/color_define.html?DbPAR=DRAW">སྲོལ་སྒྲིག་ཚོས་གཞི་ཚུ་ ངེས་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/gradient.html?DbPAR=DRAW">སྟེགས་རིས་ཀྱི་བཀང་བ་ཚུ་ གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">ཚོས་གཞི་ཚུ་ ཚབ་མ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">དངོས་པོ་ཚུ་ བདེ་ཞིབ་དང་ཕྲང་སྒྲིག་ དེ་ལས་བགོ་བཀྲམ་འབད་ནི།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/background.html?DbPAR=DRAW">བཤུད་རྒྱབ་གཞི་བཀང་ནི་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/move_object.html?DbPAR=DRAW">དངོས་པོ་ཚུ་སྤོ་བཤུད་འབད་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Printing</label><ul>\
    <li><a target="_top" href="dz/text/simpress/guide/printing.html?DbPAR=DRAW">དཔར་བསྐྲུན་འབད་ནིའི་གསལ་སྟོན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/print_tofit.html?DbPAR=DRAW">ཤོག་ལེབ་ཀྱི་ཚད་ཚུད་སྒྲིག་འབད་ནི་ལུ་བཤུ་དདཔར་བསྐྲུན་འབད་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effects</label><ul>\
    <li><a target="_top" href="dz/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">དངོས་པོ་གཉིས་ སྐེདཔ་བཏོག་ཡལ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/01/05350000.html?DbPAR=DRAW">༣ ཌི་ནུས་པ་ཚུ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objects, Graphics, and Bitmaps</label><ul>\
    <li><a target="_top" href="dz/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">དངོས་པོ་ཚུ་མཉམ་མཐུད་དང་ དབྱིབས་ཚུ་བཟོ་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">དུམ་ཚན་དང་ཆ་བགོས་ཚུ་ བྲིས།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">དངོས་པོ་ཚུ་ངོ་བཤུས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">དངོས་པོ་ཚུ་ བསྒྱིར་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">༣ཌི་ དངོས་པོ་ཚུ་ འཛོམས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/join_objects.html?DbPAR=DRAW">གྲལ་ཐིག་ཚུ་མཐུད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/text2curve.html?DbPAR=DRAW">ཚིག་ཡིག་ཡིག་འབྲུ་ཚུ་འབྲི་ནིའི་དངོས་པོ་ཚུ་ནང་ལུ་གཞི་བསྒྱུར་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/vectorize.html?DbPAR=DRAW">བིཊི་མེཔ་གཟུགས་བརྙན་ཚུ་མཉམ་ཐིག་ཚད་རིས་ཚུ་ནང་ལུ་གཞི་བསྒྱུར་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/3d_create.html?DbPAR=DRAW">༢་ཌི་དངོས་པོ་འདི་ གུག་གུགཔ་ཚུ་དང་ཟུར་མང་དབྱིབས་ཚུ་༣་ཌི་དངོས་པོ་ཚུ་ལུ་གཞི་བསྒྱུར་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">གྲལ་ཐིག་དང་མདའ་རྟགས་བཟོ་རྣམ་ཚུ་མངོན་གསལ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/line_draw.html?DbPAR=DRAW">གུག་གུགཔ་ཚུ་འབྲི་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/line_edit.html?DbPAR=DRAW">གུག་གུགཔ་ཚུ་ཞུན་དག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">ཚད་རིས་ཚུ་ བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/table_insert.html?DbPAR=DRAW">བཤུད་ཚུ་ནང་ཤོག་ཁྲམ་ཚུ་གྲངས་སུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/move_object.html?DbPAR=DRAW">དངོས་པོ་ཚུ་སྤོ་བཤུད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/select_object.html?DbPAR=DRAW">འོག་ལུ་ཡོད་པའི་དངོས་པོ་ཚུ་སེལ་འཐུ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/orgchart.html?DbPAR=DRAW">འབབ་རྒྱུན་དཔེ་རིས་གསར་བསྐྲུན་འབད་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Groups and Layers</label><ul>\
    <li><a target="_top" href="dz/text/sdraw/guide/groups.html?DbPAR=DRAW">དངོས་པོ་ཚུ་སྡེ་ཚན་བཟོ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserting Layers</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="dz/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text in Drawings</label><ul>\
    <li><a target="_top" href="dz/text/sdraw/guide/text_enter.html?DbPAR=DRAW">ཚིག་ཡིག་ ཁ་སྐོང་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/simpress/guide/text2curve.html?DbPAR=DRAW">ཚིག་ཡིག་ཡིག་འབྲུ་ཚུ་འབྲི་ནིའི་དངོས་པོ་ཚུ་ནང་ལུ་གཞི་བསྒྱུར་འབད་དོ།</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Viewing</label><ul>\
    <li><a target="_top" href="dz/text/simpress/guide/change_scale.html?DbPAR=DRAW">ལྡེ་གདན་གཅིག་ཁར་རྒྱས་ཟུམ་འབད་དོ།</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Database Functionality (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">General Information</label><ul>\
    <li><a target="_top" href="dz/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/database_main.html?DbPAR=BASE">གནད་སྡུད་གཞི་རྟེན་སྤྱི་མཐོང་།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_new.html?DbPAR=BASE">གནད་སྡུད་གཞི་རྟེན་གསརཔ་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_tables.html?DbPAR=BASE">ཐིག་ཁྲམ་ཚུ་དང་གཅིག་ཁར་ལཱ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_queries.html?DbPAR=BASE">འདྲི་དཔྱད་ཚུ་དང་གཅིག་ཁར་ལཱ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_forms.html?DbPAR=BASE">འབྲི་ཤོག་ཚུ་དང་གཅིག་ཁར་ལཱ་འབདདོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_reports.html?DbPAR=BASE">Creating Reports</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_register.html?DbPAR=BASE">གནད་སྡུད་གཞི་རྟེན་ཐོ་བཀོད་དང་བཏོན་གཏང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_im_export.html?DbPAR=BASE">གཞི་རྟེན་ནང་ གནད་སྡུད་ ནང་འདྲེན་དང་ཕྱིར་འདྲེན་འབད་དོ་</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_enter_sql.html?DbPAR=BASE">ཨེསི་ཀིའུ་ཨེལ་བརྡ་བཀོད་ཚུ་ལག་ལེན་འཐབ་དོ།</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formulas (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="dz/text/smath/main0000.html?DbPAR=MATH">LibreOfficeཨང་རྩིས་གྲོགས་རམ་ལུ་འབྱོན་པ་ལེགས་སོ།</a></li>\
    <li><a target="_top" href="dz/text/smath/main0503.html?DbPAR=MATH">LibreOffice ཨང་རྩིས་ཁྱད་རྣམ་ཚུ།</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formula Elements</label><ul>\
    <li><a target="_top" href="dz/text/smath/01/03090100.html?DbPAR=MATH">གཅིག་ལྡན་/ཟུང་ལྡན་གྱི་བཀོལ་སྤྱོད་པ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/smath/01/03090200.html?DbPAR=MATH">མཐུན་འབྲེལ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/smath/01/03090800.html?DbPAR=MATH">བཀོལ་སྤྱོད་པ་ཚུ་གཞི་སྒྲིག་འབད།</a></li>\
    <li><a target="_top" href="dz/text/smath/01/03090400.html?DbPAR=MATH">ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/smath/01/03090300.html?DbPAR=MATH">བཀོལ་སྤྱོད་པ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/smath/01/03090600.html?DbPAR=MATH">ཁྱད་ཆོས་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/smath/01/03090500.html?DbPAR=MATH">གུག་ཤད་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/smath/01/03090700.html?DbPAR=MATH">རྩ་སྒྲིག་</a></li>\
    <li><a target="_top" href="dz/text/smath/01/03091600.html?DbPAR=MATH">བརྡ་མཚོན་གཞན་མི་ཚུ།</a></li>\
            </ul></li>\
    <li><a target="_top" href="dz/text/smath/guide/main.html?DbPAR=MATH">LibreOffice ཨང་རྩིས་ལག་ལེན་འཐབ་ནིའི་དོན་ལུ་བསླབ་སྟོན།</a></li>\
    <li><a target="_top" href="dz/text/smath/guide/keyboard.html?DbPAR=MATH">མགྱོགས་ཐབས་ (LibreOffice ཨང་རྩིས་འཛུལ་སྤྱོད་)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Command and Menu Reference</label><ul>\
    <li><a target="_top" href="dz/text/smath/main0100.html?DbPAR=MATH">དཀར་ཆག</a></li>\
    <li><a target="_top" href="dz/text/smath/main0200.html?DbPAR=MATH">ལག་ཆས་ཕྲ་རིང་ཚུ་།</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Working with Formulas</label><ul>\
    <li><a target="_top" href="dz/text/smath/guide/align.html?DbPAR=MATH">ལག་ཐོག་ལས་ཕྲང་སྒྲིག་འབད་ནིའི་མན་ངག་གི་ཡན་ལག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/smath/guide/attributes.html?DbPAR=MATH">སྔོན་སྒྲིག་ཁྱད་ཆོས་ཚུ་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/smath/guide/brackets.html?DbPAR=MATH">གུག་ཤད་ཚུ་ནང་ལུ་ས་སྟོང་མན་ངག་གི་ཡན་ལག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/smath/guide/comment.html?DbPAR=MATH">བསམ་བཀོད་ཚུ་ཐོ་བཀོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/smath/guide/newline.html?DbPAR=MATH">གྲལ་མཚམས་ཐོ་བཀོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/smath/guide/parentheses.html?DbPAR=MATH">གུག་ཤད་ཚུ་ཐོ་བཀོད་འབད་དོ།</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Charts and Diagrams</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">General Information</label><ul>\
    <li><a target="_top" href="dz/text/schart/main0000.html?DbPAR=CHART">LibreOffice ནང་གི་དཔེ་རིས་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/schart/main0503.html?DbPAR=CHART">LibreOffice དཔེ་རིས་ཁྱད་རྣམ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/schart/04/01020000.html?DbPAR=CHART">དཔེ་རིས་ཀྱི་དོན་ལུ་མགྱོགས་ཐབས།</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Macros and Scripting</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="dz/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice གཞི་རྟེན་འགྲོགས་རམ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01000000.html?DbPAR=BASIC">LibreOffice གཞི་རྟེན་ཅིག་ཁར་ལས་རིམ་བཟོ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice གཞི་རིམ་ཚིག་ཐོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01010210.html?DbPAR=BASIC">གཞི་རྟེན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01020000.html?DbPAR=BASIC">ཚིག་སྦྱོར།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice གཞི་རྟེན་ ཨའི་ཌི་ཨི།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01030100.html?DbPAR=BASIC">ཨའི་ཌི་ཨི་སྤྱི་མཐོང་།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01030200.html?DbPAR=BASIC">གཞི་རྟེན་ཞུན་དག་འདི།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01050100.html?DbPAR=BASIC">ཝིན་དོ་བལྟ་ཞིབ་འབད་ནི།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/main0211.html?DbPAR=BASIC">མེཀརོ་ལག་ཆ་ཕྲ་རིང་།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/05060700.html?DbPAR=BASIC">མེཀརོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Command Reference</label><ul>\
    <li><a target="_top" href="dz/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01020500.html?DbPAR=BASIC">དཔེ་མཛོད་ཚུ་ ཚད་བཟུང་ཚུ་དང་ཌའི་ལོགསི།</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Functions, Statements, and Operators</label><ul>\
    <li><a target="_top" href="dz/text/sbasic/shared/03010000.html?DbPAR=BASIC">གསལ་གཞི་   I/O  ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020000.html?DbPAR=BASIC">ཡིག་སྣོད  ༡/༠ ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030000.html?DbPAR=BASIC">ཚེས་དང་དུས་ཚོད་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03050000.html?DbPAR=BASIC">ལས་འགན་ཚུ་ལེགས་སྐྱོང་འཐབ་པ་འཛོལ་བ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03060000.html?DbPAR=BASIC">གཏན་ཚིག་ཅན་བཀོལ་སྤྱོད་པ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03070000.html?DbPAR=BASIC">ཨང་རྩིས་བཀོལ་སྤྱོད་པ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080000.html?DbPAR=BASIC">ཨང་གྲངས་ཀྱི་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090000.html?DbPAR=BASIC">ལས་རིམ་ལག་ལེན་འཐབ་ནི་ཚད་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100000.html?DbPAR=BASIC">འགྱུར་ཅན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03110000.html?DbPAR=BASIC">ག་བསྡུར་བཀོལ་སྤྱོདཔ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120000.html?DbPAR=BASIC">ཡིག་རྒྱུན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Calling Calc Functions in Macros</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03130000.html?DbPAR=BASIC">གཞན་བརྡ་བཀོད་ཚུ།</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alphabetic List of Functions, Statements, and Operators</label><ul>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03050000.html?DbPAR=BASIC">ལས་འགན་ཚུ་ལེགས་སྐྱོང་འཐབ་པ་འཛོལ་བ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090400.html?DbPAR=BASIC">ཐེབས་གསལ་བཤད་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080300.html?DbPAR=BASIC">ཨང་ཚུ་གང་འབྲུང་བཟོ་བཏོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input # Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080000.html?DbPAR=BASIC">ཨང་གྲངས་ཀྱི་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080400.html?DbPAR=BASIC">གྲུ་བཞི་རྩ་བ་རྩིས་སྟོན་ནི།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03080100.html?DbPAR=BASIC">ཊིར་གོ་ནོ་མེ་ཊིཀ་ལས་འགན་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write Statement</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Advanced Basic Libraries</label><ul>\
    <li><a target="_top" href="dz/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guides</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/macro_recording.html?DbPAR=BASIC">མེཀ་རོ་སྒྲ་བཟུང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/guide/control_properties.html?DbPAR=BASIC">ཌའི་ལོག་ཞུན་དག་པའི་ནང་ལུ་ ཚད་འཛིན་གྱི་རྒྱུ་དངོས་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/guide/insert_control.html?DbPAR=BASIC">ཌའི་ཞུན་དག་པའི་ནང་ལུ་ ཚད་འཛིན་ཞུན་དག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/guide/sample_code.html?DbPAR=BASIC">ཌའི་ལོག་ཞུན་དག་པ་ནང་གི་ ཚད་འཛིན་གྱི་དོན་ལུ་ དཔེའི་ལས་རིམ་སྟོན་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="dz/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">གཞི་རྩའི་ཌའི་ལོག་ གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01030400.html?DbPAR=BASIC">དཔེ་མཛོད་ཚུ་དང་ཚད་བཟུང་ཚུ་འགོ་འདྲེན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01020100.html?DbPAR=BASIC">འགྱུར་ཅན་ཚུ་ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01020200.html?DbPAR=BASIC">དངོས་པོ་ཚུ་ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01030300.html?DbPAR=BASIC">གཞི་རྟེན་ལས་རིམ་རྐྱེན་སེལ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/shared/01040000.html?DbPAR=BASIC">བྱུང་ལས་ཌའིབན་ མེཀརོསི།</a></li>\
    <li><a target="_top" href="dz/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="dz/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic to Python</a></li>\
    <li><a target="_top" href="dz/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python Scripts Help</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="dz/text/sbasic/python/main0000.html?DbPAR=BASIC">Python Scripts</a></li>\
    <li><a target="_top" href="dz/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE for Python</a></li>\
    <li><a target="_top" href="dz/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="dz/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programming with Python</label><ul>\
    <li><a target="_top" href="dz/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="dz/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python examples</a></li>\
    <li><a target="_top" href="dz/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice Installation</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">མའི་ཀོརོ་སོཕཊི་ཨོ་ཕིསི་ཡིག་ཆའི་དབྱེ་བ་ཚུ་གི་ཚོགས་པ་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Safe Mode</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Common Help Topics</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">General Information</label><ul>\
    <li><a target="_top" href="dz/text/shared/main0400.html?DbPAR=SHARED">མགྱོགས་ཐབས་ལྡེ་མིག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/00/00000005.html?DbPAR=SHARED">སྤྱིར་གཏང་གི་ཚིག་ཐོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/00/00000002.html?DbPAR=SHARED">ཨིན་ཊར་ནེཊི་ལམ་ལུགས་ཀྱི་ཚིག་ཐོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/accessibility.html?DbPAR=SHARED">LibreOffice ནང་འཛུལ་སྤྱོད།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/keyboard.html?DbPAR=SHARED">མགྱོགས་ཐབས་ཚུ་(LibreOffice འཛུལ་སྤྱོད།)</a></li>\
    <li><a target="_top" href="dz/text/shared/04/01010000.html?DbPAR=SHARED">LibreOfficeནང་ ཡོངས་ཁྱབ་མགྱོགས་ཐབས་ལྡེ་མིག</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/version_number.html?DbPAR=SHARED">ཐོན་རིམ་ཚུ་དང་བཟོ་བརྩིགས་གྲངས་ཚུ།</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice and Microsoft Office</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/ms_user.html?DbPAR=SHARED">མའི་ཀོརོ་སོཕཊི་ཨོ་ཕིསི་དང་LibreOffice ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">མའི་ཀོརོ་སོཕཊི་ཨོ་ཕིསི་དང་LibreOffice ལམ་ལུགས་ག་བསྡུར་བརྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">མའི་ཀོརོ་སོཕཊི་ཨོ་ཕིསི་ཡིག་ཆ་ཚུ་གཞི་བསྒྱུར་འབད་ནིའི་སྐོར་ལས།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">མའི་ཀོརོ་སོཕཊི་ཨོ་ཕིསི་ཡིག་ཆའི་དབྱེ་བ་ཚུ་གི་ཚོགས་པ་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice Options</label><ul>\
    <li><a target="_top" href="dz/text/shared/optionen/01000000.html?DbPAR=SHARED">གདམ་ཁ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01010100.html?DbPAR=SHARED">ལག་ལེན་པའི་གནད་སྡུད།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01010200.html?DbPAR=SHARED">ཡོངས་ཁྱབ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01010300.html?DbPAR=SHARED">འགྲུལ་ལམ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01010400.html?DbPAR=SHARED">རྩོམ་ཆས།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01010600.html?DbPAR=SHARED">ཡོངས་ཁྱབ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01010700.html?DbPAR=SHARED">ཡིག་གཟུགས་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01010800.html?DbPAR=SHARED">View</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01010900.html?DbPAR=SHARED">དཔར་བསྐྲུན་གདམ་ཁ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01012000.html?DbPAR=SHARED">Application Colors</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01013000.html?DbPAR=SHARED">འཛུལ་སྤྱོད།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/java.html?DbPAR=SHARED">Advanced</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/opencl.html?DbPAR=SHARED">Open CL</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01020000.html?DbPAR=SHARED">མངོན་གསལ་/གདམ་ཁ་ཚུ་སྲུངས།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01030000.html?DbPAR=SHARED">ཨིན་ཊར་ནེཊི་གདམ་ཁ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01040000.html?DbPAR=SHARED">ཚིག་ཡིག་ཡིག་ཆའི་གདམ་ཁ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01050000.html?DbPAR=SHARED">ཨེཆ་ཊི་ཨེམ་ཨེལ་ཡིག་ཆའི་གདམ་ཁ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01060000.html?DbPAR=SHARED">ཤོག་ཁྲམ་གྱི་གདམ་ཁ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01070000.html?DbPAR=SHARED">གསལ་སྟོན་གདམ་ཁ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01080000.html?DbPAR=SHARED">པར་རིས་གདམ་ཁ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01090000.html?DbPAR=SHARED">མན་ངག</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01110000.html?DbPAR=SHARED">དཔེ་རིས་གདམ་ཁ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01130100.html?DbPAR=SHARED">ཝི་བི་ཨེ་རྒྱུ་དངོས་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01130200.html?DbPAR=SHARED">མའི་ཀོརོ་སོཕཊི་ཨོ་ཕིསི།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01140000.html?DbPAR=SHARED">སྐད་ཡིག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01150000.html?DbPAR=SHARED">སྐད་ཡིག་སྒྲིག་སྟངས་གདམ་ཁ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/optionen/01160000.html?DbPAR=SHARED">གནད་སྡུད་འབྱུང་ཁུངས་ཚུའི་གདམ་ཁ་ཚུ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Wizards</label><ul>\
    <li><a target="_top" href="dz/text/shared/autopi/01000000.html?DbPAR=SHARED">ཝི་ཛརཌི།</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">ཡི་གུ་ ཝི་ཛརཌི།</label><ul>\
    <li><a target="_top" href="dz/text/shared/autopi/01010000.html?DbPAR=SHARED">ཡི་གུ་ ཝི་ཛརཌི།</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">དཔར་འཕྲིན་ཝི་ཛརཌི།</label><ul>\
    <li><a target="_top" href="dz/text/shared/autopi/01020000.html?DbPAR=SHARED">དཔར་འཕྲིན་ཝི་ཛརཌི།</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">གྲོས་གཞི་ ཝི་ཛརཌི།</label><ul>\
    <li><a target="_top" href="dz/text/shared/autopi/01040000.html?DbPAR=SHARED">གྲོས་གཞི་ ཝི་ཛརཌི།</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML Export Wizard</label><ul>\
    <li><a target="_top" href="dz/text/shared/autopi/01110000.html?DbPAR=SHARED">ཨེཅ་ཊི་ཨེམ་ཨེལ་ ཕྱིར་འདྲེན།</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Document Converter Wizard</label><ul>\
    <li><a target="_top" href="dz/text/shared/autopi/01130000.html?DbPAR=SHARED">ཡིག་ཆ་སྒྱུར་བྱེད།</a></li>\
			</ul></li>\
    <li><a target="_top" href="dz/text/shared/autopi/01150000.html?DbPAR=SHARED">ཡུ་རོ་སྒྱུར་བྱེད་ཝི་ཛརཌི།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configuring LibreOffice</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/configure_overview.html?DbPAR=SHARED">LibreOffice རིམ་སྒྲིག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/01/packagemanager.html?DbPAR=SHARED">རྒྱ་བསྐྱེད་འཛིན་སྐྱོང་པ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/flat_icons.html?DbPAR=SHARED">ངོས་དཔར་མཐོང་སྣང་ཚུ་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">ལག་ཆས་ཕྲ་རིང་ཚུ་ལུ་ཨེབ་རྟ་ཚུ་ཁ་སྐོང་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/workfolder.html?DbPAR=SHARED">ཁྱོད་ཀྱི་ལཱ་གི་སྣོད་ཐོ་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/standard_template.html?DbPAR=SHARED">སྔོན་སྒྲིག་ཊེམ་པེལེཊི་ཚུ་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_addressbook.html?DbPAR=SHARED">ཁ་བྱང་ཀི་དེབ་ཐོ་བཀོད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/formfields.html?DbPAR=SHARED">བཙུགས་ནི་དང་ཞུན་དག་འབད་ནིའི་ཨེབ་རྟ་ཚུ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Working with the User Interface</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">དངོས་པོ་ཚུ་འཕྲལ་མགྱོགས་སྦེ་ལྷོད་ནི་ལུ་འགྲུལ་བསྐྱོདཔ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/navigator.html?DbPAR=SHARED">ཡིག་ཆ་སྤྱི་མཐོང་གི་དོན་ལས་འགྲུལ་བསྐྱོདཔ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/autohide.html?DbPAR=SHARED">སྟོན་ནི་དང་ཌོཀ་འབད་ནི་དེ་ལས་གསང་བཞག་ནིའི་ཝིན་ཌོསི།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/textmode_change.html?DbPAR=SHARED">བཙུགས་ཐབས་ལམ་དང་ཚབ་སྲུང་ཐབས་ལམ་བར་ན་སོར་བསྒྱུར་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">ལག་ཆས་ཕྲ་རིང་ཚུ་ལག་ལེན་འཐབ་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digital Signatures</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/digital_signatures.html?DbPAR=SHARED">ཌི་ཇི་ཊཱལ་མིང་རྟགས་ཚུ་ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">ཌི་ཇི་ཊཱལ་མིང་རྟགས་ཚུ་ལག་ལེན་འཐབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="dz/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="dz/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="dz/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Printing, Faxing, Sending</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/labels_database.html?DbPAR=SHARED">ཁ་བྱང་ཁ་ཡིག་ཚུ་དཔར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">དཀརཔོ་དང་གནགཔོ་ནང་དཔར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/email.html?DbPAR=SHARED">ཡིག་ཆ་ཚུ་གློག་འཕྲིན་བཟུམ་སྦེ་གཏང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/fax.html?DbPAR=SHARED">དཔར་འཕྲིན་གཏང་ནིའི་དོན་ལུ་དཔར་འཕྲིན་གཏང་ནི་དང་LibreOffice རིམ་སྒྲིག་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Drag & Drop</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/dragdrop.html?DbPAR=SHARED">LibreOffice ཡིག་ཆ་ནང་འཁོད་ལུ་འདྲུད་ནི་དང་བཀོག་བཞག་ནི།</a></li>\
    <li><a target="_top" href="dz/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">ཡིག་ཆ་ཚུ་ནང་ལུ་ ཚིག་ཡིག་སྤོ་བཤུད་དང་འདྲ་བཤུས་རྐྱབས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">ཤོག་ཁྲམ་མངའ་ཁོངས་ཚུ་ ཚིག་ཡིག་གི་ཡིག་ཆ་ཚུ་ལུ་འདྲ་བཤུས་རྐྱབས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">ཡིག་ཆ་ཚུའི་བར་ན་ཚད་རིས་ཚུ་འདྲ་བཤུས་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">སྟོན་ཁང་ལས་ཚད་རིས་ཚུ་འདྲ་བཤུས་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">གནད་སྡུད་འབྱུང་ཁུངས་མཐོང་སྣང་གཅིག་ཁར་འདྲུད་-དང་-བཀོག་བཞག</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copy and Paste</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">གཞན་ཡིག་ཆ་ཚུ་ནང་ལུ་པར་རིས་དངོས་པོ་ཚུ་འདྲ་བཤུས་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">ཡིག་ཆ་ཚུའི་བར་ན་ཚད་རིས་ཚུ་འདྲ་བཤུས་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">སྟོན་ཁང་ལས་ཚད་རིས་ཚུ་འདྲ་བཤུས་རྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">ཤོག་ཁྲམ་མངའ་ཁོངས་ཚུ་ ཚིག་ཡིག་གི་ཡིག་ཆ་ཚུ་ལུ་འདྲ་བཤུས་རྐྱབས་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Charts and Diagrams</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/chart_insert.html?DbPAR=SHARED">དཔེ་རིས་ཚུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/schart/main0000.html?DbPAR=SHARED">LibreOffice ནང་གི་དཔེ་རིས་ཚུ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Load, Save, Import, Export, PDF</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/doc_open.html?DbPAR=SHARED">ཡིག་ཆ་ཚུ་ཁ་ཕྱེ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/import_ms.html?DbPAR=SHARED">གཞན་མི་རྩ་སྒྲིག་ནང་ལུ་སྲུང་བཞག་འབད་ཡོད་མི་ཡིག་ཆ་ཚུ་ཁ་ཕྱེ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/doc_save.html?DbPAR=SHARED">ཡིག་ཆ་ཚུ་སྲུང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/doc_autosave.html?DbPAR=SHARED">ཡིག་ཆ་ཚུ་རང་བཞིན་གྱིས་སྲུང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/export_ms.html?DbPAR=SHARED">གཞན་མི་རྩ་སྒྲིག་ཚུ་ནང་ཡིག་ཆ་ཚུ་སྲུང་བཞག་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">པི་ཌི་ཨེཕ་འབད་ཕྱིར་འདྲེན་འབད།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">ཚིག་ཡིག་རྩ་སྒྲིག་ནང་ནང་འདྲེན་དང་ཕྱིར་འདྲེན་འབད་ནིའི་གནད་སྡུད།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Links and References</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">ཚད་བརྒལ་འབྲེལ་ལམ་ཚུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">འབྲེལ་བའི་དང་ཡང་དག་འབྲེལ་ལམ་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">ཚད་བརྒལ་འབྲེལ་ལམ་ཚུ་ཞུན་དག་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Document Version Tracking</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">ཡིག་ཆ་གི་ཐོན་རིམ་ཚུ་ག་བསྡུར་བརྐྱབ་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">ཐོན་རིམ་ཚུ་མཉམ་བསྡོམས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/redlining_enter.html?DbPAR=SHARED">སྒྲ་བཟུང་ནིའི་བསྒྱུར་བཅོས་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/redlining.html?DbPAR=SHARED">བསྒྱུར་བཅོས་ཚུ་སྒྲ་བཟུང་དང་བཀྲམ་སྟོན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/redlining_accept.html?DbPAR=SHARED">བསྒྱུར་བཅོས་ཚུ་དང་ལེན་ཡང་ན་དང་ལེན་སྤངས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/redlining_versions.html?DbPAR=SHARED">ཐོན་རིམ་འཛིན་སྐྱོང་།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Labels and Business Cards</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/labels.html?DbPAR=SHARED">གསར་བསྐྲུན་དང་དཔར་བསྐྲུན་འབད་ནིའི་ཁ་ཡིག་ཚུ་དང་ཚོང་འབྲེལ་ཤོག་བྱང་ཚུ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Inserting External Data</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/copytable2application.html?DbPAR=SHARED">ཤོག་ཁྲམ་ཚུ་ལས་གནད་སྡུད་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/copytext2application.html?DbPAR=SHARED">ཚིག་ཡིག་ཡིག་ཆ་ཚུ་ལས་གནད་སྡུད་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">དིཊི་མེཔ་ཚུ་བཙུགས་དོ་ ཞུན་དག་འབད་དོ་ སྲུང་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">སྟོན་ཁང་ལུ་ཚད་རིས་ཚུ་ཁ་སྐོང་རྐྱབ་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automatic Functions</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/autocorr_url.html?DbPAR=SHARED">རང་བཞིན་གྱི་ཡུ་ཨར་ཨེལ་ངོས་འཛིན་ཊཱན་ཨོཕ་འབད་དོ།</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Searching and Replacing</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/data_search2.html?DbPAR=SHARED">འབྲི་ཤོག་ཚགས་མ་གཅིག་ཁར་འཚོལ་ཞིབ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_search.html?DbPAR=SHARED">ཐིག་ཁྲམ་ཚུ་དང་འབྲི་ཤོག་ཡིག་ཆ་ཚུ་འཚོལ་ཞིབ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/01/02100001.html?DbPAR=SHARED">དུས་རྒྱུན་གསལ་བརྗོད་ཚུ་གི་ཐོ་ཡིག</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guides</label><ul>\
    <li><a target="_top" href="dz/text/shared/guide/linestyles.html?DbPAR=SHARED">འགྲལ་ཐིག་གི་བཟོ་རྣམ་ཚུ་འཇུག་སྤྱོད་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/text_color.html?DbPAR=SHARED">ཚིག་ཡིག་གི་ཚོས་གཞི་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/change_title.html?DbPAR=SHARED">ཡིག་ཆ་གི་མགོ་མིང་བསྒྱུར་བཅོས་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/round_corner.html?DbPAR=SHARED">སྒོར་སྒོརམ་སྒྱིད་ཁུག་ཚུ་གསར་བསྐྲུན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/background.html?DbPAR=SHARED">རྒྱབ་གཞི་ཚོས་གཞི་ཚུ་ཡང་ན་རྒྱབ་གཞི་ཚད་རིས་ཚུ་ངེས་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/lineend_define.html?DbPAR=SHARED">གྲལ་ཐིག་མཇུག་ཚུ་ངེས་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/linestyle_define.html?DbPAR=SHARED">གྲལ་ཐིག་བཟོ་རྣམ་ཚུ་ངེས་འཛིན་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Editing Graphic Objects</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/line_intext.html?DbPAR=SHARED">ཚིག་ཡིག་ནང་པར་རིས་གྲལ་ཐིག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/aaa_start.html?DbPAR=SHARED">རིམ་པ་དང་པ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/gallery_insert.html?DbPAR=SHARED">སྟོན་ཁང་ལས་དངོས་པོ་ཚུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">དམིགས་བསལ་གྱི་ཡིག་འབྲུ་ཚུ་བཙུགས་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/tabs.html?DbPAR=SHARED">བཙུགས་ནི་དང་ཞུན་དག་འབད་ནིའི་མཆོང་ལྡེ་བཀག་ཚུ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/protection.html?DbPAR=SHARED">LibreOffice ནང་ནང་དོན་ཉེན་སྐྱོབ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/redlining_protect.html?DbPAR=SHARED">སྙན་ཞུ་ཚུ་ཉེན་སྐྱོབ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/pageformat_max.html?DbPAR=SHARED">ཤོག་ལེབ་གུ་དཔར་བསྐྲུན་འབད་བཏུབ་པའི་མངའ་ཁོངས་མང་མཐའ་སེལ་འཐུ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/measurement_units.html?DbPAR=SHARED">ཚད་འཇལ་ཆ་ཕྲན་ཚུ་སེལ་འཐུ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/language_select.html?DbPAR=SHARED">ཡིག་ཆའི་སྐད་ཡིག་སེལ་འཐུ་འབད་དོ།</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">ཐིག་ཁྲམ་བཀོད་བསྒྲིག</a></li>\
    <li><a target="_top" href="dz/text/shared/guide/numbering_stop.html?DbPAR=SHARED">ངོ་རྐྱང་དོན་མཚམས་ཚུ་གི་དོན་ལུ་ཨང་བཏགས་ནི་དང་འགོ་ཚག་ཚུ་ཊཱན་ཨོཕ་འབད་དོ།</a></li>\
		</ul></li>\
	</ul></li></ul>\
';
