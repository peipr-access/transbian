document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Έγγραφα κειμένου (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Γενικές πληροφορίες και χρήση διεπαφής χρήστη</label><ul>\
    <li><a target="_top" href="el/text/swriter/main0000.html?DbPAR=WRITER">Καλωσορίσατε στη Βοήθεια για το LibreOffice Writer</a></li>\
    <li><a target="_top" href="el/text/swriter/main0503.html?DbPAR=WRITER">Χαρακτηριστικά του LibreOffice Writer</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/main.html?DbPAR=WRITER">Οδηγίες για τη χρήση του LibreOffice Writer</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Προσάρτηση και αλλαγή μεγέθους παραθύρων</a></li>\
    <li><a target="_top" href="el/text/swriter/04/01020000.html?DbPAR=WRITER">Πλήκτρα συντόμευσης για το LibreOffice Writer</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/words_count.html?DbPAR=WRITER">Καταμέτρηση λέξεων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/keyboard.html?DbPAR=WRITER">Χρήση συντομεύσεων πληκτρολογίου (Προσιτότητα στο LibreOffice Writer)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Εντολές και μενού αναφοράς</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Μενού</label><ul>\
    <li><a target="_top" href="el/text/swriter/main0100.html?DbPAR=WRITER">Μενού</a></li>\
    <li><a target="_top" href="el/text/swriter/main0101.html?DbPAR=WRITER">Αρχείο</a></li>\
    <li><a target="_top" href="el/text/swriter/main0102.html?DbPAR=WRITER">Επεξεργασία</a></li>\
    <li><a target="_top" href="el/text/swriter/main0103.html?DbPAR=WRITER">Προβολή</a></li>\
    <li><a target="_top" href="el/text/swriter/main0104.html?DbPAR=WRITER">Εισαγωγή</a></li>\
    <li><a target="_top" href="el/text/swriter/main0105.html?DbPAR=WRITER">Μορφή</a></li>\
    <li><a target="_top" href="el/text/swriter/main0115.html?DbPAR=WRITER">Τεχνοτροπίες</a></li>\
    <li><a target="_top" href="el/text/swriter/main0110.html?DbPAR=WRITER">Πίνακας</a></li>\
    <li><a target="_top" href="el/text/swriter/main0120.html?DbPAR=WRITER">Μενού φόρμας</a></li>\
    <li><a target="_top" href="el/text/swriter/main0106.html?DbPAR=WRITER">Εργαλεία</a></li>\
    <li><a target="_top" href="el/text/swriter/main0107.html?DbPAR=WRITER">Παράθυρο</a></li>\
    <li><a target="_top" href="el/text/shared/main0108.html?DbPAR=WRITER">Βοήθεια</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Γραμμές εργαλείων</label><ul>\
    <li><a target="_top" href="el/text/swriter/main0200.html?DbPAR=WRITER">Γραμμές εργαλείων</a></li>\
    <li><a target="_top" href="el/text/swriter/main0202.html?DbPAR=WRITER">Γραμμή μορφοποίησης</a></li>\
    <li><a target="_top" href="el/text/swriter/main0203.html?DbPAR=WRITER">Εργαλειοθήκη εικόνας</a></li>\
    <li><a target="_top" href="el/text/swriter/main0204.html?DbPAR=WRITER">Γραμμή πίνακα</a></li>\
    <li><a target="_top" href="el/text/swriter/main0205.html?DbPAR=WRITER">Γραμμή ιδιοτήτων αντικειμένου σχεδίασης</a></li>\
    <li><a target="_top" href="el/text/swriter/main0206.html?DbPAR=WRITER">Γραμμή εργαλείων Κουκίδες και αρίθμηση</a></li>\
    <li><a target="_top" href="el/text/swriter/main0208.html?DbPAR=WRITER">Γραμμή κατάστασης</a></li>\
    <li><a target="_top" href="el/text/swriter/main0210.html?DbPAR=WRITER">Προεπισκόπηση εκτύπωσης</a></li>\
    <li><a target="_top" href="el/text/swriter/main0213.html?DbPAR=WRITER">Χάρακες</a></li>\
    <li><a target="_top" href="el/text/swriter/main0214.html?DbPAR=WRITER">Γραμμή τύπου</a></li>\
    <li><a target="_top" href="el/text/swriter/main0215.html?DbPAR=WRITER">Γραμμή πλαισίου</a></li>\
    <li><a target="_top" href="el/text/swriter/main0216.html?DbPAR=WRITER">Γραμμή αντικειμένου OLE</a></li>\
    <li><a target="_top" href="el/text/swriter/main0220.html?DbPAR=WRITER">Γραμμή αντικειμένου κειμένου</a></li>\
    <li><a target="_top" href="el/text/shared/main0201.html?DbPAR=WRITER">Βασική γραμμή εργαλείων</a></li>\
    <li><a target="_top" href="el/text/shared/main0212.html?DbPAR=WRITER">Γραμμή δεδομένων πίνακα</a></li>\
    <li><a target="_top" href="el/text/shared/main0213.html?DbPAR=WRITER">Γραμμή πλοήγησης φόρμας</a></li>\
    <li><a target="_top" href="el/text/shared/main0214.html?DbPAR=WRITER">Γραμμή σχεδίασης ερωτημάτων</a></li>\
    <li><a target="_top" href="el/text/shared/main0226.html?DbPAR=WRITER">Γραμμή εργαλείων σχεδιασμού φόρμας</a></li>\
    <li><a target="_top" href="el/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Γραμμή εργαλείων LibreLogo</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">Δημιουργία εγγράφων κειμένου</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Περιήγηση και επιλογή με το πληκτρολόγιο</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Χρήση του άμεσου δρομέα</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Γραφικά σε έγγραφα κειμένου</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Εισαγωγή γραφικών αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Εισαγωγή γραφικού αντικειμένου από αρχείο</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Εισαγωγή γραφικών αντικειμένων από τη Συλλογή με μεταφορά και απόθεση</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Εισαγωγή εικόνας με χρήση σαρωτή</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Εισαγωγή διαγράμματος του Calc σε έγγραφο κειμένου</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Εισαγωγή γραφικών αντικειμένων από το LibreOffice Draw ή το Impress</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Πίνακες σε έγγραφα κειμένου</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Ενεργοποίηση ή απενεργοποίηση της αναγνώρισης αριθμών σε πίνακες</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/tablemode.html?DbPAR=WRITER">Τροποποίηση γραμμών και στηλών με χρήση του πληκτρολογίου</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/table_delete.html?DbPAR=WRITER">Διαγραφή πινάκων ή των περιεχομένων πίνακα</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/table_insert.html?DbPAR=WRITER">Εισαγωγή πινάκων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Επανάληψη κεφαλίδας πίνακα σε νέα σελίδα</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Αλλαγή μεγέθους γραμμών και στηλών σε πίνακα κειμένου</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Αντικείμενα σε έγγραφα κειμένου</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Τοποθέτηση αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/wrap.html?DbPAR=WRITER">Αναδίπλωση κειμένου γύρω από αντικείμενα</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Ενότητες και πλαίσια σε έγγραφα κειμένου</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/sections.html?DbPAR=WRITER">Χρήση ενοτήτων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/text_frame.html?DbPAR=WRITER">Εισαγωγή, επεξεργασία και πλαίσια σύνδεσης</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/section_edit.html?DbPAR=WRITER">Επεξεργασία ενοτήτων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/section_insert.html?DbPAR=WRITER">Εισαγωγή ενοτήτων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Πίνακες περιεχομένων και ευρετήρια</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Αρίθμηση κεφαλαίων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Ευρετήρια ορισμένα από το χρήστη</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Δημιουργία πίνακα περιεχομένων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/indices_index.html?DbPAR=WRITER">Δημιουργία αλφαβητικών ευρετηρίων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Ευρετήρια για πολλαπλά έγγραφα</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Δημιουργία βιβλιογραφίας</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Επεξεργασία ή διαγραφή καταχωρίσεων ευρετηρίου και πίνακα</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Ενημέρωση, επεξεργασία και διαγραφή ευρετηρίων και πινάκων περιεχομένων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Καθορισμός καταχωρίσεων ευρετηρίων ή πινάκων περιεχομένων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/indices_form.html?DbPAR=WRITER">Μορφοποίηση ευρετηρίου ή πίνακα περιεχομένων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Πεδία σε έγγραφα κειμένου</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/fields.html?DbPAR=WRITER">Περί πεδίων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/fields_date.html?DbPAR=WRITER">Εισαγωγή πεδίου σταθερής ή μεταβλητής ημερομηνίας</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/field_convert.html?DbPAR=WRITER">Μετατροπή πεδίων σε κείμενο</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Περιήγηση εγγράφων κειμένου</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Μετακίνηση και αντιγραφή κειμένου σε έγγραφα</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Αναδιάταξη ενός εγγράφου με χρήση του περιηγητή</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Εισαγωγή υπερσυνδέσμων με τον περιηγητή</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/navigator.html?DbPAR=WRITER">Περιήγηση για έγγραφα κειμένου</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Υπολογισμοί σε έγγραφα κειμένου</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Υπολογισμός σε πίνακες</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/calculate.html?DbPAR=WRITER">Υπολογισμοί σε έγγραφα κειμένου</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Υπολογισμός και επικόλληση του αποτελέσματος ενός τύπου σε έγγραφο κειμένου</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Υπολογισμός αθροισμάτων κελιών σε πίνακες</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Υπολογισμοί σύνθετων τύπων σε έγγραφα κειμένου.</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Προβολή του αποτελέσματος ενός υπολογισμού πίνακα σε διαφορετικό πίνακα</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Μορφοποίηση σε έγγραφα κειμένου</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">Πρότυπα και τεχνοτροπίες</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Πρότυπα και τεχνοτροπίες</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Εναλλασσόμενες τεχνοτροπίες σελίδας σε περιττές και άρτιες σελίδες</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/change_header.html?DbPAR=WRITER">Δημιουργία τεχνοτροπίας σελίδας με βάση την τρέχουσα σελίδα</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/load_styles.html?DbPAR=WRITER">Χρήση τεχνοτροπιών από διαφορετικό έγγραφο ή πρότυπο</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Δημιουργία νέων τεχνοτροπιών από επιλογές</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Ενημέρωση τεχνοτροπιών από επιλογές</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/template_create.html?DbPAR=WRITER">Δημιουργία προτύπου εγγράφου</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/template_default.html?DbPAR=WRITER">Τροποποίηση προεπιλεγμένου πρότυπου εγγράφου</a></li>\
			</ul></li>\
    <li><a target="_top" href="el/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Αλλαγή προσανατολισμού σελίδας (Οριζόντια ή Κατακόρυφη)</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/text_capital.html?DbPAR=WRITER">Εναλλαγή πεζών / κεφαλαίων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Απόκρυψη κειμένου</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Καθορισμός διαφορετικών κεφαλίδων και υποσέλιδων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Εισαγωγή ονόματος και αρίθμησης κεφαλαίου σε κεφαλίδα ή υποσέλιδο</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Εφαρμογή μορφοποίησης κειμένου κατά την πληκτρολόγηση</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/reset_format.html?DbPAR=WRITER">Επαναφορά ιδιοτήτων γραμματοσειράς</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Εφαρμογή τεχνοτροπιών με τη λειτουργία μορφοποίησης γεμίσματος</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/wrap.html?DbPAR=WRITER">Αναδίπλωση κειμένου γύρω από αντικείμενα</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Χρήση πλαισίου για στοίχιση του κειμένου στο κέντρο της σελίδας</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Έμφαση σε κείμενο</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Περιστροφή κειμένου</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/page_break.html?DbPAR=WRITER">Εισαγωγή και διαγραφή αλλαγών σελίδας</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Δημιουργία και εφαρμογή τεχνοτροπιών σελίδας</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/subscript.html?DbPAR=WRITER">Μετατροπή κειμένου σε εκθέτη ή δείκτη</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Ειδικά στοιχεία κειμένου</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/captions.html?DbPAR=WRITER">Χρήση υπομνημάτων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Κείμενο υπό συνθήκες</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Κείμενο υπό συνθήκες για καταμέτρηση σελίδων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/fields_date.html?DbPAR=WRITER">Εισαγωγή πεδίου σταθερής ή μεταβλητής ημερομηνίας</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Προσθήκη πεδίων εισαγωγής</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Εισαγωγή αριθμών σελίδας για συνεχόμενες σελίδες</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Εισαγωγή αριθμών σελίδας σε υποσέλιδα</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Απόκρυψη κειμένου</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Καθορισμός διαφορετικών κεφαλίδων και υποσέλιδων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Εισαγωγή ονόματος και αρίθμησης κεφαλαίου σε κεφαλίδα ή υποσέλιδο</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Ερωτήματα δεδομένων χρήστη σε πεδία ή συνθήκες</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Εισαγωγή και επεξεργασία υποσημειώσεων και σημειώσεων τέλους</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Απόσταση μεταξύ υποσημειώσεων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/header_footer.html?DbPAR=WRITER">Περί κεφαλίδων και υποσέλιδων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Μορφοποίηση κεφαλίδων ή υποσέλιδων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/text_animation.html?DbPAR=WRITER">Κινούμενο κείμενο</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Δημιουργία εγκυκλίων επιστολών</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Αυτόματες λειτουργίες</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Προσθήκη εξαιρέσεων στη λίστα της Αυτόματης διόρθωσης</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/autotext.html?DbPAR=WRITER">Χρήση Αυτόματου ειμένου</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Δημιουργία αριθμημένων λιστών ή με κουκίδες κατά την πληκτρολόγηση</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/auto_off.html?DbPAR=WRITER">Απενεργοποίηση αυτόματης διόρθωσης</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Αυτόματος ορθογραφικός έλεγχος</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Ενεργοποίηση ή απενεργοποίηση της αναγνώρισης αριθμών σε πίνακες</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Συλλαβισμός</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Αρίθμηση και λίστες</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Προσθήκη αριθμών κεφαλαίων σε υπομνήματα</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Δημιουργία αριθμημένων λιστών ή με κουκίδες κατά την πληκτρολόγηση</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Αρίθμηση κεφαλαίων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Αλλαγή του επιπέδου κεφαλαίου σε λίστες με κουκκίδες και αρίθμηση</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Συνδυασμός αριθμημένων λιστών</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Προσθήκη αριθμών γραμμής</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Τροποποίηση αρίθμησης σε αριθμημένη λίστα</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Ορισμός περιοχών με αριθμούς</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Προσθήκη αρίθμησης</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Αρίθμηση και τεχνοτροπίες αρίθμησης</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Προσθήκη κουκίδων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Ορθογραφικός έλεγχος, θησαυρός και γλώσσες</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Αυτόματος ορθογραφικός έλεγχος</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Αφαίρεση λέξεων από λεξικό ορισμένο από το χρήστη</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Θησαυρός λέξεων</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Ορθογραφικός και γραμματικός έλεγχος</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Συμβουλές επίλυσης προβλημάτων</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Εισαγωγή κειμένου πριν από πίνακα στην αρχή της σελίδας</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Μετάβαση σε συγκεκριμένο σελιδοδείκτη</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Φόρτωση, αποθήκευση, εισαγωγή, εξαγωγή και απόκρυψη</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/send2html.html?DbPAR=WRITER">Αποθήκευση εγγράφων κειμένου σε μορφή HTML</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Εισαγωγή ολόκληρου εγγράφου κειμένου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/redaction.html?DbPAR=WRITER">Απόκρυψη</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Κύρια έγγραφα</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Κύρια και δευτερεύοντα έγγραφα</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Σύνδεσμοι και αναφορές</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/references.html?DbPAR=WRITER">Εισαγωγή παραπομπών</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Εισαγωγή υπερσυνδέσμων με τον περιηγητή</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Εκτύπωση</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Επιλογή τροφοδότη χαρτιού του εκτυπωτή</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/print_preview.html?DbPAR=WRITER">Προεπισκόπηση σελίδας πριν την εκτύπωση</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/print_small.html?DbPAR=WRITER">Εκτύπωση πολλαπλών σελίδων σε ένα φύλλο</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Δημιουργία και εφαρμογή τεχνοτροπιών σελίδας</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Αναζήτηση και αντικατάσταση</label><ul>\
    <li><a target="_top" href="el/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Χρήση κανονικών εκφράσεων σε αναζήτηση κειμένου</a></li>\
    <li><a target="_top" href="el/text/shared/01/02100001.html?DbPAR=WRITER">Κατάλογος κανονικών εκφράσεων</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">Έγγραφα HTML (Writer Web)</label><ul>\
    <li><a target="_top" href="el/text/shared/07/09000000.html?DbPAR=WRITER">Ιστοσελίδες</a></li>\
    <li><a target="_top" href="el/text/shared/02/01170700.html?DbPAR=WRITER">Φίλτρα HTML και Φόρμες</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/send2html.html?DbPAR=WRITER">Αποθήκευση εγγράφων κειμένου σε μορφή HTML</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Υπολογιστικά φύλλα (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Γενικές πληροφορίες και χρήση διεπαφής χρήστη</label><ul>\
    <li><a target="_top" href="el/text/scalc/main0000.html?DbPAR=CALC">Καλωσορίσατε στη Βοήθεια του LibreOffice Calc</a></li>\
    <li><a target="_top" href="el/text/scalc/main0503.html?DbPAR=CALC">Χαρακτηριστικά του LibreOffice Calc</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/keyboard.html?DbPAR=CALC">Πλήκτρα συντόμευσης (Προσιτότητα LibreOffice Calc)</a></li>\
    <li><a target="_top" href="el/text/scalc/04/01020000.html?DbPAR=CALC">Πλήκτρα συντόμευσης για υπολογιστικά φύλλα</a></li>\
    <li><a target="_top" href="el/text/scalc/05/02140000.html?DbPAR=CALC">Κωδικοί σφαλμάτων στο LibreOffice Calc</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060112.html?DbPAR=CALC">Πρόσθετο για προγραμματισμό στο LibreOffice Calc</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/main.html?DbPAR=CALC">Οδηγίες για τη χρήση του LibreOffice Calc</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Εντολές και μενού αναφοράς</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Μενού</label><ul>\
    <li><a target="_top" href="el/text/scalc/main0100.html?DbPAR=CALC">Μενού</a></li>\
    <li><a target="_top" href="el/text/scalc/main0101.html?DbPAR=CALC">Αρχείο</a></li>\
    <li><a target="_top" href="el/text/scalc/main0102.html?DbPAR=CALC">Επεξεργασία</a></li>\
    <li><a target="_top" href="el/text/scalc/main0103.html?DbPAR=CALC">Προβολή</a></li>\
    <li><a target="_top" href="el/text/scalc/main0104.html?DbPAR=CALC">Εισαγωγή</a></li>\
    <li><a target="_top" href="el/text/scalc/main0105.html?DbPAR=CALC">Μορφή</a></li>\
    <li><a target="_top" href="el/text/scalc/main0116.html?DbPAR=CALC">Φύλλο</a></li>\
    <li><a target="_top" href="el/text/scalc/main0112.html?DbPAR=CALC">Δεδομένα</a></li>\
    <li><a target="_top" href="el/text/scalc/main0106.html?DbPAR=CALC">Εργαλεία</a></li>\
    <li><a target="_top" href="el/text/scalc/main0107.html?DbPAR=CALC">Παράθυρο</a></li>\
    <li><a target="_top" href="el/text/shared/main0108.html?DbPAR=CALC">Βοήθεια</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Γραμμές εργαλείων</label><ul>\
    <li><a target="_top" href="el/text/scalc/main0200.html?DbPAR=CALC">Γραμμές εργαλείων</a></li>\
    <li><a target="_top" href="el/text/scalc/main0202.html?DbPAR=CALC">Γραμμή μορφοποίησης</a></li>\
    <li><a target="_top" href="el/text/scalc/main0203.html?DbPAR=CALC">Γραμμή ιδιοτήτων αντικειμένου σχεδίασης</a></li>\
    <li><a target="_top" href="el/text/scalc/main0205.html?DbPAR=CALC">Γραμμή μορφοποίησης κειμένου</a></li>\
    <li><a target="_top" href="el/text/scalc/main0206.html?DbPAR=CALC">Γραμμή μαθηματικών τύπων</a></li>\
    <li><a target="_top" href="el/text/scalc/main0208.html?DbPAR=CALC">Γραμμή κατάστασης</a></li>\
    <li><a target="_top" href="el/text/scalc/main0210.html?DbPAR=CALC">Γραμμή προεπισκόπησης εκτύπωσης</a></li>\
    <li><a target="_top" href="el/text/scalc/main0214.html?DbPAR=CALC">Εργαλειοθήκη εικόνας</a></li>\
    <li><a target="_top" href="el/text/scalc/main0218.html?DbPAR=CALC">Γραμμή εργαλείων</a></li>\
    <li><a target="_top" href="el/text/shared/main0201.html?DbPAR=CALC">Βασική γραμμή εργαλείων</a></li>\
    <li><a target="_top" href="el/text/shared/main0212.html?DbPAR=CALC">Γραμμή δεδομένων πίνακα</a></li>\
    <li><a target="_top" href="el/text/shared/main0213.html?DbPAR=CALC">Γραμμή πλοήγησης φόρμας</a></li>\
    <li><a target="_top" href="el/text/shared/main0214.html?DbPAR=CALC">Γραμμή σχεδίασης ερωτημάτων</a></li>\
    <li><a target="_top" href="el/text/shared/main0226.html?DbPAR=CALC">Γραμμή εργαλείων σχεδιασμού φόρμας</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Τύποι συναρτήσεων και τελεστές</label><ul>\
    <li><a target="_top" href="el/text/scalc/01/04060000.html?DbPAR=CALC">Οδηγός συναρτήσεων</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060100.html?DbPAR=CALC">Συναρτήσεις ανά κατηγορία</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060107.html?DbPAR=CALC">Συναρτήσεις πίνακα</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060120.html?DbPAR=CALC">Συναρτήσεις λειτουργίας δυαδικών ψηφίων</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060101.html?DbPAR=CALC">Συναρτήσεις βάσεων δεδομένων</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060102.html?DbPAR=CALC">Συναρτήσεις ημερομηνίας και ώρας</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060103.html?DbPAR=CALC">Οικονομικές συναρτήσεις - Μέρος πρώτο</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060119.html?DbPAR=CALC">Οικονομικές συναρτήσεις - Μέρος δεύτερο</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060118.html?DbPAR=CALC">Οικονομικές συναρτήσεις - Μέρος τρίτο</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060104.html?DbPAR=CALC">Πληροφοριακές συναρτήσεις</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060105.html?DbPAR=CALC">Λογικές συναρτήσεις</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060106.html?DbPAR=CALC">Μαθηματικές συναρτήσεις</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060108.html?DbPAR=CALC">Στατιστικές συναρτήσεις</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060181.html?DbPAR=CALC">Στατιστικές συναρτήσεις - Μέρος πρώτο</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060182.html?DbPAR=CALC">Στατιστικές συναρτήσεις - Μέρος δεύτερο</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060183.html?DbPAR=CALC">Στατιστικές συναρτήσεις - Μέρος τρίτο</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060184.html?DbPAR=CALC">Στατιστικές συναρτήσεις - Μέρος τέταρτο</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060185.html?DbPAR=CALC">Στατιστικές συναρτήσεις - Μέρος πέμπτο</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060109.html?DbPAR=CALC">Συναρτήσεις υπολογιστικών φύλλων</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060110.html?DbPAR=CALC">Συναρτήσεις κειμένου</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060111.html?DbPAR=CALC">Πρόσθετες συναρτήσεις</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060115.html?DbPAR=CALC">Πρόσθετες συναρτήσεις, Κατάλογος συναρτήσεων ανάλυσης μέρος πρώτο</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060116.html?DbPAR=CALC">Πρόσθετες συναρτήσεις, κατάλογος συναρτήσεων ανάλυσης - Μέρος δεύτερο</a></li>\
    <li><a target="_top" href="el/text/scalc/01/04060199.html?DbPAR=CALC">Τελεστές στο LibreOffice Calc</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Συναρτήσεις οριζόμενες από το χρήστη</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Φόρτωση, αποθήκευση, εισαγωγή, εξαγωγή και απόκρυψη</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/webquery.html?DbPAR=CALC">Εισαγωγή εξωτερικών δεδομένων σε πίνακα (ΕρώτημαΙστού)</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/html_doc.html?DbPAR=CALC">Αποθήκευση και άνοιγμα φύλλων σε μορφή HTML</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/csv_formula.html?DbPAR=CALC">Εισαγωγή και εξαγωγή αρχείων κειμένου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/redaction.html?DbPAR=CALC">Απόκρυψη</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Μορφοποίηση</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/text_rotate.html?DbPAR=CALC">Περιστροφή κειμένου</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/text_wrap.html?DbPAR=CALC">Εγγραφή κειμένου πολλαπλών γραμμών</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/text_numbers.html?DbPAR=CALC">Μορφοποίηση αριθμών ως κείμενο</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/super_subscript.html?DbPAR=CALC">Κείμενο ως εκθέτης / δείκτης.</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/row_height.html?DbPAR=CALC">Αλλαγή ύψους γραμμής ή πλάτους στήλης</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Εφαρμογή μορφοποίησης υπό ορούς</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Επισήμανση αρνητικών αριθμών</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Ανάθεση μορφοποίησης με τύπο</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Εισαγωγή αριθμού με αρχικά μηδενικά</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/format_table.html?DbPAR=CALC">Μορφοποίηση υπολογιστικών φύλλων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/format_value.html?DbPAR=CALC">Μορφοποίηση αριθμών με δεκαδικούς</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/value_with_name.html?DbPAR=CALC">Ονομασία κελιών</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/table_rotate.html?DbPAR=CALC">Περιστροφή πινάκων (αντιμετάθεση)</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/rename_table.html?DbPAR=CALC">Μετονομασία φύλλων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/year2000.html?DbPAR=CALC">Έτη 19xx/20xx</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Χρήση στρογγυλοποιημένων αριθμών</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/currency_format.html?DbPAR=CALC">Κελιά σε νομισματική μορφή</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/autoformat.html?DbPAR=CALC">Χρήση αυτόματης μορφοποίησης σε πίνακες</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/note_insert.html?DbPAR=CALC">Εισαγωγή και επεξεργασία σημειώσεων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/design.html?DbPAR=CALC">Επιλογή θεμάτων για υπολογιστικά φύλλα</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Εισαγωγή κλασμάτων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Φιλτράρισμα και ταξινόμηση</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/filters.html?DbPAR=CALC">Εφαρμογή φίλτρων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/specialfilter.html?DbPAR=CALC">Φίλτρο: Εφαρμογή ειδικού φίλτρου</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/autofilter.html?DbPAR=CALC">Εφαρμογή αυτόματου φίλτρου</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/sorted_list.html?DbPAR=CALC">Εφαρμογή λιστών ταξινόμησης</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Εκτύπωση</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/print_title_row.html?DbPAR=CALC">Εκτύπωση γραμμών ή στηλών σε κάθε σελίδα</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/print_landscape.html?DbPAR=CALC">Εκτύπωση φύλλων σε οριζόντια μορφή</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/print_details.html?DbPAR=CALC">Εκτύπωση λεπτομερειών φύλλου</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/print_exact.html?DbPAR=CALC">Καθορισμός αριθμού σελίδων για εκτύπωση</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Περιοχές δεδομένων</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/database_define.html?DbPAR=CALC">Καθορισμός περιοχών βάσης δεδομένων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/database_filter.html?DbPAR=CALC">Φιλτράρισμα περιοχών κελιών</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/database_sort.html?DbPAR=CALC">Ταξινόμηση περιοχών βάσης δεδομένων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Συγκεντρωτικός πίνακας</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/datapilot.html?DbPAR=CALC">Συγκεντρωτικός πίνακας</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Δημιουργία συγκεντρωτικών πινάκων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Διαγραφή συγκεντρωτικών πινάκων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Επεξεργασία συγκεντρωτικών πινάκων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Φιλτράρισμα συγκεντρωτικών πινάκων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Επιλογή περιοχών εξόδου συγκεντρωτικού πίνακα</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Ενημέρωση συγκεντρωτικών πινάκων</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Συγκεντρωτικό γράφημα</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/pivotchart.html?DbPAR=CALC">Συγκεντρωτικό γράφημα</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Δημιουργία συγκεντρωτικών γραφημάτων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Επεξεργασία συγκεντρωτικών γραφημάτων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Φιλτράρισμα συγκεντρωτικών γραφημάτων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Ενημέρωση συγκεντρωτικού γραφήματος</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Διαγραφή συγκεντρωτικών γραφημάτων</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Σενάρια</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/scenario.html?DbPAR=CALC">Χρήση σεναρίων</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Μερικά αθροίσματα</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Χρήση εργαλείου μερικών αθροισμάτων</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Παραπομπές</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Ονομασίες και παραπομπές, απόλυτες και σχετικές</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/cellreferences.html?DbPAR=CALC">Παραπομπή κελιού σε άλλο έγγραφο</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Παραπομπές σε άλλα φύλλα και παραπομπή σε URL</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Παραπομπή κελιών με μεταφορά και απόθεση</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/address_auto.html?DbPAR=CALC">Αναγνώριση ονομάτων ως εκχωρήσεις διευθύνσεων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Προβολή, επιλογή, αντιγραφή</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/table_view.html?DbPAR=CALC">Αλλαγή προβολών πίνακα</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/formula_value.html?DbPAR=CALC">Εμφάνιση τύπων ή τιμών</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/line_fix.html?DbPAR=CALC">Παγίωση γραμμών ή στηλών ως κεφαλίδων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/multi_tables.html?DbPAR=CALC">Εμφάνιση πολλαπλών φύλλων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Αντιγραφή σε πολλαπλά φύλλα</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/cellcopy.html?DbPAR=CALC">Αντιγραφή μόνο ορατών κελιών</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/mark_cells.html?DbPAR=CALC">Επιλογή πολλαπλών κελιών</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Τύποι και υπολογισμοί</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/formulas.html?DbPAR=CALC">Υπολογισμός με τύπους</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/formula_copy.html?DbPAR=CALC">Αντιγραφή τύπων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/formula_enter.html?DbPAR=CALC">Εισαγωγή τύπων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/formula_value.html?DbPAR=CALC">Εμφάνιση τύπων ή τιμών</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/calculate.html?DbPAR=CALC">Υπολογισμοί σε υπολογιστικά φύλλα</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/calc_date.html?DbPAR=CALC">Υπολογισμός με ημερομηνίες και ώρες</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/calc_series.html?DbPAR=CALC">Αυτόματος υπολογισμός γραμμών</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Υπολογισμός διαφορών ώρας</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/matrixformula.html?DbPAR=CALC">Εισαγωγή τύπων πλεγμάτων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Προστασία</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/cell_protect.html?DbPAR=CALC">Προστασία κελιών από τροποποιήσεις</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Κατάργηση προστασίας κελιών</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Διάφορα</label><ul>\
    <li><a target="_top" href="el/text/scalc/guide/auto_off.html?DbPAR=CALC">Απενεργοποίηση αυτόματων αλλαγών</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/consolidate.html?DbPAR=CALC">Ενοποίηση δεδομένων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/goalseek.html?DbPAR=CALC">Εφαρμογή αναζήτησης τιμής στόχου</a></li>\
    <li><a target="_top" href="el/text/scalc/01/solver.html?DbPAR=CALC">Επίλυση</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/multioperation.html?DbPAR=CALC">Εφαρμογή πολλαπλών πράξεων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/multitables.html?DbPAR=CALC">Εφαρμογή πολλαπλών φύλλων</a></li>\
    <li><a target="_top" href="el/text/scalc/guide/validity.html?DbPAR=CALC">Εγκυρότητα των περιεχομένων των κελιών</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Παρουσιάσεις (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Γενικές πληροφορίες και χρήση διεπαφής χρήστη</label><ul>\
    <li><a target="_top" href="el/text/simpress/main0000.html?DbPAR=IMPRESS">Καλωσορίσατε στη Βοήθεια του LibreOffice Impress</a></li>\
    <li><a target="_top" href="el/text/simpress/main0503.html?DbPAR=IMPRESS">Χαρακτηριστικά του LibreOffice Impress</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Χρήση πλήκτρων συντόμευσης στο LibreOffice Impress</a></li>\
    <li><a target="_top" href="el/text/simpress/04/01020000.html?DbPAR=IMPRESS">Πλήκτρα συντόμευσης για το LibreOffice Impress</a></li>\
    <li><a target="_top" href="el/text/simpress/04/presenter.html?DbPAR=IMPRESS">Συντομεύσεις πληκτρολογίου κονσόλας παρουσιαστή</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/main.html?DbPAR=IMPRESS">Οδηγίες για τη χρήση του LibreOffice Impress</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Εντολές και μενού αναφοράς</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Μενού</label><ul>\
    <li><a target="_top" href="el/text/simpress/main0100.html?DbPAR=IMPRESS">Μενού</a></li>\
    <li><a target="_top" href="el/text/simpress/main0101.html?DbPAR=IMPRESS">Αρχείο</a></li>\
    <li><a target="_top" href="el/text/simpress/main_edit.html?DbPAR=IMPRESS">Επεξεργασία</a></li>\
    <li><a target="_top" href="el/text/simpress/main0103.html?DbPAR=IMPRESS">Προβολή</a></li>\
    <li><a target="_top" href="el/text/simpress/main0104.html?DbPAR=IMPRESS">Εισαγωγή</a></li>\
    <li><a target="_top" href="el/text/simpress/main_format.html?DbPAR=IMPRESS">Μορφή</a></li>\
    <li><a target="_top" href="el/text/simpress/main_slide.html?DbPAR=IMPRESS">Διαφάνεια</a></li>\
    <li><a target="_top" href="el/text/simpress/main0114.html?DbPAR=IMPRESS">Παρουσίαση διαφανειών</a></li>\
    <li><a target="_top" href="el/text/simpress/main_tools.html?DbPAR=IMPRESS">Εργαλεία</a></li>\
    <li><a target="_top" href="el/text/simpress/main0107.html?DbPAR=IMPRESS">Παράθυρο</a></li>\
    <li><a target="_top" href="el/text/shared/main0108.html?DbPAR=IMPRESS">Βοήθεια</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Γραμμές εργαλείων</label><ul>\
    <li><a target="_top" href="el/text/simpress/main0200.html?DbPAR=IMPRESS">Γραμμές εργαλείων</a></li>\
    <li><a target="_top" href="el/text/simpress/main0202.html?DbPAR=IMPRESS">Γραμμή εργαλείων γραμμής και γεμίσματος</a></li>\
    <li><a target="_top" href="el/text/simpress/main0203.html?DbPAR=IMPRESS">Γραμμή μορφοποίησης κειμένου</a></li>\
    <li><a target="_top" href="el/text/simpress/main0204.html?DbPAR=IMPRESS">Γραμμή προβολής διαφανειών</a></li>\
    <li><a target="_top" href="el/text/simpress/main0206.html?DbPAR=IMPRESS">Γραμμή κατάστασης</a></li>\
    <li><a target="_top" href="el/text/simpress/main0209.html?DbPAR=IMPRESS">Χάρακες</a></li>\
    <li><a target="_top" href="el/text/simpress/main0210.html?DbPAR=IMPRESS">Γραμμή σχεδίασης</a></li>\
    <li><a target="_top" href="el/text/simpress/main0211.html?DbPAR=IMPRESS">Γραμμή διάρθρωσης</a></li>\
    <li><a target="_top" href="el/text/simpress/main0212.html?DbPAR=IMPRESS">Γραμμή ταξινόμησης διαφανειών</a></li>\
    <li><a target="_top" href="el/text/simpress/main0213.html?DbPAR=IMPRESS">Γραμμή επιλογών</a></li>\
    <li><a target="_top" href="el/text/simpress/main0214.html?DbPAR=IMPRESS">Εργαλειοθήκη εικόνας</a></li>\
    <li><a target="_top" href="el/text/shared/main0201.html?DbPAR=IMPRESS">Βασική γραμμή εργαλείων</a></li>\
    <li><a target="_top" href="el/text/shared/main0213.html?DbPAR=IMPRESS">Γραμμή πλοήγησης φόρμας</a></li>\
    <li><a target="_top" href="el/text/shared/main0226.html?DbPAR=IMPRESS">Γραμμή εργαλείων σχεδιασμού φόρμας</a></li>\
    <li><a target="_top" href="el/text/shared/main0227.html?DbPAR=IMPRESS">Γραμμή επεξεργασίας σημείων</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Φόρτωση, αποθήκευση, εισαγωγή, εξαγωγή και απόκρυψη</label><ul>\
    <li><a target="_top" href="el/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Αποθήκευση παρουσίασης σε μορφή HTML</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Εισαγωγή σελίδων HTML σε παρουσιάσεις</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Φόρτωση καταλόγων χρώματος, διαβάθμισης, και γραμμοσκίασης</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Εξαγωγή κινούμενων αντικειμένων σε μορφή GIF</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Σύναψη υπολογιστικών φύλλων σε διαφάνειες</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Εισαγωγή γραφικών</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Αντιγραφή διαφανειών από άλλες παρουσιάσεις</a></li>\
    <li><a target="_top" href="el/text/shared/guide/redaction.html?DbPAR=IMPRESS">Απόκρυψη</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Μορφοποίηση</label><ul>\
    <li><a target="_top" href="el/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Φόρτωση καταλόγων χρώματος, διαβάθμισης, και γραμμοσκίασης</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Φόρτωση τεχνοτροπιών γραμμών και βελών</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Ορισμός προσαρμοσμένων χρωμάτων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Δημιουργία γεμισμάτων με διαβαθμίσεις χρωμάτων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Αντικατάσταση χρωμάτων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Τακτοποίηση, στοίχιση και κατανομή αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/background.html?DbPAR=IMPRESS">Αλλαγή του γεμίσματος του παρασκηνίου διαφάνειας</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/footer.html?DbPAR=IMPRESS">Προσθήκη κεφαλίδας ή υποσέλιδου σε όλες τις διαφάνειες</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Αλλαγή και προσθήκη κύριας σελίδας</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Μετακίνηση αντικειμένων</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Εκτύπωση</label><ul>\
    <li><a target="_top" href="el/text/simpress/guide/printing.html?DbPAR=IMPRESS">Εκτύπωση παρουσιάσεων</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Εκτύπωση διαφάνειας με προσαρμογή στο μέγεθος του χαρτιού</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Εφέ</label><ul>\
    <li><a target="_top" href="el/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Εξαγωγή κινούμενων αντικειμένων σε μορφή GIF</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Δημιουργία κινούμενων αντικειμένων σε διαφάνειες παρουσίασης</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Δημιουργία κινούμενων εναλλαγών σε διαφάνειες</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Βαθμιαίος αποχρωματισμός δύο αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Δημιουργία κινούμενων εικόνων GIF</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Αντικείμενα, γραφικά και ψηφιογραφίες</label><ul>\
    <li><a target="_top" href="el/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Συνδυασμός αντικειμένων και κατασκευή σχημάτων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Ομαδοποίηση αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Σχεδιασμός τομέων και τμημάτων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Δημιουργία διπλότυπων αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Περιστροφή αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Συναρμολόγηση αντικειμένων 3Δ</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Σύνδεση γραμμών</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Μετατροπή χαρακτήρων κειμένου σε αντικείμενα σχεδίασης</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Μετατροπή εικόνων bitmap σε διανυσματικά γραφικά</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Μετατροπή 2Δ αντικειμένων σε καμπύλες, πολύγωνα και 3Δ αντικείμενα</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Φόρτωση τεχνοτροπιών γραμμών και βελών</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Σχεδίαση καμπυλών</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Επεξεργασία καμπυλών</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Εισαγωγή γραφικών</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Σύναψη υπολογιστικών φύλλων σε διαφάνειες</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Μετακίνηση αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Επιλογή καλυπτόμενων αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Δημιουργία διαγράμματος ροής</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Κείμενο στις παρουσιάσεις</label><ul>\
    <li><a target="_top" href="el/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Προσθήκη κειμένου</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Μετατροπή χαρακτήρων κειμένου σε αντικείμενα σχεδίασης</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Προβολή</label><ul>\
    <li><a target="_top" href="el/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Τροποποίηση της ταξινόμησης διαφανειών</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Μεγέθυνση με το πληκτρολόγιο</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Προβολή διαφανειών</label><ul>\
    <li><a target="_top" href="el/text/simpress/guide/show.html?DbPAR=IMPRESS">Προβολή παρουσίασης οθόνης</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Χρήση της κονσόλας παρουσιαστή</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Οδηγός απομακρυσμένου Impress (Impress Remote)</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/individual.html?DbPAR=IMPRESS">Δημιουργία προσαρμοσμένης παρουσίασης οθόνης</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Δοκιμαστικοί συγχρονισμοί για τις εναλλαγές διαφάνειας</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Σχέδια (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Γενικές πληροφορίες και χρήση διεπαφής χρήστη</label><ul>\
    <li><a target="_top" href="el/text/sdraw/main0000.html?DbPAR=DRAW">Καλωσορίσατε στη Βοήθεια του LibreOffice Draw</a></li>\
    <li><a target="_top" href="el/text/sdraw/main0503.html?DbPAR=DRAW">Χαρακτηριστικά του LibreOffice Draw</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Πλήκτρα συντόμευσης για αντικείμενα σχεδίασης</a></li>\
    <li><a target="_top" href="el/text/sdraw/04/01020000.html?DbPAR=DRAW">Πλήκτρα συντόμευσης για την σχεδίαση</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/main.html?DbPAR=DRAW">Οδηγίες για τη χρήση του LibreOffice Draw</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Παραπομπές εντολών και μενού</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Μενού</label><ul>\
    <li><a target="_top" href="el/text/sdraw/main0100.html?DbPAR=DRAW">Μενού</a></li>\
    <li><a target="_top" href="el/text/sdraw/main0101.html?DbPAR=DRAW">Αρχείο</a></li>\
    <li><a target="_top" href="el/text/sdraw/main_edit.html?DbPAR=DRAW">Επεξεργασία</a></li>\
    <li><a target="_top" href="el/text/sdraw/main0103.html?DbPAR=DRAW">Προβολή</a></li>\
    <li><a target="_top" href="el/text/sdraw/main_insert.html?DbPAR=DRAW">Εισαγωγή</a></li>\
    <li><a target="_top" href="el/text/sdraw/main_format.html?DbPAR=DRAW">Μορφή</a></li>\
    <li><a target="_top" href="el/text/sdraw/main_page.html?DbPAR=DRAW">Σελίδα</a></li>\
    <li><a target="_top" href="el/text/sdraw/main_shape.html?DbPAR=DRAW">Σχήμα</a></li>\
    <li><a target="_top" href="el/text/sdraw/main_tools.html?DbPAR=DRAW">Εργαλεία</a></li>\
    <li><a target="_top" href="el/text/simpress/main0107.html?DbPAR=DRAW">Παράθυρο</a></li>\
    <li><a target="_top" href="el/text/shared/main0108.html?DbPAR=DRAW">Βοήθεια</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Γραμμές εργαλείων</label><ul>\
    <li><a target="_top" href="el/text/sdraw/main0200.html?DbPAR=DRAW">Γραμμές εργαλείων</a></li>\
    <li><a target="_top" href="el/text/sdraw/main0210.html?DbPAR=DRAW">Γραμμή σχεδίασης</a></li>\
    <li><a target="_top" href="el/text/sdraw/main0213.html?DbPAR=DRAW">Γραμμή επιλογών</a></li>\
    <li><a target="_top" href="el/text/shared/main0201.html?DbPAR=DRAW">Βασική γραμμή εργαλείων</a></li>\
    <li><a target="_top" href="el/text/shared/main0213.html?DbPAR=DRAW">Γραμμή πλοήγησης φόρμας</a></li>\
    <li><a target="_top" href="el/text/shared/main0226.html?DbPAR=DRAW">Γραμμή εργαλείων σχεδιασμού φόρμας</a></li>\
    <li><a target="_top" href="el/text/shared/main0227.html?DbPAR=DRAW">Γραμμή επεξεργασίας σημείων</a></li>\
    <li><a target="_top" href="el/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">Ρυθμίσεις 3Δ</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Φόρτωση, αποθήκευση, εισαγωγή και εξαγωγή</label><ul>\
    <li><a target="_top" href="el/text/simpress/guide/palette_files.html?DbPAR=DRAW">Φόρτωση καταλόγων χρώματος, διαβάθμισης, και γραμμοσκίασης</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Εισαγωγή γραφικών</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Μορφοποίηση</label><ul>\
    <li><a target="_top" href="el/text/simpress/guide/palette_files.html?DbPAR=DRAW">Φόρτωση καταλόγων χρώματος, διαβάθμισης, και γραμμοσκίασης</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Φόρτωση τεχνοτροπιών γραμμών και βελών</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/color_define.html?DbPAR=DRAW">Ορισμός προσαρμοσμένων χρωμάτων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/gradient.html?DbPAR=DRAW">Δημιουργία γεμισμάτων με διαβαθμίσεις χρωμάτων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Αντικατάσταση χρωμάτων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Τακτοποίηση, στοίχιση και κατανομή αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/background.html?DbPAR=DRAW">Αλλαγή του γεμίσματος του παρασκηνίου διαφάνειας</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/masterpage.html?DbPAR=DRAW">Αλλαγή και προσθήκη κύριας σελίδας</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/move_object.html?DbPAR=DRAW">Μετακίνηση αντικειμένων</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Εκτύπωση</label><ul>\
    <li><a target="_top" href="el/text/simpress/guide/printing.html?DbPAR=DRAW">Εκτύπωση παρουσιάσεων</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Εκτύπωση διαφάνειας με προσαρμογή στο μέγεθος του χαρτιού</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Εφέ</label><ul>\
    <li><a target="_top" href="el/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Βαθμιαίος αποχρωματισμός δύο αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/shared/01/05350000.html?DbPAR=DRAW">Εφέ 3Δ</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Αντικείμενα, γραφικά και ψηφιογραφίες</label><ul>\
    <li><a target="_top" href="el/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Συνδυασμός αντικειμένων και κατασκευή σχημάτων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Σχεδιασμός τομέων και τμημάτων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Δημιουργία διπλότυπων αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Περιστροφή αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Συναρμολόγηση αντικειμένων 3Δ</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Σύνδεση γραμμών</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/text2curve.html?DbPAR=DRAW">Μετατροπή χαρακτήρων κειμένου σε αντικείμενα σχεδίασης</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/vectorize.html?DbPAR=DRAW">Μετατροπή εικόνων bitmap σε διανυσματικά γραφικά</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/3d_create.html?DbPAR=DRAW">Μετατροπή 2Δ αντικειμένων σε καμπύλες, πολύγωνα και 3Δ αντικείμενα</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Φόρτωση τεχνοτροπιών γραμμών και βελών</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/line_draw.html?DbPAR=DRAW">Σχεδίαση καμπυλών</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/line_edit.html?DbPAR=DRAW">Επεξεργασία καμπυλών</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Εισαγωγή γραφικών</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/table_insert.html?DbPAR=DRAW">Σύναψη υπολογιστικών φύλλων σε διαφάνειες</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/move_object.html?DbPAR=DRAW">Μετακίνηση αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/select_object.html?DbPAR=DRAW">Επιλογή καλυπτόμενων αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/orgchart.html?DbPAR=DRAW">Δημιουργία διαγράμματος ροής</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Ομάδες και στρώσεις</label><ul>\
    <li><a target="_top" href="el/text/sdraw/guide/groups.html?DbPAR=DRAW">Ομαδοποίηση αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/layers.html?DbPAR=DRAW">Περί στρώσεων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Εισαγωγή στρώσεων</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Εργασία με στρώσεις</a></li>\
    <li><a target="_top" href="el/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Μετακίνηση αντικειμένων σε διαφορετική στρώση</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Κείμενο στα σχέδια</label><ul>\
    <li><a target="_top" href="el/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Προσθήκη κειμένου</a></li>\
    <li><a target="_top" href="el/text/simpress/guide/text2curve.html?DbPAR=DRAW">Μετατροπή χαρακτήρων κειμένου σε αντικείμενα σχεδίασης</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Προβολή</label><ul>\
    <li><a target="_top" href="el/text/simpress/guide/change_scale.html?DbPAR=DRAW">Μεγέθυνση με το πληκτρολόγιο</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Λειτουργικότητα βάσης δεδομένων (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Γενικές Πληροφορίες</label><ul>\
    <li><a target="_top" href="el/text/sdatabase/main.html?DbPAR=BASE">Βάση δεδομένων του LibreOffice</a></li>\
    <li><a target="_top" href="el/text/shared/guide/database_main.html?DbPAR=BASE">Σύνοψη βάσης δεδομένων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_new.html?DbPAR=BASE">Δημιουργία μιας νέας βάση δεδομένων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_tables.html?DbPAR=BASE">Εργασία με πίνακες</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_queries.html?DbPAR=BASE">Εργασία με ερωτήματα</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_forms.html?DbPAR=BASE">Εργασία με φόρμες</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_reports.html?DbPAR=BASE">Δημιουργία αναφορών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_register.html?DbPAR=BASE">Δήλωση και διαγραφή μιας βάσης δεδομένων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_im_export.html?DbPAR=BASE">Εισαγωγή και εξαγωγή δεδομένων στο Base</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_enter_sql.html?DbPAR=BASE">Εκτέλεση εντολών SQL</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Τύποι (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Γενικές πληροφορίες και χρήση διεπαφής χρήστη</label><ul>\
    <li><a target="_top" href="el/text/smath/main0000.html?DbPAR=MATH">Καλωσορίσατε στη Βοήθεια για το LibreOffice Math</a></li>\
    <li><a target="_top" href="el/text/smath/main0503.html?DbPAR=MATH">Χαρακτηριστικά του LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">Στοιχεία τύπου του LibreOffice</label><ul>\
    <li><a target="_top" href="el/text/smath/01/03090100.html?DbPAR=MATH">Μοναδιαίοι/Δυαδικοί τελεστές</a></li>\
    <li><a target="_top" href="el/text/smath/01/03090200.html?DbPAR=MATH">Σχέσεις</a></li>\
    <li><a target="_top" href="el/text/smath/01/03090800.html?DbPAR=MATH">Πράξεις συνόλων</a></li>\
    <li><a target="_top" href="el/text/smath/01/03090400.html?DbPAR=MATH">Συναρτήσεις</a></li>\
    <li><a target="_top" href="el/text/smath/01/03090300.html?DbPAR=MATH">Τελεστές</a></li>\
    <li><a target="_top" href="el/text/smath/01/03090600.html?DbPAR=MATH">Γνωρίσματα</a></li>\
    <li><a target="_top" href="el/text/smath/01/03090500.html?DbPAR=MATH">Αγκύλες</a></li>\
    <li><a target="_top" href="el/text/smath/01/03090700.html?DbPAR=MATH">Μορφοποίηση</a></li>\
    <li><a target="_top" href="el/text/smath/01/03091600.html?DbPAR=MATH">Άλλα σύμβολα</a></li>\
            </ul></li>\
    <li><a target="_top" href="el/text/smath/guide/main.html?DbPAR=MATH">Οδηγίες για τη χρήση του LibreOffice Math</a></li>\
    <li><a target="_top" href="el/text/smath/guide/keyboard.html?DbPAR=MATH">Συντομεύσεις Προσιτότητας (LibreOffice Math)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Εντολές και μενού αναφοράς</label><ul>\
    <li><a target="_top" href="el/text/smath/main0100.html?DbPAR=MATH">Μενού</a></li>\
    <li><a target="_top" href="el/text/smath/main0200.html?DbPAR=MATH">Γραμμές εργαλείων</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Εργασία με τύπους</label><ul>\
    <li><a target="_top" href="el/text/smath/guide/align.html?DbPAR=MATH">Μη αυτόματη στοίχιση των τμημάτων τύπου</a></li>\
    <li><a target="_top" href="el/text/smath/guide/attributes.html?DbPAR=MATH">Αλλαγή των προεπιλεγμένων γνωρισμάτων</a></li>\
    <li><a target="_top" href="el/text/smath/guide/brackets.html?DbPAR=MATH">Συγχώνευση τμημάτων τύπου σε παρενθέσεις</a></li>\
    <li><a target="_top" href="el/text/smath/guide/comment.html?DbPAR=MATH">Εισαγωγή σχολίων</a></li>\
    <li><a target="_top" href="el/text/smath/guide/newline.html?DbPAR=MATH">Εισαγωγή αλλαγών γραμμής</a></li>\
    <li><a target="_top" href="el/text/smath/guide/parentheses.html?DbPAR=MATH">Εισαγωγή παρενθέσεων</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Χάρτες και διαγράμματα</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Γενικές Πληροφορίες</label><ul>\
    <li><a target="_top" href="el/text/schart/main0000.html?DbPAR=CHART">Διαγράμματα στο LibreOffice</a></li>\
    <li><a target="_top" href="el/text/schart/main0503.html?DbPAR=CHART">Χαρακτηριστικά LibreOffice Chart</a></li>\
    <li><a target="_top" href="el/text/schart/04/01020000.html?DbPAR=CHART">Συντομεύσεις για διαγράμματα</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Μακροεντολές και δέσμη ενεργειών</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Γενικές πληροφορίες και χρήση διεπαφής χρήστη</label><ul>\
    <li><a target="_top" href="el/text/sbasic/shared/main0601.html?DbPAR=BASIC">Βοήθεια για την LibreOffice Basic</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01000000.html?DbPAR=BASIC">Προγραμματισμός με την LibreOffice Basic</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/00000002.html?DbPAR=BASIC">Γλωσσάρι της LibreOffice Basic</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01010210.html?DbPAR=BASIC">Βασικές αρχές</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01020000.html?DbPAR=BASIC">Σύνταξη</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01030100.html?DbPAR=BASIC">Επισκόπηση IDE</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01030200.html?DbPAR=BASIC">Ο επεξεργαστής της Basic</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01050100.html?DbPAR=BASIC">Παράθυρο Παρατηρητή</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/main0211.html?DbPAR=BASIC">Γραμμή εργαλείων μακροεντολών</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/05060700.html?DbPAR=BASIC">Μακροεντολή</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Υποστήριξη για μακροεντολές VBA</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Αναφορά εντολών</label><ul>\
    <li><a target="_top" href="el/text/sbasic/shared/01020300.html?DbPAR=BASIC">Χρήση διαδικασιών, συναρτήσεων ή ιδιοτήτων</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01020500.html?DbPAR=BASIC">Βιβλιοθήκες, αρθρώματα και παράθυρα διαλόγων</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Συναρτήσεις, προτάσεις και τελεστές</label><ul>\
    <li><a target="_top" href="el/text/sbasic/shared/03010000.html?DbPAR=BASIC">Συναρτήσεις εισόδου/εξόδου οθόνης</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020000.html?DbPAR=BASIC">Συναρτήσεις εισαγωγής/εξαγωγής αρχείων</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030000.html?DbPAR=BASIC">Συναρτήσεις ημερομηνίας και ώρας</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03050000.html?DbPAR=BASIC">Συναρτήσεις χειρισμού σφαλμάτων</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03060000.html?DbPAR=BASIC">Λογικοί τελεστές</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03070000.html?DbPAR=BASIC">Μαθηματικοί τελεστές</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080000.html?DbPAR=BASIC">Αριθμητικές συναρτήσεις</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090000.html?DbPAR=BASIC">Έλεγχος εκτέλεσης προγράμματος</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100000.html?DbPAR=BASIC">Μεταβλητές</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03040000.html?DbPAR=BASIC">Σταθερές Basic</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03110000.html?DbPAR=BASIC">Τελεστές σύγκρισης</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120000.html?DbPAR=BASIC">Συμβολοσειρές</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Κλήση συναρτήσεων Calc σε μακροεντολές</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Συναρτήσεις αποκλεισμού VBA</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03130000.html?DbPAR=BASIC">Άλλες εντολές</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Αλφαβητική λίστα συναρτήσεων, δηλώσεων και τελεστών</label><ul>\
    <li><a target="_top" href="el/text/sbasic/shared/03080601.html?DbPAR=BASIC">Συνάρτηση Abs</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03060100.html?DbPAR=BASIC">Τελεστής AND</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03104200.html?DbPAR=BASIC">Συνάρτηση Array</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120101.html?DbPAR=BASIC">Συνάρτηση Asc</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120111.html?DbPAR=BASIC">Συνάρτηση AscW</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080101.html?DbPAR=BASIC">Συνάρτηση Atn</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03130100.html?DbPAR=BASIC">Πρόταση Beep</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03010301.html?DbPAR=BASIC">Συνάρτηση Blue</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090102.html?DbPAR=BASIC">Πρόταση Select...Case</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100100.html?DbPAR=BASIC">Συνάρτηση CBool</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120105.html?DbPAR=BASIC">Συνάρτηση CByte</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100050.html?DbPAR=BASIC">Συνάρτηση CCur</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030116.html?DbPAR=BASIC">Συνάρτηση CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030115.html?DbPAR=BASIC">Συνάρτηση CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030114.html?DbPAR=BASIC">Συνάρτηση CDateFromUnoTime</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030113.html?DbPAR=BASIC">Συνάρτηση CDateToUnoTime</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030112.html?DbPAR=BASIC">Συνάρτηση CDateFromUnoDate</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030111.html?DbPAR=BASIC">Συνάρτηση CDateToUnoDate</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030108.html?DbPAR=BASIC">Συνάρτηση CDateFromIso</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030107.html?DbPAR=BASIC">Συνάρτηση CDateToIso</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100300.html?DbPAR=BASIC">Συνάρτηση CDate</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100400.html?DbPAR=BASIC">Συνάρτηση CDbl</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100060.html?DbPAR=BASIC">Συνάρτηση CDec</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100500.html?DbPAR=BASIC">Συνάρτηση CInt</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100600.html?DbPAR=BASIC">Συνάρτηση CLng</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100900.html?DbPAR=BASIC">Συνάρτηση CSng</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03101000.html?DbPAR=BASIC">Συνάρτηση CStr</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090401.html?DbPAR=BASIC">Πρόταση Call</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020401.html?DbPAR=BASIC">Πρόταση ChDir</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020402.html?DbPAR=BASIC">Πρόταση ChDrive</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090402.html?DbPAR=BASIC">Συνάρτηση Choose</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120102.html?DbPAR=BASIC">Συνάρτηση Chr</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120112.html?DbPAR=BASIC">Συνάρτηση ChrW [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020101.html?DbPAR=BASIC">Πρόταση Close</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03110100.html?DbPAR=BASIC">Τελεστές σύγκρισης</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100700.html?DbPAR=BASIC">Πρόταση Const</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120313.html?DbPAR=BASIC">Συνάρτηση ConvertFromURL</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120312.html?DbPAR=BASIC">Συνάρτηση ConvertToURL</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080102.html?DbPAR=BASIC">Συνάρτηση Cos</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03132400.html?DbPAR=BASIC">Συνάρτηση CreateObject</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03131800.html?DbPAR=BASIC">Συνάρτηση CreateUnoDialog</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03132000.html?DbPAR=BASIC">Συνάρτηση CreateUnoListener</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03131600.html?DbPAR=BASIC">Συνάρτηση CreateUnoService</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03131500.html?DbPAR=BASIC">Συνάρτηση CreateUnoStruct</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03132300.html?DbPAR=BASIC">Συνάρτηση CreateUnoValue</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020403.html?DbPAR=BASIC">Συνάρτηση CurDir</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100070.html?DbPAR=BASIC">Συνάρτηση CVar</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03100080.html?DbPAR=BASIC">Συνάρτηση CVErr</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030301.html?DbPAR=BASIC">Πρόταση Date</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030110.html?DbPAR=BASIC">Συνάρτηση DateAdd</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030120.html?DbPAR=BASIC">Συνάρτηση DateDiff</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030130.html?DbPAR=BASIC">Συνάρτηση DatePart</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030101.html?DbPAR=BASIC">Συνάρτηση DateSerial</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030102.html?DbPAR=BASIC">Συνάρτηση DateValue</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030103.html?DbPAR=BASIC">Συνάρτηση Day</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140000.html?DbPAR=BASIC">Συνάρτηση DDB [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090403.html?DbPAR=BASIC">Πρόταση Declare</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03101100.html?DbPAR=BASIC">Πρόταση DefBool</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03101300.html?DbPAR=BASIC">Πρόταση DefDate</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03101400.html?DbPAR=BASIC">Πρόταση DefDbl</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03101500.html?DbPAR=BASIC">Πρόταση DefInt</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03101600.html?DbPAR=BASIC">Πρόταση DefLng</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03101700.html?DbPAR=BASIC">Πρόταση DefObj</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102000.html?DbPAR=BASIC">Πρόταση DefVar</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03104300.html?DbPAR=BASIC">Συνάρτηση DimArray</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102100.html?DbPAR=BASIC">Πρόταση Dim</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020404.html?DbPAR=BASIC">Συνάρτηση Dir</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090201.html?DbPAR=BASIC">Πρόταση Do...Loop</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03110100.html?DbPAR=BASIC">Τελεστές σύγκρισης</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090404.html?DbPAR=BASIC">Πρόταση End</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/enum.html?DbPAR=BASIC">Πρόταση Enum</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03130800.html?DbPAR=BASIC">Συνάρτηση Environ</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020301.html?DbPAR=BASIC">Συνάρτηση Eof</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03104600.html?DbPAR=BASIC">Συνάρτηση EqualUnoObjects</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03060200.html?DbPAR=BASIC">Τελεστής Eqv</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03104700.html?DbPAR=BASIC">Πρόταση Erase</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03050100.html?DbPAR=BASIC">Συνάρτηση Erl</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03050200.html?DbPAR=BASIC">Συνάρτηση Err</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Αντικείμενο Err VBA</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03050300.html?DbPAR=BASIC">Συνάρτηση Error</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03050000.html?DbPAR=BASIC">Συναρτήσεις χειρισμού σφαλμάτων</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090412.html?DbPAR=BASIC">Πρόταση Exit</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080201.html?DbPAR=BASIC">Συνάρτηση Exp</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020405.html?DbPAR=BASIC">Συνάρτηση FileAttr</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020406.html?DbPAR=BASIC">Πρόταση FileCopy</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020407.html?DbPAR=BASIC">Συνάρτηση FileDateTime</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020415.html?DbPAR=BASIC">Συνάρτηση FileExists</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020408.html?DbPAR=BASIC">Συνάρτηση FileLen</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103800.html?DbPAR=BASIC">Συνάρτηση FindObject</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103900.html?DbPAR=BASIC">Συνάρτηση FindPropertyObject</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080501.html?DbPAR=BASIC">Συνάρτηση Fix</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090202.html?DbPAR=BASIC">Πρόταση For...Next</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090202.html?DbPAR=BASIC">Πρόταση For...Next</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120301.html?DbPAR=BASIC">Συνάρτηση Format</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03150000.html?DbPAR=BASIC">Συνάρτηση FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03170010.html?DbPAR=BASIC">Συνάρτηση FormatNumber [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080503.html?DbPAR=BASIC">Συνάρτηση Frac</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020102.html?DbPAR=BASIC">Συνάρτηση FreeFile</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090405.html?DbPAR=BASIC">Συνάρτηση FreeLibrary</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090406.html?DbPAR=BASIC">Πρόταση Function</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090400.html?DbPAR=BASIC">Πρόσθετες προτάσεις</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140001.html?DbPAR=BASIC">Συνάρτηση FV [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080300.html?DbPAR=BASIC">Δημιουργία τυχαίων αριθμών</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020409.html?DbPAR=BASIC">Συνάρτηση GetAttr</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03132500.html?DbPAR=BASIC">Συνάρτηση GetDefaultContext</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03132100.html?DbPAR=BASIC">Συνάρτηση GetGuiType</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03131700.html?DbPAR=BASIC">Συνάρτηση GetProcessServiceManager</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">Συνάρτηση GetPathSeparator</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03131000.html?DbPAR=BASIC">Συνάρτηση GetSolarVersion</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03130700.html?DbPAR=BASIC">Συνάρτηση GetSystemTicks</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020201.html?DbPAR=BASIC">Πρόταση Get</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103450.html?DbPAR=BASIC">Πρόταση Global</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090301.html?DbPAR=BASIC">Πρόταση GoSub...Return</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090302.html?DbPAR=BASIC">Πρόταση GoTo</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03010302.html?DbPAR=BASIC">Συνάρτηση Green</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03104400.html?DbPAR=BASIC">Συνάρτηση HasUnoInterfaces</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080801.html?DbPAR=BASIC">Συνάρτηση Hex</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030201.html?DbPAR=BASIC">Συνάρτηση Hour</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090103.html?DbPAR=BASIC">Πρόταση IIf</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090101.html?DbPAR=BASIC">Πρόταση If...Then...Else</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03060300.html?DbPAR=BASIC">Τελεστής Imp</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120401.html?DbPAR=BASIC">Συνάρτηση InStr</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120411.html?DbPAR=BASIC">Συνάρτηση InStrRev [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03160000.html?DbPAR=BASIC">Συνάρτηση Input [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03010201.html?DbPAR=BASIC">Συνάρτηση InputBox</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020202.html?DbPAR=BASIC">Πρόταση Input#</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080502.html?DbPAR=BASIC">Συνάρτηση Int</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140002.html?DbPAR=BASIC">Συνάρτηση IPmt [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140003.html?DbPAR=BASIC">Συνάρτηση IRR [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102200.html?DbPAR=BASIC">Συνάρτηση IsArray</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102300.html?DbPAR=BASIC">Συνάρτηση IsDate</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102400.html?DbPAR=BASIC">Συνάρτηση IsEmpty</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102450.html?DbPAR=BASIC">Συνάρτηση IsError</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03104000.html?DbPAR=BASIC">Συνάρτηση IsMissing</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102600.html?DbPAR=BASIC">Συνάρτηση IsNull</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102700.html?DbPAR=BASIC">Συνάρτηση IsNumeric</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102800.html?DbPAR=BASIC">Συνάρτηση IsObject</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03104500.html?DbPAR=BASIC">Συνάρτηση IsUnoStruct</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120315.html?DbPAR=BASIC">Συνάρτηση Join</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020410.html?DbPAR=BASIC">Πρόταση Kill</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102900.html?DbPAR=BASIC">Συνάρτηση LBound</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120302.html?DbPAR=BASIC">Συνάρτηση LCase</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120304.html?DbPAR=BASIC">Πρόταση LSet</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120305.html?DbPAR=BASIC">Συνάρτηση LTrim</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120303.html?DbPAR=BASIC">Συνάρτηση Left</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120402.html?DbPAR=BASIC">Συνάρτηση Len</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103100.html?DbPAR=BASIC">Πρόταση Let</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020203.html?DbPAR=BASIC">Πρόταση Line Input #</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020302.html?DbPAR=BASIC">Συνάρτηση Loc</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020303.html?DbPAR=BASIC">Συνάρτηση Lof</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080202.html?DbPAR=BASIC">Συνάρτηση Log</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120306.html?DbPAR=BASIC">Συνάρτηση Mid, Πρόταση Mid</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030202.html?DbPAR=BASIC">Συνάρτηση Minute</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140004.html?DbPAR=BASIC">Συνάρτηση MIRR [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020411.html?DbPAR=BASIC">Πρόταση MkDir</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03070600.html?DbPAR=BASIC">Τελεστής Mod</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030104.html?DbPAR=BASIC">Συνάρτηση Month</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03150002.html?DbPAR=BASIC">Συνάρτηση MonthName [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03010102.html?DbPAR=BASIC">Συνάρτηση MsgBox</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03010101.html?DbPAR=BASIC">Πρόταση MsgBox</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020412.html?DbPAR=BASIC">Πρόταση Name</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03060400.html?DbPAR=BASIC">Τελεστής Not</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030203.html?DbPAR=BASIC">Συνάρτηση Now</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140005.html?DbPAR=BASIC">Συνάρτηση NPer [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140006.html?DbPAR=BASIC">Συνάρτηση NPV [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080000.html?DbPAR=BASIC">Αριθμητικές συναρτήσεις</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080802.html?DbPAR=BASIC">Συνάρτηση Oct</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03050500.html?DbPAR=BASIC">Πρόταση On Error GoTo ... Resume</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090303.html?DbPAR=BASIC">Πρόταση On...GoSub; Πρόταση On...GoTo</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020103.html?DbPAR=BASIC">Πρόταση Open</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103200.html?DbPAR=BASIC">Πρόταση Option Base</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Επιλογή ClassModule</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103300.html?DbPAR=BASIC">Πρόταση Option Explicit</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103350.html?DbPAR=BASIC">Πρόταση Option VBASupport</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (σε πρόταση συνάρτησης)</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03060500.html?DbPAR=BASIC">Τελεστής Or</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140007.html?DbPAR=BASIC">Συνάρτηση Pmt [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140008.html?DbPAR=BASIC">Συνάρτηση PPmt [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03010103.html?DbPAR=BASIC">Πρόταση Print</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103400.html?DbPAR=BASIC">Πρόταση Public</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020204.html?DbPAR=BASIC">Πρόταση Put</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140009.html?DbPAR=BASIC">Συνάρτηση PV [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03010304.html?DbPAR=BASIC">Συνάρτηση QBColor</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140010.html?DbPAR=BASIC">Συνάρτηση Rate [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080301.html?DbPAR=BASIC">Πρόταση Randomize</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03102101.html?DbPAR=BASIC">Πρόταση ReDim</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03010303.html?DbPAR=BASIC">Συνάρτηση Red</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090407.html?DbPAR=BASIC">Πρόταση Rem</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020104.html?DbPAR=BASIC">Πρόταση Reset</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/Resume.html?DbPAR=BASIC">Πρόταση Resume</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03010305.html?DbPAR=BASIC">Συνάρτηση RGB</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120307.html?DbPAR=BASIC">Συνάρτηση Right</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020413.html?DbPAR=BASIC">Πρόταση RmDir</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080302.html?DbPAR=BASIC">Συνάρτηση Rnd</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03170000.html?DbPAR=BASIC">Συνάρτηση Round [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120308.html?DbPAR=BASIC">Πρόταση RSet</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120309.html?DbPAR=BASIC">Συνάρτηση RTrim</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030204.html?DbPAR=BASIC">Συνάρτηση Second</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020304.html?DbPAR=BASIC">Συνάρτηση Seek</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020305.html?DbPAR=BASIC">Συνάρτηση Seek</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090102.html?DbPAR=BASIC">Πρόταση Select...Case</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020414.html?DbPAR=BASIC">Πρόταση SetAttr</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103700.html?DbPAR=BASIC">Πρόταση Set</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080701.html?DbPAR=BASIC">Συνάρτηση Sgn</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03130500.html?DbPAR=BASIC">Συνάρτηση Shell</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080103.html?DbPAR=BASIC">Συνάρτηση Sin</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140011.html?DbPAR=BASIC">Συνάρτηση SLN [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120201.html?DbPAR=BASIC">Συναρτήσεις Space και Spc</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120201.html?DbPAR=BASIC">Συναρτήσεις Space και Spc</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120314.html?DbPAR=BASIC">Συνάρτηση Split</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080401.html?DbPAR=BASIC">Συνάρτηση Sqr</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080400.html?DbPAR=BASIC">Υπολογισμός τετραγωνικής ρίζας</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103500.html?DbPAR=BASIC">Πρόταση Static</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090408.html?DbPAR=BASIC">Πρόταση Stop</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120403.html?DbPAR=BASIC">Συνάρτηση StrComp</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120103.html?DbPAR=BASIC">Συνάρτηση Str</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120412.html?DbPAR=BASIC">Συνάρτηση StrReverse [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120202.html?DbPAR=BASIC">Συνάρτηση String</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090409.html?DbPAR=BASIC">Πρόταση Sub</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090410.html?DbPAR=BASIC">Συνάρτηση Switch</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03140012.html?DbPAR=BASIC">Συνάρτηση SYD [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080104.html?DbPAR=BASIC">Συνάρτηση Tan</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03132200.html?DbPAR=BASIC">Αντικείμενο ThisComponent</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030205.html?DbPAR=BASIC">Συνάρτηση TimeSerial</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030206.html?DbPAR=BASIC">Συνάρτηση TimeValue</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030302.html?DbPAR=BASIC">Πρόταση Time</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030303.html?DbPAR=BASIC">Συνάρτηση Timer</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03080100.html?DbPAR=BASIC">Τριγωνομετρικές συναρτήσεις</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120311.html?DbPAR=BASIC">Συνάρτηση Trim</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03131300.html?DbPAR=BASIC">Συνάρτηση TwipsPerPixelX</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03131400.html?DbPAR=BASIC">Συνάρτηση TwipsPerPixelY</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090413.html?DbPAR=BASIC">Πρόταση Type</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103600.html?DbPAR=BASIC">Συνάρτηση TypeName; Συνάρτηση VarType</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03103000.html?DbPAR=BASIC">Συνάρτηση UBound</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120310.html?DbPAR=BASIC">Συνάρτηση UCase</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03120104.html?DbPAR=BASIC">Συνάρτηση Val</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03130600.html?DbPAR=BASIC">Πρόταση Wait</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03130610.html?DbPAR=BASIC">Πρόταση WaitUntil</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030105.html?DbPAR=BASIC">Συνάρτηση WeekDay</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03150001.html?DbPAR=BASIC">Συνάρτηση WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090203.html?DbPAR=BASIC">Πρόταση While...Wend</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03090411.html?DbPAR=BASIC">Πρόταση With</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03020205.html?DbPAR=BASIC">Πρόταση Write</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03060600.html?DbPAR=BASIC">Τελεστής XOR</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03030106.html?DbPAR=BASIC">Συνάρτηση Year</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03070100.html?DbPAR=BASIC">Τελεστής "-"</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03070200.html?DbPAR=BASIC">Τελεστής "*"</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03070300.html?DbPAR=BASIC">Τελεστής "+"</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03070400.html?DbPAR=BASIC">Τελεστής "/"</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03070500.html?DbPAR=BASIC">Τελεστής "^"</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Προχωρημένες βιβλιοθήκες Basic</label><ul>\
    <li><a target="_top" href="el/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Βιβλιοθήκη εργαλείων</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Βιβλιοθήκη DEPOT</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Βιβλιοθήκη EURO</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Βιβλιοθήκη FORMWIZARD</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Βιβλιοθήκη GIMMICKS</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Βιβλιοθήκη SCHEDULE</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Βιβλιοθήκη SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Βιβλιοθήκη TEMPLATE</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Οδηγοί</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/macro_recording.html?DbPAR=BASIC">Καταγραφή μιας μακροεντολής</a></li>\
    <li><a target="_top" href="el/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Αλλαγή των ιδιοτήτων των πεδίων ελέγχου στον επεξεργαστή διαλόγου</a></li>\
    <li><a target="_top" href="el/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Δημιουργία πεδίων ελέγχου στον επεξεργαστή διαλόγου</a></li>\
    <li><a target="_top" href="el/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Παραδείγματα προγραμματισμού πεδίων ελέγχου στον επεξεργαστή διαλόγου</a></li>\
    <li><a target="_top" href="el/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Άνοιγμα διαλόγου με Basic</a></li>\
    <li><a target="_top" href="el/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Δημιουργία διαλόγου Basic</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01030400.html?DbPAR=BASIC">Οργάνωση βιβλιοθηκών και αρθρωμάτων</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01020100.html?DbPAR=BASIC">Χρήση μεταβλητών</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01020200.html?DbPAR=BASIC">Χρήση των αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01030300.html?DbPAR=BASIC">Αποσφαλμάτωση ενός προγράμματος BASIC</a></li>\
    <li><a target="_top" href="el/text/sbasic/shared/01040000.html?DbPAR=BASIC">Μακροεντολές οδηγούμενες από γεγονότα</a></li>\
    <li><a target="_top" href="el/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Παραδείγματα προγραμματισμού Basic</a></li>\
    <li><a target="_top" href="el/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic σε Python</a></li>\
    <li><a target="_top" href="el/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Βοήθεια δεσμών ενεργειών Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Γενικές πληροφορίες και χρήση διεπαφής χρήστη</label><ul>\
    <li><a target="_top" href="el/text/sbasic/python/main0000.html?DbPAR=BASIC">Δέσμες ενεργειών Python</a></li>\
    <li><a target="_top" href="el/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE για Python</a></li>\
    <li><a target="_top" href="el/text/sbasic/python/python_locations.html?DbPAR=BASIC">Οργάνωση σεναρίων Python</a></li>\
    <li><a target="_top" href="el/text/sbasic/python/python_shell.html?DbPAR=BASIC">Διαδραστικό κέλυφος Python</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Προγραμματισμός με Python</label><ul>\
    <li><a target="_top" href="el/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Προγραμματισμός με Python</a></li>\
    <li><a target="_top" href="el/text/sbasic/python/python_examples.html?DbPAR=BASIC">Παραδείγματα Python</a></li>\
    <li><a target="_top" href="el/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python σε Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Εγκατάσταση του LibreOffice</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Αλλαγή συσχετισμών τύπων εγγράφων του Microsoft Office</a></li>\
    <li><a target="_top" href="el/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Ασφαλής λειτουργία</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Συνηθισμένα θέματα βοήθειας</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Γενικές Πληροφορίες</label><ul>\
    <li><a target="_top" href="el/text/shared/main0400.html?DbPAR=SHARED">Πλήκτρα συντόμευσης</a></li>\
    <li><a target="_top" href="el/text/shared/00/00000005.html?DbPAR=SHARED">Γενικό Γλωσσάρι</a></li>\
    <li><a target="_top" href="el/text/shared/00/00000002.html?DbPAR=SHARED">Γλωσσάρι όρων Διαδικτύου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/accessibility.html?DbPAR=SHARED">Προσιτότητα στο LibreOffice</a></li>\
    <li><a target="_top" href="el/text/shared/guide/keyboard.html?DbPAR=SHARED">Συντομεύσεις (Προσιτότητα LibreOffice)</a></li>\
    <li><a target="_top" href="el/text/shared/04/01010000.html?DbPAR=SHARED">Γενικά πλήκτρα συντόμευσης του LibreOffice</a></li>\
    <li><a target="_top" href="el/text/shared/guide/version_number.html?DbPAR=SHARED">Εκδόσεις και αριθμοί έκδοσης</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice και Microsoft Office</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/ms_user.html?DbPAR=SHARED">Χρήση Microsoft Office και LibreOffice</a></li>\
    <li><a target="_top" href="el/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Σύγκριση όρων Microsoft Office και LibreOffice</a></li>\
    <li><a target="_top" href="el/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Σχετικά με τη μετατροπή εγγράφων Microsoft Office</a></li>\
    <li><a target="_top" href="el/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Αλλαγή συσχετισμών τύπων εγγράφων του Microsoft Office</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Επιλογές LibreOffice</label><ul>\
    <li><a target="_top" href="el/text/shared/optionen/01000000.html?DbPAR=SHARED">Επιλογές</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01010100.html?DbPAR=SHARED">Δεδομένα χρήστη</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01010200.html?DbPAR=SHARED">Γενικά</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01010300.html?DbPAR=SHARED">Διαδρομές</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01010400.html?DbPAR=SHARED">Βοηθήματα γραφής</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01010600.html?DbPAR=SHARED">Γενικά</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01010700.html?DbPAR=SHARED">Γραμματοσειρές</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01010800.html?DbPAR=SHARED">Προβολή</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01010900.html?DbPAR=SHARED">Επιλογές εκτύπωσης</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01012000.html?DbPAR=SHARED">Χρώματα εφαρμογής</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01013000.html?DbPAR=SHARED">Προσιτότητα</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/java.html?DbPAR=SHARED">Προχωρημένα</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Ειδική διαμόρφωση</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/opencl.html?DbPAR=SHARED">Open CL</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01020000.html?DbPAR=SHARED">Επιλογές Φόρτωση/Αποθήκευση</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01030000.html?DbPAR=SHARED">Επιλογές Διαδικτύου</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01040000.html?DbPAR=SHARED">Επιλογές Εγγράφου Κειμένου</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01050000.html?DbPAR=SHARED">Επιλογές εγγράφων HTML</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01060000.html?DbPAR=SHARED">Επιλογές λογιστικού φύλλου</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01070000.html?DbPAR=SHARED">Επιλογές παρουσίασης</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01080000.html?DbPAR=SHARED">Επιλογές σχεδίασης</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01090000.html?DbPAR=SHARED">Τύπος</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01110000.html?DbPAR=SHARED">Επιλογές διαγράμματος</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01130100.html?DbPAR=SHARED">Ιδιότητες VBA</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01140000.html?DbPAR=SHARED">Γλώσσες</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01150000.html?DbPAR=SHARED">Επιλογές ρύθμισης γλώσσας</a></li>\
    <li><a target="_top" href="el/text/shared/optionen/01160000.html?DbPAR=SHARED">Επιλογές προέλευσης δεδομένων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Οδηγοί</label><ul>\
    <li><a target="_top" href="el/text/shared/autopi/01000000.html?DbPAR=SHARED">Οδηγός</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Οδηγός γράμματος</label><ul>\
    <li><a target="_top" href="el/text/shared/autopi/01010000.html?DbPAR=SHARED">Αυτόματος πιλότος επιστολής</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Οδηγός τηλεομοιότυπου</label><ul>\
    <li><a target="_top" href="el/text/shared/autopi/01020000.html?DbPAR=SHARED">Αυτόματος πιλότος  Fax</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Οδηγός σημειωματαρίου</label><ul>\
    <li><a target="_top" href="el/text/shared/autopi/01040000.html?DbPAR=SHARED">Αυτόματος Πιλότος Προγράμματος Εργασίας</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Οδηγός εξαγωγής HTML</label><ul>\
    <li><a target="_top" href="el/text/shared/autopi/01110000.html?DbPAR=SHARED">Εξαγωγή HTML</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Οδηγός μετατροπής εγγράφου</label><ul>\
    <li><a target="_top" href="el/text/shared/autopi/01130000.html?DbPAR=SHARED">Μετατροπέας εγγράφων</a></li>\
			</ul></li>\
    <li><a target="_top" href="el/text/shared/autopi/01150000.html?DbPAR=SHARED">Αυτόματος πιλότος Μετατροπής Ευρώ</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Διαμόρφωση LibreOffice</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/configure_overview.html?DbPAR=SHARED">Προσαρμογή του LibreOffice</a></li>\
    <li><a target="_top" href="el/text/shared/01/packagemanager.html?DbPAR=SHARED">Διαχειριστής Επεκτάσεων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/flat_icons.html?DbPAR=SHARED">Αλλαγή μεγέθους εικονιδίων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Προσθήκη πεδίων επιλογών σε γραμμές εργαλείων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/workfolder.html?DbPAR=SHARED">Αλλαγή του καταλόγου εργασίας σας</a></li>\
    <li><a target="_top" href="el/text/shared/guide/standard_template.html?DbPAR=SHARED">Αλλαγή προεπιλεγμένων προτύπων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Δήλωση ενός βιβλίου διευθύνσεων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/formfields.html?DbPAR=SHARED">Εισαγωγή και επεξεργασία πεδίων επιλογών</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Εργασία με τη διεπαφή χρήστη</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Περιήγηση σε αντικείμενα γρήγορης πρόσβασης</a></li>\
    <li><a target="_top" href="el/text/shared/guide/navigator.html?DbPAR=SHARED">Περιήγηση σύνοψης εγγράφου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/autohide.html?DbPAR=SHARED">Εμφάνιση, αγκύρωση και απόκρυψη παραθύρων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/textmode_change.html?DbPAR=SHARED">Εναλλαγή μεταξύ λειτουργίας εισαγωγής και λειτουργίας αντικατάστασης</a></li>\
    <li><a target="_top" href="el/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Χρήση γραμμών εργαλείων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Ψηφιακές υπογραφές</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Περί ψηφιακών υπογραφών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Εφαρμογή ψηφιακών υπογραφών</a></li>\
    <li><a target="_top" href="el/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">Εξαγωγή ψηφιακής υπογραφής PDF</a></li>\
    <li><a target="_top" href="el/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Υπογραφή υφιστάμενου PDF</a></li>\
    <li><a target="_top" href="el/text/shared/01/addsignatureline.html?DbPAR=SHARED">Προσθήκη γραμμής υπογραφής σε έγγραφα</a></li>\
    <li><a target="_top" href="el/text/shared/01/signsignatureline.html?DbPAR=SHARED">Υπογράφοντας στη γραμμή υπογραφής</a></li>\
    <li><a target="_top" href="el/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Εκτύπωση, τηλεομοιοτυπία, αποστολή</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/labels_database.html?DbPAR=SHARED">Εκτύπωση ετικετών διευθύνσεων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Ασπρόμαυρη εκτύπωση</a></li>\
    <li><a target="_top" href="el/text/shared/guide/email.html?DbPAR=SHARED">Αποστολή εγγράφων ως E-mail</a></li>\
    <li><a target="_top" href="el/text/shared/guide/fax.html?DbPAR=SHARED">Αποστολή φαξ με το LibreOffice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Μεταφορά & απόθεση</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/dragdrop.html?DbPAR=SHARED">Μετακίνηση και απόθεση μέσα σε ένα έγγραφο του LibreOffice</a></li>\
    <li><a target="_top" href="el/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Μετακίνηση και αντιγραφή κειμένου σε έγγραφα</a></li>\
    <li><a target="_top" href="el/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Αντιγραφή περιοχών υπολογιστικού φύλλου σε έγγραφα κειμένου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Αντιγραφή γραφικών μεταξύ εγγράφων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Αντιγραφή γραφικών από τη Συλλογή</a></li>\
    <li><a target="_top" href="el/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Μετακίνηση και απόθεση με την προβολή προέλευσης δεδομένων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Αντιγραφή και επικόλληση</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Αντιγραφή αντικειμένων σχεδίασης σε άλλα έγγραφα</a></li>\
    <li><a target="_top" href="el/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Αντιγραφή γραφικών μεταξύ εγγράφων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Αντιγραφή γραφικών από τη Συλλογή</a></li>\
    <li><a target="_top" href="el/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Αντιγραφή περιοχών υπολογιστικού φύλλου σε έγγραφα κειμένου</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Χάρτες και διαγράμματα</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/chart_insert.html?DbPAR=SHARED">Εισαγωγή διαγραμμάτων</a></li>\
    <li><a target="_top" href="el/text/schart/main0000.html?DbPAR=SHARED">Διαγράμματα στο LibreOffice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Φόρτωση, αποθήκευση, εισαγωγή, εξαγωγή, PDF</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/doc_open.html?DbPAR=SHARED">Άνοιγμα εγγράφων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/import_ms.html?DbPAR=SHARED">Άνοιγμα εγγράφων αποθηκευμένων σε άλλες μορφές</a></li>\
    <li><a target="_top" href="el/text/shared/guide/doc_save.html?DbPAR=SHARED">Αποθήκευση εγγράφων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Αυτόματη αποθήκευση εγγράφων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/export_ms.html?DbPAR=SHARED">Αποθήκευση εγγράφων σε άλλες μορφές</a></li>\
    <li><a target="_top" href="el/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Εξαγωγή ως PDF</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Εισαγωγή και εξαγωγή δεδομένων σε μορφή κειμένου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Σύνδεσμοι και αναφορές</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Εισαγωγή υπερσυνδέσμων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Σχετικοί και απόλυτοι σύνδεσμοι</a></li>\
    <li><a target="_top" href="el/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Επεξεργασία υπερσυνδέσμων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Εντοπισμός έκδοσης εγγράφου</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Σύγκριση εκδόσεων ενός εγγράφου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Συγχώνευση εκδόσεων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Καταγραφή αλλαγών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/redlining.html?DbPAR=SHARED">Καταγραφή και εμφάνιση αλλαγών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Αποδοχή ή απόρριψη αλλαγών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Διαχείριση αναθεωρήσεων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Ετικέτες και επαγγελματικές κάρτες</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/labels.html?DbPAR=SHARED">Δημιουργία και εκτύπωση ετικετών και επαγγελματικών καρτών</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Εισαγωγή εξωτερικών δεδομένων</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/copytable2application.html?DbPAR=SHARED">Εισαγωγή δεδομένων από υπολογιστικά φύλλα</a></li>\
    <li><a target="_top" href="el/text/shared/guide/copytext2application.html?DbPAR=SHARED">Εισαγωγή δεδομένων από έγγραφα κειμένου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Εισαγωγή, επεξεργασία, αποθήκευση Bitmaps</a></li>\
    <li><a target="_top" href="el/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Προσθήκη γραφικών στη Συλλογή</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Αυτόματες λειτουργίες</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Απενεργοποίηση της επιλογής Αυτόματη αναγνώριση URL</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Αναζήτηση και αντικατάσταση</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/data_search2.html?DbPAR=SHARED">Αναζήτηση με ένα φίλτρο φόρμας</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_search.html?DbPAR=SHARED">Αναζήτηση σε πίνακες και έγγραφα φόρμας</a></li>\
    <li><a target="_top" href="el/text/shared/01/02100001.html?DbPAR=SHARED">Κατάλογος κανονικών εκφράσεων</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Οδηγοί</label><ul>\
    <li><a target="_top" href="el/text/shared/guide/linestyles.html?DbPAR=SHARED">Εφαρμογή τεχνοτροπιών γραμμών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/text_color.html?DbPAR=SHARED">Αλλαγή του χρώματος κειμένου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/change_title.html?DbPAR=SHARED">Αλλαγή του τίτλου ενός εγγράφου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/round_corner.html?DbPAR=SHARED">Δημιουργία στρογγυλεμένων γωνιών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/background.html?DbPAR=SHARED">Ορισμός χρωμάτων παρασκηνίου ή γραφικών παρασκηνίου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/lineend_define.html?DbPAR=SHARED">Καθορισμός άκρων γραμμής</a></li>\
    <li><a target="_top" href="el/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Καθορισμός τεχνοτροπιών γραμμών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Επεξεργασία γραφικών αντικειμένων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/line_intext.html?DbPAR=SHARED">Σχεδίαση γραμμών σε κείμενο</a></li>\
    <li><a target="_top" href="el/text/shared/guide/aaa_start.html?DbPAR=SHARED">Πρώτα βήματα</a></li>\
    <li><a target="_top" href="el/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Εισαγωγή αντικειμένων από τη Συλλογή</a></li>\
    <li><a target="_top" href="el/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Εισαγωγή μη χωριζόμενων διαστημάτων, ενωτικών και ήπιων ενωτικών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Εισαγωγή ειδικών χαρακτήρων</a></li>\
    <li><a target="_top" href="el/text/shared/guide/tabs.html?DbPAR=SHARED">Εισαγωγή και επεξεργασία στηλοθετών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/protection.html?DbPAR=SHARED">Προστασία περιεχομένων στο LibreOffice</a></li>\
    <li><a target="_top" href="el/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Προστασία εγγραφών</a></li>\
    <li><a target="_top" href="el/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Επιλογή της μέγιστης εκτυπώσιμης περιοχής μιας σελίδας</a></li>\
    <li><a target="_top" href="el/text/shared/guide/measurement_units.html?DbPAR=SHARED">Επιλογή μονάδων μέτρησης</a></li>\
    <li><a target="_top" href="el/text/shared/guide/language_select.html?DbPAR=SHARED">Επιλογή της γλώσσας εγγράφου</a></li>\
    <li><a target="_top" href="el/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Σχεδίαση πίνακα</a></li>\
    <li><a target="_top" href="el/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Απενεργοποίηση Κουκκίδων και Αρίθμησης για μεμονωμένες παραγράφους</a></li>\
		</ul></li>\
	</ul></li></ul>\
';
