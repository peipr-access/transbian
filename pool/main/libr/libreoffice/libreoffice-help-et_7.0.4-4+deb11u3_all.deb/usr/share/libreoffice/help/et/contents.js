document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="02"><label for="02">Tekstidokumendid (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Üldine teave ja kasutajaliidese kasutamine</label><ul>\
    <li><a target="_top" href="et/text/swriter/main0000.html?DbPAR=WRITER">LibreOffice Writeri Abi sissejuhatus</a></li>\
    <li><a target="_top" href="et/text/swriter/main0503.html?DbPAR=WRITER">LibreOffice Writeri võimalused</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/main.html?DbPAR=WRITER">Juhised LibreOffice Writeri kasutamiseks</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Akende dokkimine ja suuruse muutmine</a></li>\
    <li><a target="_top" href="et/text/swriter/04/01020000.html?DbPAR=WRITER">LibreOffice Writeri kiirklahvid</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/words_count.html?DbPAR=WRITER">Sõnade loendamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/keyboard.html?DbPAR=WRITER">Kiirklahvide kasutamine (LibreOffice Writeri hõlbustus)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Käskude ja menüüde seletused</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menüüd</label><ul>\
    <li><a target="_top" href="et/text/swriter/main0100.html?DbPAR=WRITER">Menüüd</a></li>\
    <li><a target="_top" href="et/text/swriter/main0101.html?DbPAR=WRITER">Fail</a></li>\
    <li><a target="_top" href="et/text/swriter/main0102.html?DbPAR=WRITER">Redigeerimine</a></li>\
    <li><a target="_top" href="et/text/swriter/main0103.html?DbPAR=WRITER">Vaade</a></li>\
    <li><a target="_top" href="et/text/swriter/main0104.html?DbPAR=WRITER">Lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/main0105.html?DbPAR=WRITER">Vormindus</a></li>\
    <li><a target="_top" href="et/text/swriter/main0115.html?DbPAR=WRITER">Stiilid</a></li>\
    <li><a target="_top" href="et/text/swriter/main0110.html?DbPAR=WRITER">Tabel</a></li>\
    <li><a target="_top" href="et/text/swriter/main0120.html?DbPAR=WRITER">Vorm</a></li>\
    <li><a target="_top" href="et/text/swriter/main0106.html?DbPAR=WRITER">Tööriistad</a></li>\
    <li><a target="_top" href="et/text/swriter/main0107.html?DbPAR=WRITER">Aken</a></li>\
    <li><a target="_top" href="et/text/shared/main0108.html?DbPAR=WRITER">Abi</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Tööriistaribad</label><ul>\
    <li><a target="_top" href="et/text/swriter/main0200.html?DbPAR=WRITER">Tööriistaribad</a></li>\
    <li><a target="_top" href="et/text/swriter/main0202.html?DbPAR=WRITER">Vormindusriba</a></li>\
    <li><a target="_top" href="et/text/swriter/main0203.html?DbPAR=WRITER">Pildiriba</a></li>\
    <li><a target="_top" href="et/text/swriter/main0204.html?DbPAR=WRITER">Tabeliriba</a></li>\
    <li><a target="_top" href="et/text/swriter/main0205.html?DbPAR=WRITER">Joonistusobjekti omaduste riba</a></li>\
    <li><a target="_top" href="et/text/swriter/main0206.html?DbPAR=WRITER">Number- ja täpploendite riba</a></li>\
    <li><a target="_top" href="et/text/swriter/main0208.html?DbPAR=WRITER">Olekuriba</a></li>\
    <li><a target="_top" href="et/text/swriter/main0210.html?DbPAR=WRITER">Printimise eelvaade</a></li>\
    <li><a target="_top" href="et/text/swriter/main0213.html?DbPAR=WRITER">Joonlauad</a></li>\
    <li><a target="_top" href="et/text/swriter/main0214.html?DbPAR=WRITER">Valemiriba</a></li>\
    <li><a target="_top" href="et/text/swriter/main0215.html?DbPAR=WRITER">Paneeliriba</a></li>\
    <li><a target="_top" href="et/text/swriter/main0216.html?DbPAR=WRITER">OLE-objektide riba</a></li>\
    <li><a target="_top" href="et/text/swriter/main0220.html?DbPAR=WRITER">Tekstiobjekti riba</a></li>\
    <li><a target="_top" href="et/text/shared/main0201.html?DbPAR=WRITER">Standardriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0212.html?DbPAR=WRITER">Tabeliandmete riba</a></li>\
    <li><a target="_top" href="et/text/shared/main0213.html?DbPAR=WRITER">Vormi navigeerimisriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0214.html?DbPAR=WRITER">Päringu disaini riba</a></li>\
    <li><a target="_top" href="et/text/shared/main0226.html?DbPAR=WRITER">Vormi disainiriba</a></li>\
    <li><a target="_top" href="et/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo tööriistariba</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">Tekstidokumentide loomine</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Liikumine ja valimine klaviatuuri abil</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Otsese kursori kasutamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Pildid tekstidokumentides</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Piltide lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Pildi lisamine failist</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Piltide lisamine galeriist lohistades</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Skaneeritud pildi lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Diagrammi lisamine tekstidokumenti</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Piltide lisamine LibreOffice Draw&#39;st või Impressist</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabelid tekstidokumentides</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Arvude tuvastamise sisse- ja väljalülitamine tabelites</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/tablemode.html?DbPAR=WRITER">Tabeli ridade ja veergude redigeerimine klaviatuuri abil</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/table_delete.html?DbPAR=WRITER">Tabeli või tabeli sisu kustutamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/table_insert.html?DbPAR=WRITER">Tabelite lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Tabeli päise kordamine uuel leheküljel</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Tekstitabeli ridade ja veergude suuruse muutmine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objektid tekstidokumentides</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Objektide paigutamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/wrap.html?DbPAR=WRITER">Teksti mähkimine ümber objektide</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sektsioonid ja paneelid tekstidokumentides</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/sections.html?DbPAR=WRITER">Sektsioonide kasutamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/section_edit.html?DbPAR=WRITER">Sektsioonide redigeerimine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/section_insert.html?DbPAR=WRITER">Sektsioonide lisamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Sisukorrad ja registrid</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Peatükkide nummerdamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Kasutaja määratud registrid</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Sisukorra loomine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/indices_index.html?DbPAR=WRITER">Tähestikuliste registrite loomine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Mitut dokumenti hõlmavad registrid</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Bibliograafia loomine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Registrite ja sisukordade kirjete redigeerimine ning kustutamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Registrite ja sisukordade värskendamine, redigeerimine ning kustutamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Registri või sisukorra kirjete kirjeldamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/indices_form.html?DbPAR=WRITER">Registrite ja sisukordade vormindamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Väljad tekstidokumentides</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/fields.html?DbPAR=WRITER">Väljad</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/fields_date.html?DbPAR=WRITER">Fikseeritud või muutuva väärtusega kuupäevavälja lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/field_convert.html?DbPAR=WRITER">Välja teisendamine tekstiks</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Liikumine tekstidokumentides</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Teksti liigutamine ja kopeerimine dokumentides</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Dokumendi ümberkorraldamine Navigaatori abil</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Hüperlinkide lisamine Navigaatori abil</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/navigator.html?DbPAR=WRITER">Tekstidokumentide Navigaator</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Arvutamine tekstidokumentides</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Mitmeid tabeleid hõlmavad arvutused</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/calculate.html?DbPAR=WRITER">Arvutamine tekstidokumentides</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Arvutuse teostamine ja tehte tulemuse asetamine tekstidokumenti</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Lahtrite summeerimine tabelis</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Keerukamate arvutustehete teostamine tekstidokumentides</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Arvutuse teostamine ja tulemuse esitamine erinevates tabelites</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Tekstidokumentide vormindus</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">Mallid ja stiilid</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Mallid ja stiilid</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Erinevad leheküljestiilid vasak- ja parempoolsetel lehekülgedel</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/change_header.html?DbPAR=WRITER">Leheküljestiili loomine aktiivse lehekülje põhjal</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/load_styles.html?DbPAR=WRITER">Teisest dokumendist või mallist pärit stiilide kasutamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Uute stiilide loomine valikutest</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Stiilide uuendamine valikutest</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/template_create.html?DbPAR=WRITER">Dokumendimallide loomine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/template_default.html?DbPAR=WRITER">Vaikemallide muutmine</a></li>\
			</ul></li>\
    <li><a target="_top" href="et/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Lehekülje suuna muutmine (püstpaigutus või rõhtpaigutus)</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/text_capital.html?DbPAR=WRITER">Teksti tähesuuruse muutmine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Teksti peitmine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Erinevate päiste ja jaluste määramine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Peatüki nime ja numbri lisamine päisesse või jalusesse</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Teksti vormindamine sisestamise ajal</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/reset_format.html?DbPAR=WRITER">Fondi atribuutide lähtestamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Stiilide rakendamine vorminduse valamisrežiimis</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/wrap.html?DbPAR=WRITER">Teksti mähkimine ümber objektide</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Paneeli kasutamine teksti joondamiseks lehekülje keskele</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Teksti rõhutamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Teksti pööramine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/page_break.html?DbPAR=WRITER">Leheküljepiiride lisamine ja kustutamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Leheküljestiilide loomine ja rakendamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/subscript.html?DbPAR=WRITER">Teksti muutmine üla- või alakirjaks</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Erilised tekstielemendid</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/captions.html?DbPAR=WRITER">Pealdiste kasutamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Tingimuslik tekst</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Tingimuslik tekst lehekülgede loendamisel</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/fields_date.html?DbPAR=WRITER">Fikseeritud või muutuva väärtusega kuupäevavälja lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Sisestusväljade lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Jätkulehekülgede numbrite lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Leheküljenumbri lisamine jalusesse</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Teksti peitmine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Erinevate päiste ja jaluste määramine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Peatüki nime ja numbri lisamine päisesse või jalusesse</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Isikuandmete kasutamine väljadel või tingimustes</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Allmärkuste ja lõpumärkuste lisamine ning redigeerimine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Vahed allmärkuste vahel</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/header_footer.html?DbPAR=WRITER">Päised ja jalused</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Päiste ja jaluste vormindamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/text_animation.html?DbPAR=WRITER">Teksti animeerimine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Tüüpkirja loomine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automaatfunktsioonid</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Erandite lisamine automaatkorrektuuri loendisse</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/autotext.html?DbPAR=WRITER">Automaatteksti kasutamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Nummerdatud või täpploendite loomine teksti sisestamisel</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/auto_off.html?DbPAR=WRITER">Automaatkorrektuuri väljalülitamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automaatne õigekirjakontroll</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Arvude tuvastamise sisse- ja väljalülitamine tabelites</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Poolitamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Nummerdus ja loendid</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Peatükkide nummerduse lisamine pealdistele</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Nummerdatud või täpploendite loomine teksti sisestamisel</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Peatükkide nummerdamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the Chapter Level of Numbered and Bulleted Lists</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Numberloendite kombineerimine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Reanumbrite lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Nummerduse muutmine nummerdatud loendis</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Nummerdusvahemike kirjeldamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Nummerduse lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Nummerdamine ja nummerdusstiilid</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Täppide lisamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Õigekirjakontroll, tesaurus ja keeled</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automaatne õigekirjakontroll</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Sõnade eemaldamine kasutaja määratud sõnastikust</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Tesaurus</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Õigekirja ja grammatika kontroll</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Nõuanded probleemide lahendamiseks</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Teksti lisamine tabeli ette lehekülje alguses</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Hüppamine konkreetsele järjehoidjale</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Laadimine, salvestamine, importimine, eksportimine ja sisu varjamine</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/send2html.html?DbPAR=WRITER">Tekstidokumentide salvestamine HTML-vormingus</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Kogu tekstidokumendi lisamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/redaction.html?DbPAR=WRITER">Sisu varjamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Põhidokumendid</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Põhi- ja alamdokumendid</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Lingid ja viited</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/references.html?DbPAR=WRITER">Ristviidete lisamine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Hüperlinkide lisamine Navigaatori abil</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Printimine</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Printeri paberisalvede valimine</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/print_preview.html?DbPAR=WRITER">Lehekülje eelvaate vaatamine enne printimist</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/print_small.html?DbPAR=WRITER">Mitme lehekülje printimine ühele lehele</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Leheküljestiilide loomine ja rakendamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Otsimine ja asendamine</label><ul>\
    <li><a target="_top" href="et/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="et/text/shared/01/02100001.html?DbPAR=WRITER">Regulaaravaldiste loend</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML-dokumendid (Writer/veeb)</label><ul>\
    <li><a target="_top" href="et/text/shared/07/09000000.html?DbPAR=WRITER">Veebilehed</a></li>\
    <li><a target="_top" href="et/text/shared/02/01170700.html?DbPAR=WRITER">HTML-filtrid ja vormid</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/send2html.html?DbPAR=WRITER">Tekstidokumentide salvestamine HTML-vormingus</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Arvutustabelid (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Üldine teave ja kasutajaliidese kasutamine</label><ul>\
    <li><a target="_top" href="et/text/scalc/main0000.html?DbPAR=CALC">LibreOffice Calci Abi sissejuhatus</a></li>\
    <li><a target="_top" href="et/text/scalc/main0503.html?DbPAR=CALC">LibreOffice Calci võimalused</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/keyboard.html?DbPAR=CALC">Kiirklahvid (LibreOffice Calci hõlbustus)</a></li>\
    <li><a target="_top" href="et/text/scalc/04/01020000.html?DbPAR=CALC">Kiirklahvid arvutustabelites</a></li>\
    <li><a target="_top" href="et/text/scalc/05/02140000.html?DbPAR=CALC">LibreOffice Calc&#39;i veakoodid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060112.html?DbPAR=CALC">Lisafunktsioonid programmeerimisel LibreOffice Calcis</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/main.html?DbPAR=CALC">Juhised LibreOffice Calci kasutamiseks</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Käskude ja menüüde seletused</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menüüd</label><ul>\
    <li><a target="_top" href="et/text/scalc/main0100.html?DbPAR=CALC">Menüüd</a></li>\
    <li><a target="_top" href="et/text/scalc/main0101.html?DbPAR=CALC">Fail</a></li>\
    <li><a target="_top" href="et/text/scalc/main0102.html?DbPAR=CALC">Redigeerimine</a></li>\
    <li><a target="_top" href="et/text/scalc/main0103.html?DbPAR=CALC">Vaade</a></li>\
    <li><a target="_top" href="et/text/scalc/main0104.html?DbPAR=CALC">Lisamine</a></li>\
    <li><a target="_top" href="et/text/scalc/main0105.html?DbPAR=CALC">Vormindus</a></li>\
    <li><a target="_top" href="et/text/scalc/main0116.html?DbPAR=CALC">Leht</a></li>\
    <li><a target="_top" href="et/text/scalc/main0112.html?DbPAR=CALC">Andmed</a></li>\
    <li><a target="_top" href="et/text/scalc/main0106.html?DbPAR=CALC">Tööriistad</a></li>\
    <li><a target="_top" href="et/text/scalc/main0107.html?DbPAR=CALC">Aken</a></li>\
    <li><a target="_top" href="et/text/shared/main0108.html?DbPAR=CALC">Abi</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Tööriistaribad</label><ul>\
    <li><a target="_top" href="et/text/scalc/main0200.html?DbPAR=CALC">Tööriistaribad</a></li>\
    <li><a target="_top" href="et/text/scalc/main0202.html?DbPAR=CALC">Vormindusriba</a></li>\
    <li><a target="_top" href="et/text/scalc/main0203.html?DbPAR=CALC">Joonistusobjekti omaduste riba</a></li>\
    <li><a target="_top" href="et/text/scalc/main0205.html?DbPAR=CALC">Teksti vormindusriba</a></li>\
    <li><a target="_top" href="et/text/scalc/main0206.html?DbPAR=CALC">Valemiriba</a></li>\
    <li><a target="_top" href="et/text/scalc/main0208.html?DbPAR=CALC">Olekuriba</a></li>\
    <li><a target="_top" href="et/text/scalc/main0210.html?DbPAR=CALC">Printimise eelvaate riba</a></li>\
    <li><a target="_top" href="et/text/scalc/main0214.html?DbPAR=CALC">Pildiriba</a></li>\
    <li><a target="_top" href="et/text/scalc/main0218.html?DbPAR=CALC">Tööriistade riba</a></li>\
    <li><a target="_top" href="et/text/shared/main0201.html?DbPAR=CALC">Standardriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0212.html?DbPAR=CALC">Tabeliandmete riba</a></li>\
    <li><a target="_top" href="et/text/shared/main0213.html?DbPAR=CALC">Vormi navigeerimisriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0214.html?DbPAR=CALC">Päringu disaini riba</a></li>\
    <li><a target="_top" href="et/text/shared/main0226.html?DbPAR=CALC">Vormi disainiriba</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">funktsioonide tüübid ja tehtemärgid</label><ul>\
    <li><a target="_top" href="et/text/scalc/01/04060000.html?DbPAR=CALC">Funktsiooninõustaja</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060100.html?DbPAR=CALC">Funktsioonid kategooriate järgi</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060107.html?DbPAR=CALC">Massiivi funktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060120.html?DbPAR=CALC">Bititehete funktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060101.html?DbPAR=CALC">Andmebaasifunktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060102.html?DbPAR=CALC">Kuupäeva- ja ajafunktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060103.html?DbPAR=CALC">Rahandusfunktsioonid 1. osa</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060119.html?DbPAR=CALC">Rahandusfunktsioonid, 2. osa</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060118.html?DbPAR=CALC">Rahandusfunktsioonid, 3. osa</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060104.html?DbPAR=CALC">Teabefunktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060105.html?DbPAR=CALC">Loogilised funktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060106.html?DbPAR=CALC">Matemaatilised funktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060108.html?DbPAR=CALC">Statistilised funktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060181.html?DbPAR=CALC">Statistilised funktsioonid, 1. osa</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060182.html?DbPAR=CALC">Statistilised funktsioonid, 2. osa</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060183.html?DbPAR=CALC">Statistilised funktsioonid, 3. osa</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060184.html?DbPAR=CALC">Statistilised funktsioonid, 4. osa</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060185.html?DbPAR=CALC">Statistilised funktsioonid, 5. osa</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060109.html?DbPAR=CALC">Tabelarvutuse funktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060110.html?DbPAR=CALC">Tekstifunktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060111.html?DbPAR=CALC">Lisafunktsioonid</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060115.html?DbPAR=CALC">Lisafunktsioonid, analüütilised funktsioonid, 1. osa</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060116.html?DbPAR=CALC">Lisafunktsioonid, analüütilised funktsioonid, 2. osa</a></li>\
    <li><a target="_top" href="et/text/scalc/01/04060199.html?DbPAR=CALC">Tehted LibreOffice Calcis</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Kasutaja määratud funktsioonid</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Laadimine, salvestamine, importimine, eksportimine ja sisu varjamine</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/webquery.html?DbPAR=CALC">Väliste andmete lisamine tabelisse (veebipäring)</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/html_doc.html?DbPAR=CALC">HTML-lehtede salvestamine ja avamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/csv_formula.html?DbPAR=CALC">Tekstifailide importimine ja eksportimine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/redaction.html?DbPAR=CALC">Sisu varjamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Vormindus</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/text_rotate.html?DbPAR=CALC">Teksti pööramine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/text_wrap.html?DbPAR=CALC">Mitmerealise teksti kirjutamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/text_numbers.html?DbPAR=CALC">Arvude vormindamine tekstina</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/super_subscript.html?DbPAR=CALC">Ülakirjas / alakirjas tekst</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/row_height.html?DbPAR=CALC">Rea kõrguse ja veeru laiuse muutmine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Tingimusliku vorminduse rakendamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Negatiivsete arvude eristamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Vorminduse määramine valemi abil</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Nullidega algavate arvude sisestamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/format_table.html?DbPAR=CALC">Arvutustabeli vormindamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/format_value.html?DbPAR=CALC">Komakohtadega arvude vormindamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/value_with_name.html?DbPAR=CALC">Nimede panemine lahtritele</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/table_rotate.html?DbPAR=CALC">Arvutustabeli pööramine (ridade ja veergude vahetamine)</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/rename_table.html?DbPAR=CALC">Lehtede ümbernimetamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/year2000.html?DbPAR=CALC">Aastad 19xx/20xx</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Ümardatud arvude kasutamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/currency_format.html?DbPAR=CALC">Lahtrid raha vormingus</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/autoformat.html?DbPAR=CALC">Automaatvorminduse kasutamine arvutustabelites</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/note_insert.html?DbPAR=CALC">Märkuste lisamine ja redigeerimine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/design.html?DbPAR=CALC">Teemade valimine lehtedele</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Murdude sisestamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtreerimine ja sortimine</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/filters.html?DbPAR=CALC">Filtrite rakendamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/specialfilter.html?DbPAR=CALC">Filtrid: täiustatud filtri rakendamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/autofilter.html?DbPAR=CALC">Automaatfiltri rakendamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/sorted_list.html?DbPAR=CALC">Sortimisloendite rakendamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Printimine</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/print_title_row.html?DbPAR=CALC">Ridade või veergude kordamine printimisel</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/print_landscape.html?DbPAR=CALC">Lehekülgede printimine rõhtpaigutusega</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/print_details.html?DbPAR=CALC">Lehekülje elementide printimine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/print_exact.html?DbPAR=CALC">Prinditavate lehtede arvu määramine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Andmevahemikud</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/database_define.html?DbPAR=CALC">Andmebaasi vahemike määramine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/database_filter.html?DbPAR=CALC">Lahtrite vahemike filtreerimine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/database_sort.html?DbPAR=CALC">Andmete sortimine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Liigendtabel</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/datapilot.html?DbPAR=CALC">Liigendtabel</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Liigendtabelite loomine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Liigendtabelite kustutamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Liigendtabelite redigeerimine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Liigendtabelite filtreerimine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Liigendtabeli väljundvahemike valimine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Liigendtabelite uuendamine</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Liigenddiagramm</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/pivotchart.html?DbPAR=CALC">Liigenddiagramm</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Stsenaariumid</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/scenario.html?DbPAR=CALC">Stsenaariumide kasutamine</a></li>\
</ul></li>\
    <li><input type="checkbox" id="08101"><label for="08101">Vahekokkuvõtted</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/subtotaltool.html?DbPAR=CALC">Using Subtotals Tool</a></li>\
</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Viited</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Aadressid ja viited, absoluutsed ja suhtelised</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/cellreferences.html?DbPAR=CALC">Viitamine teises dokumendis asuvale lahtrile</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Viitamine teistele lehtedele ja URL-idele</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Lahtritele viitamine lohistamise abil</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/address_auto.html?DbPAR=CALC">Nimede kasutamine aadressidena</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Vaatamine, valimine, kopeerimine</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/table_view.html?DbPAR=CALC">Arvutustabeli vaate muutmine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/formula_value.html?DbPAR=CALC">Valemite või väärtuste kuvamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/line_fix.html?DbPAR=CALC">Veergude või ridade külmutamine päistena</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/multi_tables.html?DbPAR=CALC">Lehtede sakkide vahel liikumine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Kopeerimine mitmele lehele</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/cellcopy.html?DbPAR=CALC">Ainult nähtavate lahtrite kopeerimine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/mark_cells.html?DbPAR=CALC">Mitme lahtri valimine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Valemid ja arvutused</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/formulas.html?DbPAR=CALC">Arvutamine valemite abil</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/formula_copy.html?DbPAR=CALC">Valemite kopeerimine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/formula_enter.html?DbPAR=CALC">Valemite sisestamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/formula_value.html?DbPAR=CALC">Valemite või väärtuste kuvamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/calculate.html?DbPAR=CALC">Arvutamine arvutustabelites</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/calc_date.html?DbPAR=CALC">Arvutused kuupäevade ja kellaaegadega</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/calc_series.html?DbPAR=CALC">Automaatne jadade genereerimine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Ajavahede arvutamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/matrixformula.html?DbPAR=CALC">Massiivi valemite sisestamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Kaitse</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/cell_protect.html?DbPAR=CALC">Lahtrite kaitsmine muudatuste eest</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Kaitse eemaldamine lahtritelt</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Mitmesugust</label><ul>\
    <li><a target="_top" href="et/text/scalc/guide/auto_off.html?DbPAR=CALC">Automaatsete muudatuste keelamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/consolidate.html?DbPAR=CALC">Andmete konsolideerimine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/goalseek.html?DbPAR=CALC">Sihiotsingu rakendamine</a></li>\
    <li><a target="_top" href="et/text/scalc/01/solver.html?DbPAR=CALC">Lahendaja</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/multioperation.html?DbPAR=CALC">Mitme tehte rakendamine</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/multitables.html?DbPAR=CALC">Töötamine mitme lehega</a></li>\
    <li><a target="_top" href="et/text/scalc/guide/validity.html?DbPAR=CALC">Lahtri sisu valideerimine</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Esitlused (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Üldine teave ja kasutajaliidese kasutamine</label><ul>\
    <li><a target="_top" href="et/text/simpress/main0000.html?DbPAR=IMPRESS">LibreOffice Impressi Abi sissejuhatus</a></li>\
    <li><a target="_top" href="et/text/simpress/main0503.html?DbPAR=IMPRESS">LibreOffice Impressi võimalused</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Kiirklahvide kasutamine LibreOffice Impressis</a></li>\
    <li><a target="_top" href="et/text/simpress/04/01020000.html?DbPAR=IMPRESS">LibreOffice Impressi kiirklahvid</a></li>\
    <li><a target="_top" href="et/text/simpress/04/presenter.html?DbPAR=IMPRESS">Ettekandjakuva kiirklahvid</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/main.html?DbPAR=IMPRESS">LibreOffice Impressi kasutamise juhendid</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Käskude ja menüüde seletused</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menüüd</label><ul>\
    <li><a target="_top" href="et/text/simpress/main0100.html?DbPAR=IMPRESS">Menüüd</a></li>\
    <li><a target="_top" href="et/text/simpress/main0101.html?DbPAR=IMPRESS">Fail</a></li>\
    <li><a target="_top" href="et/text/simpress/main_edit.html?DbPAR=IMPRESS">Redigeerimine</a></li>\
    <li><a target="_top" href="et/text/simpress/main0103.html?DbPAR=IMPRESS">Vaade</a></li>\
    <li><a target="_top" href="et/text/simpress/main0104.html?DbPAR=IMPRESS">Lisamine</a></li>\
    <li><a target="_top" href="et/text/simpress/main_format.html?DbPAR=IMPRESS">Vormindus</a></li>\
    <li><a target="_top" href="et/text/simpress/main_slide.html?DbPAR=IMPRESS">Slaid</a></li>\
    <li><a target="_top" href="et/text/simpress/main0114.html?DbPAR=IMPRESS">Slaidiseanss</a></li>\
    <li><a target="_top" href="et/text/simpress/main_tools.html?DbPAR=IMPRESS">Tööriistad</a></li>\
    <li><a target="_top" href="et/text/simpress/main0107.html?DbPAR=IMPRESS">Aken</a></li>\
    <li><a target="_top" href="et/text/shared/main0108.html?DbPAR=IMPRESS">Abi</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Tööriistaribad</label><ul>\
    <li><a target="_top" href="et/text/simpress/main0200.html?DbPAR=IMPRESS">Tööriistaribad</a></li>\
    <li><a target="_top" href="et/text/simpress/main0202.html?DbPAR=IMPRESS">Joonte ja täitmise riba</a></li>\
    <li><a target="_top" href="et/text/simpress/main0203.html?DbPAR=IMPRESS">Teksti vormindusriba</a></li>\
    <li><a target="_top" href="et/text/simpress/main0204.html?DbPAR=IMPRESS">Slaidivaate riba</a></li>\
    <li><a target="_top" href="et/text/simpress/main0206.html?DbPAR=IMPRESS">Olekuriba</a></li>\
    <li><a target="_top" href="et/text/simpress/main0209.html?DbPAR=IMPRESS">Joonlauad</a></li>\
    <li><a target="_top" href="et/text/simpress/main0210.html?DbPAR=IMPRESS">Joonistusriba</a></li>\
    <li><a target="_top" href="et/text/simpress/main0211.html?DbPAR=IMPRESS">Liigendusriba</a></li>\
    <li><a target="_top" href="et/text/simpress/main0212.html?DbPAR=IMPRESS">Slaidisortimise riba</a></li>\
    <li><a target="_top" href="et/text/simpress/main0213.html?DbPAR=IMPRESS">Säteteriba</a></li>\
    <li><a target="_top" href="et/text/simpress/main0214.html?DbPAR=IMPRESS">Pildiriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0201.html?DbPAR=IMPRESS">Standardriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0213.html?DbPAR=IMPRESS">Vormi navigeerimisriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0226.html?DbPAR=IMPRESS">Vormi disainiriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0227.html?DbPAR=IMPRESS">Punktide redigeerimine</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Laadimine, salvestamine, importimine, eksportimine ja sisu varjamine</label><ul>\
    <li><a target="_top" href="et/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Esitluse salvestamine HTML-vormingusse</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/html_import.html?DbPAR=IMPRESS">HTML-lehtede importimine esitlustesse</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Värvide, üleminekute ja viirutuste loendite laadimine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Animatsioonide eksportimine GIF-vormingusse</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Arvutustabeli lisamine slaidile</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Piltide lisamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Slaidide kopeerimine teistest esitlustest</a></li>\
    <li><a target="_top" href="et/text/shared/guide/redaction.html?DbPAR=IMPRESS">Sisu varjamine</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Vormindus</label><ul>\
    <li><a target="_top" href="et/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Värvide, üleminekute ja viirutuste loendite laadimine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Joone- ja noolestiilide laadimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Kohandatud värvide määratlemine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Üleminekute loomine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Värvide asendamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Objektide korraldamine, joondamine ja jaotamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/background.html?DbPAR=IMPRESS">Slaidi tausta muutmine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/footer.html?DbPAR=IMPRESS">Päise või jaluse lisamine kõikidele slaididele</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Juhtslaidide/-lehtede muutmine ja lisamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Objektide liigutamine</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Printimine</label><ul>\
    <li><a target="_top" href="et/text/simpress/guide/printing.html?DbPAR=IMPRESS">Esitluste printimine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Slaidi mahutamine paberile printimisel</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Efektid</label><ul>\
    <li><a target="_top" href="et/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Animatsioonide eksportimine GIF-vormingusse</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animeeritud objektid esitluste slaidides</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Slaidisiirete animeerimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Ühe objekti sujuv üleminek teiseks</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Animeeritud GIF-piltide loomine</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objektid ja pildid</label><ul>\
    <li><a target="_top" href="et/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Objektide kombineerimine ja kujundite konstrueerimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Objektide rühmitamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Sektorite ja segmentide joonistamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Objektide kloonimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Objektide pööramine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Ruumiliste objektide ühendamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Joonte ühendamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Tähemärkide teisendamine joonistusobjektideks</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Bittrasterkujutiste teisendamine vektorgraafikaks</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Tasapinnaliste objektide teisendamine kõverateks, hulknurkadeks ja ruumilisteks objektideks</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Joone- ja noolestiilide laadimine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Kõverate joonistamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Kõverate redigeerimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Piltide lisamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Arvutustabeli lisamine slaidile</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Objektide liigutamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Alumiste objektide valimine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Vooskeemi loomine</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Tekst esitlustes</label><ul>\
    <li><a target="_top" href="et/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Teksti lisamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Tähemärkide teisendamine joonistusobjektideks</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Vaatamine</label><ul>\
    <li><a target="_top" href="et/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Slaidide järjekorra muutmine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Suurenduse muutmine klaviatuuri abil</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Slaidiseansid</label><ul>\
    <li><a target="_top" href="et/text/simpress/guide/show.html?DbPAR=IMPRESS">Slaidiseansi esitamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Ettekandjakuva kasutamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impressi kaugjuhtimispuldi juhend</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/individual.html?DbPAR=IMPRESS">Kohandatud slaidiseansi loomine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Slaidide vahetumise aja salvestamine</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Joonistused (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Üldine teave ja kasutajaliidese kasutamine</label><ul>\
    <li><a target="_top" href="et/text/sdraw/main0000.html?DbPAR=DRAW">LibreOffice Draw&#39; Abi sissejuhatus</a></li>\
    <li><a target="_top" href="et/text/sdraw/main0503.html?DbPAR=DRAW">LibreOffice Draw&#39; võimalused</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Kiirklahvid joonistusobjektide puhul</a></li>\
    <li><a target="_top" href="et/text/sdraw/04/01020000.html?DbPAR=DRAW">Kiirklahvid joonistustes</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/main.html?DbPAR=DRAW">LibreOffice Draw&#39; kasutamise juhendid</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Käskude ja menüüde seletused</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menüüd</label><ul>\
    <li><a target="_top" href="et/text/sdraw/main0100.html?DbPAR=DRAW">Menüüd</a></li>\
    <li><a target="_top" href="et/text/sdraw/main0101.html?DbPAR=DRAW">Fail</a></li>\
    <li><a target="_top" href="et/text/sdraw/main_edit.html?DbPAR=DRAW">Redigeerimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/main0103.html?DbPAR=DRAW">Vaade</a></li>\
    <li><a target="_top" href="et/text/sdraw/main_insert.html?DbPAR=DRAW">Lisamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/main_format.html?DbPAR=DRAW">Vormindus</a></li>\
    <li><a target="_top" href="et/text/sdraw/main_page.html?DbPAR=DRAW">Leht</a></li>\
    <li><a target="_top" href="et/text/sdraw/main_shape.html?DbPAR=DRAW">Kujundid</a></li>\
    <li><a target="_top" href="et/text/sdraw/main_tools.html?DbPAR=DRAW">Tööriistad</a></li>\
    <li><a target="_top" href="et/text/simpress/main0107.html?DbPAR=DRAW">Aken</a></li>\
    <li><a target="_top" href="et/text/shared/main0108.html?DbPAR=DRAW">Abi</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Tööriistaribad</label><ul>\
    <li><a target="_top" href="et/text/sdraw/main0200.html?DbPAR=DRAW">Tööriistaribad</a></li>\
    <li><a target="_top" href="et/text/sdraw/main0210.html?DbPAR=DRAW">Joonistusriba</a></li>\
    <li><a target="_top" href="et/text/sdraw/main0213.html?DbPAR=DRAW">Säteteriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0201.html?DbPAR=DRAW">Standardriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0213.html?DbPAR=DRAW">Vormi navigeerimisriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0226.html?DbPAR=DRAW">Vormi disainiriba</a></li>\
    <li><a target="_top" href="et/text/shared/main0227.html?DbPAR=DRAW">Punktide redigeerimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/01/3dsettings_toolbar.html?DbPAR=DRAW">Ruumilisuse sätted</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Laadimine, salvestamine, importimine ja eksportimine</label><ul>\
    <li><a target="_top" href="et/text/simpress/guide/palette_files.html?DbPAR=DRAW">Värvide, üleminekute ja viirutuste loendite laadimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Piltide lisamine</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Vormindus</label><ul>\
    <li><a target="_top" href="et/text/simpress/guide/palette_files.html?DbPAR=DRAW">Värvide, üleminekute ja viirutuste loendite laadimine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Joone- ja noolestiilide laadimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/color_define.html?DbPAR=DRAW">Kohandatud värvide määratlemine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/gradient.html?DbPAR=DRAW">Üleminekute loomine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Värvide asendamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Objektide korraldamine, joondamine ja jaotamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/background.html?DbPAR=DRAW">Slaidi tausta muutmine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/masterpage.html?DbPAR=DRAW">Juhtslaidide/-lehtede muutmine ja lisamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/move_object.html?DbPAR=DRAW">Objektide liigutamine</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Printimine</label><ul>\
    <li><a target="_top" href="et/text/simpress/guide/printing.html?DbPAR=DRAW">Esitluste printimine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Slaidi mahutamine paberile printimisel</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Efektid</label><ul>\
    <li><a target="_top" href="et/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Ühe objekti sujuv üleminek teiseks</a></li>\
    <li><a target="_top" href="et/text/shared/01/05350000.html?DbPAR=DRAW">Ruumiefektid</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objektid ja pildid</label><ul>\
    <li><a target="_top" href="et/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Objektide kombineerimine ja kujundite konstrueerimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Sektorite ja segmentide joonistamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Objektide kloonimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Objektide pööramine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Ruumiliste objektide ühendamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Joonte ühendamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/text2curve.html?DbPAR=DRAW">Tähemärkide teisendamine joonistusobjektideks</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/vectorize.html?DbPAR=DRAW">Bittrasterkujutiste teisendamine vektorgraafikaks</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/3d_create.html?DbPAR=DRAW">Tasapinnaliste objektide teisendamine kõverateks, hulknurkadeks ja ruumilisteks objektideks</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Joone- ja noolestiilide laadimine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/line_draw.html?DbPAR=DRAW">Kõverate joonistamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/line_edit.html?DbPAR=DRAW">Kõverate redigeerimine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Piltide lisamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/table_insert.html?DbPAR=DRAW">Arvutustabeli lisamine slaidile</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/move_object.html?DbPAR=DRAW">Objektide liigutamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/select_object.html?DbPAR=DRAW">Alumiste objektide valimine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/orgchart.html?DbPAR=DRAW">Vooskeemi loomine</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Rühmad ja kihid</label><ul>\
    <li><a target="_top" href="et/text/sdraw/guide/groups.html?DbPAR=DRAW">Objektide rühmitamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/layers.html?DbPAR=DRAW">Kihid</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Kihtide lisamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Kihtidega töötamine</a></li>\
    <li><a target="_top" href="et/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Objektide teisaldamine teisele kihile</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Tekst joonistustes</label><ul>\
    <li><a target="_top" href="et/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Teksti lisamine</a></li>\
    <li><a target="_top" href="et/text/simpress/guide/text2curve.html?DbPAR=DRAW">Tähemärkide teisendamine joonistusobjektideks</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Vaatamine</label><ul>\
    <li><a target="_top" href="et/text/simpress/guide/change_scale.html?DbPAR=DRAW">Suurenduse muutmine klaviatuuri abil</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Andmebaasid (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Üldine teave</label><ul>\
    <li><a target="_top" href="et/text/sdatabase/main.html?DbPAR=BASE">LibreOffice Database</a></li>\
    <li><a target="_top" href="et/text/shared/guide/database_main.html?DbPAR=BASE">Ülevaade andmeallikatest</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_new.html?DbPAR=BASE">Andmebaasi loomine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_tables.html?DbPAR=BASE">Tabelite kasutamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_queries.html?DbPAR=BASE">Päringute kasutamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_forms.html?DbPAR=BASE">Vormide kasutamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_reports.html?DbPAR=BASE">Aruannete loomine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_register.html?DbPAR=BASE">Andmebaasi registreerimine ja kustutamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_im_export.html?DbPAR=BASE">Andmete importimine ja eksportimine Base&#39;is</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_enter_sql.html?DbPAR=BASE">SQL-lausete täitmine</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Valemid (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Üldine teave ja kasutajaliidese kasutamine</label><ul>\
    <li><a target="_top" href="et/text/smath/main0000.html?DbPAR=MATH">LibreOffice Mathi Abi sissejuhatus</a></li>\
    <li><a target="_top" href="et/text/smath/main0503.html?DbPAR=MATH">LibreOffice Mathi võimalused</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice&#39;i valemielemendid</label><ul>\
    <li><a target="_top" href="et/text/smath/01/03090100.html?DbPAR=MATH">Unaarsed/binaarsed tehted</a></li>\
    <li><a target="_top" href="et/text/smath/01/03090200.html?DbPAR=MATH">Seosed</a></li>\
    <li><a target="_top" href="et/text/smath/01/03090800.html?DbPAR=MATH">Tehted hulkadega</a></li>\
    <li><a target="_top" href="et/text/smath/01/03090400.html?DbPAR=MATH">Funktsioonid</a></li>\
    <li><a target="_top" href="et/text/smath/01/03090300.html?DbPAR=MATH">Operaatorid</a></li>\
    <li><a target="_top" href="et/text/smath/01/03090600.html?DbPAR=MATH">Atribuudid</a></li>\
    <li><a target="_top" href="et/text/smath/01/03090500.html?DbPAR=MATH">Sulud</a></li>\
    <li><a target="_top" href="et/text/smath/01/03090700.html?DbPAR=MATH">Vormindus</a></li>\
    <li><a target="_top" href="et/text/smath/01/03091600.html?DbPAR=MATH">Muud sümbolid</a></li>\
            </ul></li>\
    <li><a target="_top" href="et/text/smath/guide/main.html?DbPAR=MATH">LibreOffice Mathi kasutamise juhised</a></li>\
    <li><a target="_top" href="et/text/smath/guide/keyboard.html?DbPAR=MATH">Kiirklahvid (LibreOffice Mathi hõlbustusfunktsioonid)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Käskude ja menüüde seletused</label><ul>\
    <li><a target="_top" href="et/text/smath/main0100.html?DbPAR=MATH">Menüüd</a></li>\
    <li><a target="_top" href="et/text/smath/main0200.html?DbPAR=MATH">Tööriistaribad</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Töö valemitega</label><ul>\
    <li><a target="_top" href="et/text/smath/guide/align.html?DbPAR=MATH">Valemi osade käsitsi joondamine</a></li>\
    <li><a target="_top" href="et/text/smath/guide/attributes.html?DbPAR=MATH">Vaikimisi omaduste muutmine</a></li>\
    <li><a target="_top" href="et/text/smath/guide/brackets.html?DbPAR=MATH">Valemi osade ühendamine loogeliste sulgude abil</a></li>\
    <li><a target="_top" href="et/text/smath/guide/comment.html?DbPAR=MATH">Kommentaaride lisamine</a></li>\
    <li><a target="_top" href="et/text/smath/guide/newline.html?DbPAR=MATH">Reavahetuste sisestamine</a></li>\
    <li><a target="_top" href="et/text/smath/guide/parentheses.html?DbPAR=MATH">Sulgude sisestamine</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Diagrammid</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Üldine teave</label><ul>\
    <li><a target="_top" href="et/text/schart/main0000.html?DbPAR=CHART">Diagrammid LibreOffice&#39;is</a></li>\
    <li><a target="_top" href="et/text/schart/main0503.html?DbPAR=CHART">LibreOffice Charti võimalused</a></li>\
    <li><a target="_top" href="et/text/schart/04/01020000.html?DbPAR=CHART">Diagrammide kiirklahvid</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="07"><label for="07">Makrod ja skriptimine</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Üldine teave ja kasutajaliidese kasutamine</label><ul>\
    <li><a target="_top" href="et/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice BASICu abi</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programmeerimine LibreOffice BASICu abil</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice BASICu sõnastik</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01010210.html?DbPAR=BASIC">Põhitõed</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01020000.html?DbPAR=BASIC">Süntaks</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice BASICu arenduskeskkond</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01030100.html?DbPAR=BASIC">Arenduskeskkonna ülevaade</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01030200.html?DbPAR=BASIC">BASICu redaktor</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01050100.html?DbPAR=BASIC">Jälgimise aken</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/main0211.html?DbPAR=BASIC">Makrode tööriistariba</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makro</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Käskude seletused</label><ul>\
    <li><a target="_top" href="et/text/sbasic/shared/01020300.html?DbPAR=BASIC">Using Procedures, Functions or Properties</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01020500.html?DbPAR=BASIC">Teegid, moodulid ja dialoogid</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funktsioonid, laused ja tehted</label><ul>\
    <li><a target="_top" href="et/text/sbasic/shared/03010000.html?DbPAR=BASIC">Ekraani sisend- ja väljundfunktsioonid</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020000.html?DbPAR=BASIC">Faili sisend-/väljundfunktsioonid</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030000.html?DbPAR=BASIC">Kuupäeva ja kellaaja funktsioonid</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03050000.html?DbPAR=BASIC">Vigade käsitlemise funktsioonid</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03060000.html?DbPAR=BASIC">Loogilised tehted</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03070000.html?DbPAR=BASIC">Matemaatilised tehted</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numbrilised funktsioonid</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090000.html?DbPAR=BASIC">Programmi täitmise kontrollimine</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100000.html?DbPAR=BASIC">Muutujad</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03110000.html?DbPAR=BASIC">Võrdlusoperaatorid</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120000.html?DbPAR=BASIC">Stringid</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/calc_functions.html?DbPAR=BASIC">Calling Calc Functions in Macros</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03130000.html?DbPAR=BASIC">Muud käsud</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Käitusaja funktsioonide, lausete ja tehete tähestikuline loend</label><ul>\
    <li><a target="_top" href="et/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc function</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030108.html?DbPAR=BASIC">CdateFromIso funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030107.html?DbPAR=BASIC">CdateToIso funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090404.html?DbPAR=BASIC">End lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03104700.html?DbPAR=BASIC">Erase Statement</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/ErrVBA.html?DbPAR=BASIC">Err VBA Object</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03050000.html?DbPAR=BASIC">Vigade käsitlemise funktsioonid</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090400.html?DbPAR=BASIC">Täpsemad laused</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080300.html?DbPAR=BASIC">Juhuslike arvude genereerimine</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103450.html?DbPAR=BASIC">Global lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102450.html?DbPAR=BASIC">IsError funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input # lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid funktsioon, Mid lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03070600.html?DbPAR=BASIC">Tehe "MOD"</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numbrilised funktsioonid</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub lause; On...GoTo lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/property.html?DbPAR=BASIC">Property Statement</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/Resume.html?DbPAR=BASIC">Resume Statement</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space ja Spc funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space ja Spc funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080400.html?DbPAR=BASIC">Ruutjuure arvutamine</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120202.html?DbPAR=BASIC">String funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03080100.html?DbPAR=BASIC">Trigonomeetrilised funktsioonid</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName funktsioon; VarType funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName funktsioon [VBA]</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03090411.html?DbPAR=BASIC">With lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write lause</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year funktsioon</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03070100.html?DbPAR=BASIC">Tehe "-"</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03070200.html?DbPAR=BASIC">Tehe "*"</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03070300.html?DbPAR=BASIC">Tehe "+"</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03070400.html?DbPAR=BASIC">Tehe "/"</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03070500.html?DbPAR=BASIC">Tehe "^"</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">BASICu teegid edasijõudnuile</label><ul>\
    <li><a target="_top" href="et/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Teek TOOLS</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Teek DEPOT</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Teek EURO</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Teek FORMWIZARD</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Teek GIMMICKS</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Teek SCHEDULE</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Teek SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Teek TEMPLATE</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Juhised</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/macro_recording.html?DbPAR=BASIC">Makro salvestamine</a></li>\
    <li><a target="_top" href="et/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Juhtelementide omaduste muutmine dialoogiredaktoris</a></li>\
    <li><a target="_top" href="et/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Juhtelementide loomine dialoogiredaktoris</a></li>\
    <li><a target="_top" href="et/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Juhtelementide programmeerimise näited dialoogiredaktoris</a></li>\
    <li><a target="_top" href="et/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="et/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">BASICu dialoogi loomine</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01030400.html?DbPAR=BASIC">Teekide ja moodulite korraldamine</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01020100.html?DbPAR=BASIC">Muutujate kasutamine</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01020200.html?DbPAR=BASIC">Objektide kasutamine</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01030300.html?DbPAR=BASIC">BASICu programmi silumine</a></li>\
    <li><a target="_top" href="et/text/sbasic/shared/01040000.html?DbPAR=BASIC">Sündmusjuhitavad makrod</a></li>\
    <li><a target="_top" href="et/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="et/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic to Python</a></li>\
    <li><a target="_top" href="et/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Pythoni skriptide abimaterjal</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Üldine teave ja kasutajaliidese kasutamine</label><ul>\
    <li><a target="_top" href="et/text/sbasic/python/main0000.html?DbPAR=BASIC">Python Scripts</a></li>\
    <li><a target="_top" href="et/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE for Python</a></li>\
    <li><a target="_top" href="et/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="et/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programmeerimine Pythoni keeles</label><ul>\
    <li><a target="_top" href="et/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="et/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python examples</a></li>\
    <li><a target="_top" href="et/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice&#39;i paigaldus</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office&#39;i dokumenditüüpide seoste muutmine</a></li>\
    <li><a target="_top" href="et/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Päästerežiim</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Üldised teemad</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Üldine teave</label><ul>\
    <li><a target="_top" href="et/text/shared/main0400.html?DbPAR=SHARED">Kiirklahvid</a></li>\
    <li><a target="_top" href="et/text/shared/00/00000005.html?DbPAR=SHARED">Üldine sõnastik</a></li>\
    <li><a target="_top" href="et/text/shared/00/00000002.html?DbPAR=SHARED">Interneti terminite sõnastik</a></li>\
    <li><a target="_top" href="et/text/shared/guide/accessibility.html?DbPAR=SHARED">LibreOffice&#39;i hõlbustusfunktsioonid</a></li>\
    <li><a target="_top" href="et/text/shared/guide/keyboard.html?DbPAR=SHARED">Kiirklahvid (LibreOffice&#39;i hõlbustus)</a></li>\
    <li><a target="_top" href="et/text/shared/04/01010000.html?DbPAR=SHARED">LibreOffice&#39;i üldised kiirklahvid</a></li>\
    <li><a target="_top" href="et/text/shared/guide/version_number.html?DbPAR=SHARED">Versioonid ja väljalaskenumbrid</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice ja Microsoft Office</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/ms_user.html?DbPAR=SHARED">Microsoft Office&#39;i ja LibreOffice&#39;i kasutamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Microsoft Office&#39;i ja LibreOffice&#39;i terminite võrdlus</a></li>\
    <li><a target="_top" href="et/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Microsoft Office&#39;i dokumentide teisendamisest</a></li>\
    <li><a target="_top" href="et/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Microsoft Office&#39;i dokumenditüüpide seoste muutmine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice&#39;i sätted</label><ul>\
    <li><a target="_top" href="et/text/shared/optionen/01000000.html?DbPAR=SHARED">Sätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01010100.html?DbPAR=SHARED">Isikuandmed</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01010200.html?DbPAR=SHARED">Üldine</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01010300.html?DbPAR=SHARED">Asukohad</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01010400.html?DbPAR=SHARED">Kirjutamise abivahendid</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01010600.html?DbPAR=SHARED">Üldine</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01010700.html?DbPAR=SHARED">Fondid</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01010800.html?DbPAR=SHARED">Vaade</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01010900.html?DbPAR=SHARED">Prindisätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01012000.html?DbPAR=SHARED">Programmi värvid</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01013000.html?DbPAR=SHARED">Hõlbustus</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/java.html?DbPAR=SHARED">Edasijõudnuile</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Täppishäälestus</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">BASICu IDE</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01020000.html?DbPAR=SHARED">Laadimise ja salvestamise sätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01030000.html?DbPAR=SHARED">Interneti sätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01040000.html?DbPAR=SHARED">Tekstidokumendi sätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01050000.html?DbPAR=SHARED">HTML-dokumendi sätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01060000.html?DbPAR=SHARED">Arvutustabeli sätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01070000.html?DbPAR=SHARED">Esitluste sätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01080000.html?DbPAR=SHARED">Joonistuste sätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01090000.html?DbPAR=SHARED">Valemid</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01110000.html?DbPAR=SHARED">Diagrammide sätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA sätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01140000.html?DbPAR=SHARED">Keeled</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01150000.html?DbPAR=SHARED">Keelesätted</a></li>\
    <li><a target="_top" href="et/text/shared/optionen/01160000.html?DbPAR=SHARED">Andmeallikate sätted</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Nõustajad</label><ul>\
    <li><a target="_top" href="et/text/shared/autopi/01000000.html?DbPAR=SHARED">Nõustaja</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Kirja loomise nõustaja</label><ul>\
    <li><a target="_top" href="et/text/shared/autopi/01010000.html?DbPAR=SHARED">Kirja loomise nõustaja</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Faksi loomise nõustaja</label><ul>\
    <li><a target="_top" href="et/text/shared/autopi/01020000.html?DbPAR=SHARED">Faksi loomise nõustaja</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Päevakorra loomise nõustaja</label><ul>\
    <li><a target="_top" href="et/text/shared/autopi/01040000.html?DbPAR=SHARED">Päevakorra loomise nõustaja</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML-vormingusse eksportimise nõustaja</label><ul>\
    <li><a target="_top" href="et/text/shared/autopi/01110000.html?DbPAR=SHARED">HTML-vormingusse eksportimine</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Dokumentide teisendaja</label><ul>\
    <li><a target="_top" href="et/text/shared/autopi/01130000.html?DbPAR=SHARED">Dokumentide teisendaja</a></li>\
			</ul></li>\
    <li><a target="_top" href="et/text/shared/autopi/01150000.html?DbPAR=SHARED">Euro teisendamise nõustaja</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">LibreOffice&#39;i seadistamine</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/configure_overview.html?DbPAR=SHARED">LibreOffice&#39;i kohandamine</a></li>\
    <li><a target="_top" href="et/text/shared/01/packagemanager.html?DbPAR=SHARED">Laienduste haldur</a></li>\
    <li><a target="_top" href="et/text/shared/guide/flat_icons.html?DbPAR=SHARED">Ikoonivaate muutmine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Nuppude lisamine tööriistaribale</a></li>\
    <li><a target="_top" href="et/text/shared/guide/workfolder.html?DbPAR=SHARED">Töökataloogi muutmine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/standard_template.html?DbPAR=SHARED">Vaikimisi mallide muutmine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Aadressiraamatu registreerimine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/formfields.html?DbPAR=SHARED">Nuppude lisamine ja redigeerimine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Töö kasutajaliidesega</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navigeerimine kiireks liikumiseks objektidele</a></li>\
    <li><a target="_top" href="et/text/shared/guide/navigator.html?DbPAR=SHARED">Dokumentide ülevaade Navigaatoris</a></li>\
    <li><a target="_top" href="et/text/shared/guide/autohide.html?DbPAR=SHARED">Akende kuvamine, peitmine ja dokkimine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/textmode_change.html?DbPAR=SHARED">Lisamisrežiimi ja ülekirjutusrežiimi vahel lülitumine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Tööriistaribade kasutamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digiallkirjad</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Teave digiallkirjade kohta</a></li>\
    <li><a target="_top" href="et/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Digiallkirjade rakendamine</a></li>\
    <li><a target="_top" href="et/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="et/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="et/text/shared/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Documents</a></li>\
    <li><a target="_top" href="et/text/shared/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="et/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Printimine, faksimine, saatmine</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/labels_database.html?DbPAR=SHARED">Aadressisiltide printimine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Mustvalgelt printimine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/email.html?DbPAR=SHARED">Dokumendi saatmine e-kirjana</a></li>\
    <li><a target="_top" href="et/text/shared/guide/fax.html?DbPAR=SHARED">Fakside saatmine ja LibreOffice&#39;i häälestamine faksimiseks</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Lohistamine</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/dragdrop.html?DbPAR=SHARED">Lohistamine LibreOffice&#39;i dokumendi sees</a></li>\
    <li><a target="_top" href="et/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Teksti liigutamine ja kopeerimine dokumentides</a></li>\
    <li><a target="_top" href="et/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Arvutustabeli alade kopeerimine tekstidokumentidesse</a></li>\
    <li><a target="_top" href="et/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Piltide kopeerimine dokumentide vahel</a></li>\
    <li><a target="_top" href="et/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Piltide kopeerimine galeriist</a></li>\
    <li><a target="_top" href="et/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Lohistamine andmeallika vaates</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Kopeerimine ja asetamine</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Joonistusobjektide kopeerimine teistesse dokumentidesse</a></li>\
    <li><a target="_top" href="et/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Piltide kopeerimine dokumentide vahel</a></li>\
    <li><a target="_top" href="et/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Piltide kopeerimine galeriist</a></li>\
    <li><a target="_top" href="et/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Arvutustabeli alade kopeerimine tekstidokumentidesse</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Diagrammid</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/chart_insert.html?DbPAR=SHARED">Diagrammide lisamine</a></li>\
    <li><a target="_top" href="et/text/schart/main0000.html?DbPAR=SHARED">Diagrammid LibreOffice&#39;is</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Laadimine, salvestamine, importimine, eksportimine, PDF</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/doc_open.html?DbPAR=SHARED">Dokumentide avamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/import_ms.html?DbPAR=SHARED">Teistes vormingutes dokumentide avamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/doc_save.html?DbPAR=SHARED">Dokumentide salvestamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Dokumentide automaatne salvestamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/export_ms.html?DbPAR=SHARED">Dokumentide salvestamine teistesse vormingutesse</a></li>\
    <li><a target="_top" href="et/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Ekspordi PDF-ina</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Tekstivormingus andmete importimine ja eksportimine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Lingid ja viited</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Hüperlinkide lisamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Suhtelised ja absoluutsed lingid</a></li>\
    <li><a target="_top" href="et/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Hüperlinkide redigeerimine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Dokumendi versioonihaldus</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Dokumendi erinevate versioonide võrdlemine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Versioonide ühendamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Muudatuste salvestamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/redlining.html?DbPAR=SHARED">Muudatuste kuvamine ja salvestamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Muudatustega nõustumine või nende hülgamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Versioonihaldus</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Sildid ja visiitkaardid</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/labels.html?DbPAR=SHARED">Siltide ja visiitkaartide loomine ning printimine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Väliste andmete lisamine</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/copytable2application.html?DbPAR=SHARED">Andmete lisamine arvutustabelitest</a></li>\
    <li><a target="_top" href="et/text/shared/guide/copytext2application.html?DbPAR=SHARED">Andmete lisamine tekstidokumentidest</a></li>\
    <li><a target="_top" href="et/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Bittrastrite lisamine, redigeerimine ja salvestamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Piltide lisamine galeriisse</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automaatfunktsioonid</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Automaatse URL-ide tuvastamise väljalülitamine</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Otsimine ja asendamine</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/data_search2.html?DbPAR=SHARED">Otsimine vormifiltrite abil</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_search.html?DbPAR=SHARED">Otsimine tabelites ja vormidokumentides</a></li>\
    <li><a target="_top" href="et/text/shared/01/02100001.html?DbPAR=SHARED">Regulaaravaldiste loend</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Juhised</label><ul>\
    <li><a target="_top" href="et/text/shared/guide/linestyles.html?DbPAR=SHARED">Joonestiilide rakendamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/text_color.html?DbPAR=SHARED">Teksti värvi muutmine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/change_title.html?DbPAR=SHARED">Dokumendi tiitli muutmine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/round_corner.html?DbPAR=SHARED">Nurkade ümardamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/background.html?DbPAR=SHARED">Taustavärvide ja taustapiltide määramine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/lineend_define.html?DbPAR=SHARED">Jooneotsade kirjeldamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Joonestiilide kirjeldamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Graafiliste objektide redigeerimine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/line_intext.html?DbPAR=SHARED">Joonte lisamine teksti</a></li>\
    <li><a target="_top" href="et/text/shared/guide/aaa_start.html?DbPAR=SHARED">Esimesed sammud</a></li>\
    <li><a target="_top" href="et/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Objektide lisamine galeriist</a></li>\
    <li><a target="_top" href="et/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Kaitstud tühikute, sidekriipsude ja tingimuslike eraldajate lisamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Erimärkide lisamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/tabs.html?DbPAR=SHARED">Tabelduskohtade lisamine ja redigeerimine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/protection.html?DbPAR=SHARED">Sisu kaitsmine LibreOffice&#39;is</a></li>\
    <li><a target="_top" href="et/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Salvestuste kaitsmine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Maksimaalse prinditava ala valimine leheküljel</a></li>\
    <li><a target="_top" href="et/text/shared/guide/measurement_units.html?DbPAR=SHARED">Mõõtühikute valimine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/language_select.html?DbPAR=SHARED">Dokumendi keele valimine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Tabeli koostamine</a></li>\
    <li><a target="_top" href="et/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Üksikute lõikude täppide ja nummerduse väljalülitamine</a></li>\
		</ul></li>\
	</ul></li></ul>\
';
