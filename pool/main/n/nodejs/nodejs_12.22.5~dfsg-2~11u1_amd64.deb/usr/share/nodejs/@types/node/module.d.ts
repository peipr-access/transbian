declare module 'module' {
    export = NodeJS.Module;
}
