This directory contains style sheets contributed by users.
default.css is the default style that you get if you don't specify any other.
To use a different one, specify it with a STYLESHEET command.
