                       Man-pages in Hungarian Language
                       ===============================

This will be the english translation of the Hungarian language file olvasd.el,
if I found somebody to transalte it. :)

