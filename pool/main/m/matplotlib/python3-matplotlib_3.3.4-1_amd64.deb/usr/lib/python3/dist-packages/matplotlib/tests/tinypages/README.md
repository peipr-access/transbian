# Test project for matplotlib sphinx extensions

A tiny sphinx project from ``sphinx-quickstart`` with all default answers.
