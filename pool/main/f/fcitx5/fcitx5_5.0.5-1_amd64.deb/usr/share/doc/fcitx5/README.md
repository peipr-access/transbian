Next generation of fcitx
==========================
Fcitx 5 is a generic input method framework released under LGPL-2.1+.

[![Jenkins Build Status](https://img.shields.io/jenkins/s/https/jenkins.fcitx-im.org/job/fcitx5.svg)](https://jenkins.fcitx-im.org/job/fcitx5/)
[![Coverity Scan Status](https://img.shields.io/coverity/scan/9063.svg)](https://scan.coverity.com/projects/fcitx-fcitx5)
[![Documentation](https://codedocs.xyz/fcitx/fcitx5.svg)](https://codedocs.xyz/fcitx/fcitx5/)
