.. cmake-module:: ../../Modules/CPackIFWConfigureFile.cmake
