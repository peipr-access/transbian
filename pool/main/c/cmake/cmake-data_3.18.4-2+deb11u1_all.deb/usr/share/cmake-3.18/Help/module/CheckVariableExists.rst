.. cmake-module:: ../../Modules/CheckVariableExists.cmake
