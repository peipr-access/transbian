.. cmake-module:: ../../Modules/FindKDE3.cmake
