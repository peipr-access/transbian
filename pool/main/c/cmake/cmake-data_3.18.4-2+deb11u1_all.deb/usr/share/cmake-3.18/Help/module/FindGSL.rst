.. cmake-module:: ../../Modules/FindGSL.cmake
