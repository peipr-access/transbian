# DO NOT EDIT. CREATED AUTOMATICALLY BY myConfig
package Tk::Config;
require Exporter;
use base qw(Exporter);
$VERSION = '804.035';
$inc = ' -I/usr/include/freetype2';
$define = '';
$xlib = '-L/usr/lib/x86_64-linux-gnu -lXft';
$xinc = '-I/usr/include';
$gccopt = '';
$win_arch = 'x';
@EXPORT = qw($VERSION $inc $define $xlib $xinc $gccopt $win_arch);
1;
