"""
For improved compatibility when older keyring metadata points
to this module, supply it. See jaraco/keyring#486.
"""
