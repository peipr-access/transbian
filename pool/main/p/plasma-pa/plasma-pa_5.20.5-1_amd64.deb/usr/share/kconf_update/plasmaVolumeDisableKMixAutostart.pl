#! /usr/bin/perl

use strict;

print "AutoStart=false\n";
print "startkdeRestore=false\n";
