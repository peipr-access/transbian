## Qt Process Manager

### Building

* Requires Qt 5

### License

Qps is licensed under the terms of the
[GPLv2](http://choosealicense.com/licenses/gpl-2.0/) or any later version.


### Translation

Translations can be done in [LXQt-Weblate](https://translate.lxqt-project.org/projects/lxqt-desktop/qps/)

<a href="https://translate.lxqt-project.org/projects/lxqt-desktop/qps/">
<img src="https://translate.lxqt-project.org/widgets/lxqt-desktop/-/qps/multi-auto.svg" alt="Translation status" />
</a>

